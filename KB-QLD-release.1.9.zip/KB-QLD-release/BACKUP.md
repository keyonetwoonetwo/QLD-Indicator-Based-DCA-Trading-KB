# Telegram 백업과 복구

## 백업 목적

KB QLD Trader 백업은 단순한 데이터 보관이 아니라 장애 후 기존 전략 cycle, state와 workflow를 검증된 상태로 이어서 복구하기 위한 것입니다.

## 백업 파일 내용

동일한 `tar.gz` 포맷을 Linux와 Termux에서 사용합니다. 정상 설치에서 archive에는 다음 파일이 들어갑니다.

- `state.json`
- `order_ledger.json`
- `dry_run_validation.json` (존재하는 경우)
- `trade_history.csv` (존재하는 경우)
- `trading_settings.json` (거래 설정만; `.env` 파일 자체는 제외)
- `manifest.json`

## 포함되지 않는 민감정보

`.env`, API Client Secret, Telegram Bot Token, OAuth token과 기타 인증정보는 포함하지 않습니다. 다만 state와 ledger에는 계좌 상태와 installation identity 같은 운영 데이터가 있으므로 백업 파일 자체를 공개 파일로 취급하면 안 됩니다.

## Telegram 백업 대화방 만들기

1. Telegram에서 새 그룹을 만들고 비공개로 유지합니다.
2. 기존 KB QLD Trader 봇을 그룹에 추가합니다.
3. 그룹에서 메시지 하나를 보냅니다.
4. Bot API `getUpdates` 등으로 그룹 Chat ID를 확인합니다. supergroup ID는 보통 `-100...` 형식입니다.
5. 백업 대화방을 분리하려면 해당 값을 `TELEGRAM_BACKUP_CHAT_ID`로 설정합니다.

Bot Token을 문서, 공개 채팅 또는 화면 공유에 붙여 넣지 마십시오.

권장 구성은 데이터·거래 알림은 개인 대화방, 백업 데이터는 비공개 Telegram 그룹으로 분리하는 것입니다. 분리를 원하면 그룹 ID를 `TELEGRAM_BACKUP_CHAT_ID`에 입력합니다. 별도 백업방을 만들지 않으려면 이 값을 비워 두십시오. 백업 tar.gz가 자동으로 `TELEGRAM_ALERT_CHAT_ID`로 전송됩니다.

Telegram을 사용하지 않으면 `TELEGRAM_ENABLED=false`로 둡니다. 일반 알림과 백업 전송만 비활성화되며 거래에는 영향이 없습니다.

## 자동 백업 흐름

```text
scheduler
→ backup.sh
→ active workflow broker reconciliation
→ 현재 QLD zero-fill 주문은 cancel 후 CANCELED 확인 / 불명확하면 clean backup 중단
→ 레거시 workflow는 기존 주문 조회만 수행하고 BLOCKED 보존 / clean backup 중단
→ 기존 tar.gz 생성 및 manifest/hash 작성
→ Telegram sendDocument
→ 별도 백업 대화방 또는 알림 대화방
```

Linux systemd timer와 Termux cron은 기존 시간대와 백업 시각을 유지합니다.

안전하게 종료된 workflow는 `order_ledger.json`의 `workflow_history`에 `ABORTED_PRE_BACKUP`, `ABORTED_NO_FILL` 또는 `ABORTED_DRY_RUN` 이력과 확인 결과를 남긴 뒤 `active_workflow`만 비웁니다. DRY_RUN은 simulated ledger만 정리하고 전략 state를 advance하지 않습니다. PARTIAL, UNKNOWN, 취소 미확정 또는 broker 조회 실패는 active 상태를 유지하고 Telegram 경고 후 정상 백업을 만들지 않습니다.

## 운영자 workflow reconciliation

아래 자동 완료·종결 처리는 현재 QLD MINUTE workflow에만 적용됩니다. 레거시는 기존 주문번호로 조회·대조한 뒤 항상 BLOCKED로 남습니다. 원장·단계·pending transition을 삭제하거나 완료 처리하지 않으며 취소도 수행하지 않습니다. 모든 과거 주문이 체결됐더라도 다음 전략 단계는 실행하지 않습니다.

```bash
./reconcile-workflow.sh
```

이 명령은 persisted `broker_order_id`로 모든 주문 상세와 MAIN/SAFE/USD cash를 다시 조회합니다. 전량체결이 확인되고 모든 step이 끝난 workflow만 기존 conditional state commit 경로로 완료하며, zero-fill terminal 주문만 abort history를 남기고 종료합니다. PARTIAL/UNKNOWN/조회 실패는 추정하지 않고 active 상태로 보존합니다. `state.json`이나 `order_ledger.json`을 직접 수정하지 마십시오.

## 복구 방법

### 새 서버 장애 복구 및 scheduler 재구성

setup이 기존 MAIN 보유 때문에 fresh initialize를 거부한 새 Linux/Termux 환경에서는 다음을 사용합니다.

```bash
./recover_backup.sh /path/to/kb-qld-trader-backup-YYYYMMDD-HHMMSS-UTC.tar.gz
```

새 백업은 ETF 종목 및 거래시간이 다를 때 각각 백업값 적용 여부를 `[y/N]`으로 질문합니다. N이면 현재 설정을 유지합니다. 종목이 같으면 질문하지 않습니다. 계좌번호/account binding, 원장 및 미확정 주문 안전 검증은 계속 적용됩니다. 새 주문은 MINUTE만 허용합니다. 설정 데이터가 없는 오래된 백업은 기존 `[1] 현재 거래방식 유지 / [2] 백업 거래방식 복구` 선택 절차를 유지합니다.

archive hash와 3.91-compatible schema, protected identity를 검증하고 현재 인증정보로 KB account/portfolio/persisted order를 다시 조회합니다. 임시 state/ledger에서 reconcile과 consistency 검사가 모두 성공한 후에만 실제 파일을 교체하고 scheduler를 구성합니다. PARTIAL, UNKNOWN, 주문조회 실패 또는 portfolio mismatch는 fail-closed이며 scheduler를 만들지 않습니다. 복구 중 주문 생성 및 취소 API는 호출하지 않습니다. `[2]`의 `.env` 반영 이후 어떤 단계라도 실패하면 `.env`도 복구 전 내용으로 rollback합니다.

설정 및 CSV 복원을 포함한 복구는 `recover_backup.sh`를 사용하십시오. `restore.sh`는 기존 state/ledger 전용 복원 명령이며 설정/CSV를 복원하지 않습니다.

기존 local state/ledger가 있으면 `data/pre-recovery-local-*-UTC/`에 보존합니다. 이후 실패하면 실제 pair와 기존 scheduler 상태를 rollback합니다.

### 일반 파일 복원

1. Telegram 백업 대화방에서 최신 `tar.gz`를 직접 다운로드합니다.
2. 파일을 Linux 서버 또는 Termux로 복사합니다.
3. `./restore.sh /path/to/kb-qld-trader-backup-YYYYMMDD-HHMMSS-UTC.tar.gz`를 실행합니다.
4. manifest, hash, account/install identity, state와 ledger 검증이 완료된 뒤 `./validate.sh`를 실행하고 운영을 재개합니다.

자동 Telegram 다운로드 기능은 없습니다.

## 백업 실패 시

Telegram 전송 실패는 trading state, ledger 또는 workflow를 변경하거나 거래를 차단하지 않습니다. 생성된 archive는 `data/backups/`에 남기므로 수동 전송과 복구에 사용할 수 있습니다. 일반 alert 대화방 설정이 활성화되어 있으면 짧은 실패 알림도 시도하며, 그 알림까지 실패하면 로그만 남깁니다.

## 백업·복구 동작

### 2.1 레거시 workflow 제한

허용되는 실행은 `event=CONDITIONAL_ACCUMULATION`, `execution_core=MINUTE`이며 모든 단계가 `MAIN_AMOUNT_BUY`, `SAFE_CASH_BUY`, `SAFE_CASH_SELL`인 workflow뿐입니다. 분할진입·과열·Milestone·Drawdown·MAIN 자동매도·자산전환 및 CLOSE workflow는 조회 전용입니다. 빈 레거시 단계나 전량체결 상태도 자동 완료하지 않습니다.

`run.sh`, 재시작, `reconcile-workflow.sh`, 백업 직전 대조 및 `recover_backup.sh`는 공통 대조 경로에서 차단합니다. 실제 주문은 기존 broker_order_id로 조회하고, 주문번호가 없으면 추정 제출하지 않습니다. 계좌번호/account binding가 일치하지 않으면 조회도 중단합니다. 레거시 종목/시간 메타데이터 차이는 같은 계좌의 조회에만 허용하며 현재 설정으로 변환하지 않습니다. 식별 가능한 DRY_RUN SIM 주문은 실제 계좌 조회를 하지 않습니다.

active 레거시가 들어 있는 백업은 자동 복구 완료 및 스케줄러 재설치가 차단됩니다. 임시 원장에서 기존 주문을 조회한 뒤 중단하고 원래 rollback 절차를 유지합니다. `restore.sh`는 검증된 원장을 그대로 복원하며 이후 실행에서 동일하게 차단합니다. `initialize.sh`는 기존 원장을 우회 초기화하지 않습니다. active 레거시가 없는 과거 백업 호환성은 유지합니다.

차단 상태에서 state/ledger를 직접 삭제·수정하지 마십시오. 체결·미체결·현금과 백업/원장을 수동 확인해야 하며, 이 릴리스는 자동 이관 기능을 제공하지 않습니다. clean backup이 막히면 기존 원본 데이터와 백업을 별도로 보존하십시오.

기존 압축 포맷 버전 1을 유지하고 다음 선택 항목을 확장한다.

- trade_history.csv: 존재할 때만 저장. 복원은 기존 CSV와 백업 CSV의 행을 손실 없이 합친다.
  동일 행은 두 파일 중 큰 출현 횟수를 유지한다. 컬럼 불일치는 중단한다.
  과거 종목·주문 식별자·실제/가상 구분값은 바꾸지 않는다.
- trading_settings.json: .env의 거래 설정 27개만 저장한다. .env 자체는 넣지 않는다.
- dry_run_validation.json: 기존 파일이 존재하면 그대로 포함한다.

설정 대상은 3개 종목, RISK_THRESHOLD, MA_PERIOD, F&G 임계값 2개,
CASH_TARGET_MULTIPLIER, MIN_ORDER_AMOUNT_USD, 매수금액 12개,
TRADING_SIGNAL_MODE, SIGNAL_TIME, MINUTE_ORDER_CUTOFF,
MINUTE_POLLING_INTERVAL_SECONDS, CANDLE_LOOKBACK_DAYS, BACKUP_TIME이다.
모두 현재 전략·runner·설정·스케줄러에서 사용하는 키이다. 이외 설정은 추가하지 않았다.
API/Telegram 비밀값, 계좌 설정 및 LIVE 활성화 키는 설정 JSON에서 제외한다.
기존 state/ledger의 계좌 식별자는 기존 계좌 안전성 검증을 위해 유지한다.

새 백업에서는 ETF가 다를 때만 종목 적용 y/N 질문을 한다.
시간 설정이 다를 때만 시간 적용 y/N 질문을 한다.
N이면 현재 종목/시간을 유지하며, 시간 차이가 적용되지 않으면 스케줄러에 손대지 않는다.
나머지 저장된 거래 설정은 기존 AppConfig 검증 후 복원한다. 누락 키는 현재 값을 유지한다.
설정 JSON이 없는 옛 백업도 원래 복구 방식으로 읽는다.
옛 백업의 신호 방식/시간 선택 질문은 하위 호환을 위해 기존 방식대로 유지한다.
설정 복원이 CLOSE 주문을 활성화하지 않으며 새 설정의 주문 방식은 MINUTE만 허용한다.

종목 변경이 아직 안전 체크포인트에 반영되지 않았다면 백업도 명확한 오류로 중단한다.
계좌 및 manifest/hash 검증은 생략하지 않는다. 새 역할의 보유량은 다른 역할의 과거
스냅샷과 비교하지 않고 확인된 계좌 조회값으로 갱신한다.
종목이 다르면 미확정 백업 주문, 진행 중 workflow, 실제 OPEN 주문이 있거나
조회에 실패할 때 중단한다. 로컬의 미확정/백업보다 새로운 실제 체결 및 더 최근의
당일 실행 체크포인트는 자동 덮어쓰지 않는다.
복구 전 데이터는 data/pre-recovery-local-*에 보존하며, 실패하면 설정/데이터를 롤백한다.
스케줄러 롤백 실패는 명시적으로 표시하며 DRY_RUN/LIVE 차단 상태에서 수동 점검이 필요하다.
복원한 DRY_RUN 검증 기록이 현재 종목/시간과 다르면 기존 LIVE 게이트의 재검증이 필요하다.

## .env 직접 종목 변경

다음 실행에서 기존 ProcessLock 안에 새 종목을 검사한다.
계좌·거래시간 변경을 종목 변경으로 우회하지 않는다.
진행 중 workflow, 알려지지 않은 상태를 포함한 비종결 주문, 계좌 OPEN 주문,
조회 실패가 있으면 새 주문 없이 중단한다.
이미 실행한 같은 미국 거래일의 종목 변경은 다음 거래일까지 보류한다.
당일 완료 날짜를 초기화하지 않으므로 MAIN/SAFE 중복 실행을 방지한다.
SAFE 주간 작업은 기존 미국 거래일/주 경계 판단을 그대로 사용한다.
금요일→다음 첫 거래일에는 새 SAFE로 현재 보유량/주문가능 현금을 조회하여 계산하고,
같은 날 역할 변경으로 주간 작업을 재실행하지 않는다. 이전 종목을 자동으로 매도하지 않는다.

## WSL/Termux 확인 절차

LIVE 설치와 다른 디렉터리에 압축을 풀고 기존 설치 절차를 사용한다.
원본 서비스와 같은 계좌·스케줄로 동시에 가동하지 않는다.
.env에서 EXECUTION_MODE=DRY_RUN, LIVE_TRADING_ENABLED=false를 직접 확인한다.

```bash
# 독립 복사본에서만 수행
./setup.sh
# .env 두 안전 설정이 DRY_RUN/false인지 확인한 후
.venv/bin/python -m pip install pytest
.venv/bin/python -m pytest -q
.venv/bin/python -m compileall -q app config scripts tests
./backup.sh
./recover_backup.sh ~/storage/downloads/
# WSL에서는 백업이 있는 경로를 지정
./recover_backup.sh /mnt/c/Users/사용자/Downloads/
```

백업에 CSV와 trading_settings.json이 있는지 확인하고 인증값/.env가 없는지 검사한다.
종목 변경 질문에서 N/y 각각 테스트하고 CSV의 과거 종목명이 유지되는지 확인한다.
시간 N이면 기존 일정을 비교하고, y이면 기존 설정 설치 결과를 확인한다.

```bash
# Termux
crontab -l
# WSL Ubuntu/systemd 환경
systemctl cat kb-qld-trader.timer kb-qld-trader-backup.timer
systemctl list-timers --all
# 계좌 조회만 하는 기존 원장 대조
./reconcile-workflow.sh
# MINUTE DRY_RUN 검증 후 확정 일봉 사후 대조
./validate.sh
./validate-close.sh
```

ETF 변경 후 기존 검증 승인으로 LIVE를 켜지 말고 새 설정의 DRY_RUN 검증을 수행한다.
실제 운영 장치에서 스케줄러/Telegram/백업 전송 확인이 끝나기 전 LIVE 전환을 하지 않는다.

