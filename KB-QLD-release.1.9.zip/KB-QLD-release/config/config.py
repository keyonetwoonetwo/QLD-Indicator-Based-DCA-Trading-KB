import os
import re
import hashlib
from dataclasses import dataclass, field
from datetime import datetime, time as clock_time, timedelta
from decimal import Decimal
from pathlib import Path
from typing import Dict, Optional, Tuple
from config.defaults import (
    DEFAULT_MAIN_SYMBOL,
    DEFAULT_MINUTE_ORDER_CUTOFF,
    DEFAULT_SAFE_SYMBOL,
    DEFAULT_SIGNAL_SYMBOL,
    DEFAULT_SIGNAL_TIME,
)

AMOUNT_KEYS = tuple(
    f"{regime}_{direction}_{band}_USD"
    for regime in ("RISK_ON", "RISK_OFF")
    for direction in ("GREEN", "RED")
    for band in ("FG_LOW", "FG_MID", "FG_HIGH")
)

SYMBOL_KEYS = ("SIGNAL_SYMBOL", "MAIN_SYMBOL", "SAFE_SYMBOL")
SCHEDULE_KEYS = ("TRADING_SIGNAL_MODE", "SIGNAL_TIME", "MINUTE_ORDER_CUTOFF",
                 "MINUTE_POLLING_INTERVAL_SECONDS", "BACKUP_TIME")
TRADING_BACKUP_KEYS = SYMBOL_KEYS + SCHEDULE_KEYS + (
    "RISK_THRESHOLD", "MA_PERIOD", "FEAR_GREED_LOW_THRESHOLD",
    "FEAR_GREED_HIGH_THRESHOLD", "CASH_TARGET_MULTIPLIER",
    "MIN_ORDER_AMOUNT_USD", "CANDLE_LOOKBACK_DAYS",
) + AMOUNT_KEYS


def normalize_kb_account_no(value: Optional[str]) -> Optional[str]:
    """Return a canonical local account number or reject bad input."""
    if value is None or value == "":
        return None
    canonical = re.sub(r"[-\s]+", "", value)
    if not canonical or not canonical.isdigit():
        raise ValueError("KB_ACCOUNT_NO must contain digits only (hyphens and whitespace are allowed separators)")
    return canonical


def _load_env_file(filepath: str = ".env") -> None:
    """Lightweight .env parser using standard library."""
    p = Path(filepath)
    if not p.exists():
        return
    try:
        with open(p, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                k = k.strip()
                v = v.strip().strip("'\"")
                if k not in os.environ:
                    os.environ[k] = v
    except Exception:
        pass


_load_env_file()


def account_fingerprint(account_no: str) -> str:
    """Stable local identity; never expose a configured account number in state."""
    if account_no.startswith("kb-account:"):
        return account_no
    canonical = normalize_kb_account_no(account_no)
    if not canonical:
        raise ValueError("KB account number is required")
    return "kb-account:" + hashlib.sha256(canonical.encode()).hexdigest()


@dataclass
class StrategyConfig:
    ma_period: int = 200


@dataclass(frozen=True)
class GenericStrategyConfig:
    """Generic strategy profile with a deliberately small durable identity.

    ``signal_symbol`` is deliberately distinct from ``main_symbol``.  The
    former is only allowed to drive regime/rebound calculations; the latter
    owns the configured main-asset lifecycle and every executable main-asset order.
    Tuning values are runtime-selectable.  Decisions and destinations are
    persisted into a workflow before submission, so recovery never reinterprets
    an existing workflow from a changed ``.env``.
    """
    signal_symbol: str = DEFAULT_SIGNAL_SYMBOL
    main_symbol: str = DEFAULT_MAIN_SYMBOL
    safe_symbol: str = DEFAULT_SAFE_SYMBOL
    risk_threshold: float = 1.0
    signal_time: str = DEFAULT_SIGNAL_TIME

    def installation_identity(
        self, signal_mode: str, account_no: Optional[str] = None, account_binding: Optional[str] = None,
    ) -> Dict[str, str]:
        identity = {
            "signal_symbol": self.signal_symbol,
            "main_symbol": self.main_symbol,
            "safe_symbol": self.safe_symbol,
            "signal_time": self.signal_time,
            "signal_mode": signal_mode,
        }
        if account_no is not None and account_binding is not None:
            identity["broker"] = "KB"
            identity["account_no"] = account_fingerprint(account_no)
            identity["account_binding"] = str(account_binding)
        return identity


@dataclass
class TradingConfig:
    min_order_amount_usd: float = 1.0
    candle_lookback_days: int = 201
    fear_greed_low_threshold: Decimal = Decimal("10")
    fear_greed_high_threshold: Decimal = Decimal("45")
    cash_target_multiplier: Decimal = Decimal("5")
    buy_amounts: Dict[str, Decimal] = field(
        default_factory=lambda: {
            key: Decimal(str(amount))
            for regime, directions in {
                "RISK_ON": {"GREEN": (10, 5, 0), "RED": (20, 15, 10)},
                "RISK_OFF": {"GREEN": (20, 15, 10), "RED": (40, 30, 20)},
            }.items()
            for direction, amounts in directions.items()
            for band, amount in zip(("FG_LOW", "FG_MID", "FG_HIGH"), amounts)
            for key in (f"{regime}_{direction}_{band}_USD",)
        }
    )


@dataclass
class MinuteConfig:
    """All times are interpreted in America/New_York, never server local time."""
    polling_interval_seconds: float = 2.0
    order_cutoff: str = DEFAULT_MINUTE_ORDER_CUTOFF


@dataclass
class StorageConfig:
    state_file: str = "data/state.json"
    daily_history_file: str = "data/history/daily_history.csv"
    trade_history_file: str = "data/history/trade_history.csv"
    order_ledger_file: str = "data/order_ledger.json"
    process_lock_file: str = "data/trader.lock"


@dataclass
class AppConfig:
    execution_mode: str = "DRY_RUN"
    live_trading_enabled: bool = False
    signal_mode: str = "MINUTE"
    timeout_seconds: int = 30

    kb_client_id: str = ""
    kb_client_secret: str = ""
    kb_api_base_url: str = "https://developer.kbsec.com:32484"
    kb_account_no: Optional[str] = None

    telegram_bot_token: str = ""
    telegram_chat_id: str = ""
    telegram_enabled: bool = False

    strategy_rules: StrategyConfig = field(default_factory=StrategyConfig)
    strategy: GenericStrategyConfig = field(default_factory=GenericStrategyConfig)
    trading: TradingConfig = field(default_factory=TradingConfig)
    minute: MinuteConfig = field(default_factory=MinuteConfig)
    storage: StorageConfig = field(default_factory=StorageConfig)

    def resolved_strategy(self) -> GenericStrategyConfig:
        """Return the single configured generic strategy profile."""
        return self.strategy

    @property
    def target_cash(self) -> Decimal:
        return max(self.trading.buy_amounts.values(), default=Decimal("0")) * self.trading.cash_target_multiplier

    @staticmethod
    def _validate_minute_timing(signal_time: str, minute: MinuteConfig) -> None:
        """Validate the bounded regular-session MINUTE execution window."""
        values = {
            "signal_time": signal_time,
            "order_cutoff": minute.order_cutoff,
        }
        parsed: Dict[str, clock_time] = {}
        for name, value in values.items():
            if not isinstance(value, str) or not re.fullmatch(r"\d{2}:\d{2}:\d{2}", value):
                raise ValueError(f"Invalid MINUTE timing: {name} must be HH:MM:SS")
            try:
                parsed[name] = clock_time.fromisoformat(value)
            except ValueError as exc:
                raise ValueError(f"Invalid MINUTE timing: {name} must be HH:MM:SS") from exc

        signal = parsed["signal_time"]
        order_cutoff = parsed["order_cutoff"]
        regular_start = clock_time(9, 30)
        regular_close = clock_time(16, 0)
        polling_start = (datetime.combine(datetime(2000, 1, 1).date(), signal) + timedelta(minutes=1)).time()

        if signal.second != 0 or signal.microsecond != 0:
            raise ValueError("Invalid MINUTE timing: signal_time must be minute-aligned")
        if signal < regular_start:
            raise ValueError("Invalid MINUTE timing: signal_time must be at or after 09:30:00")
        if not polling_start < order_cutoff:
            raise ValueError("Invalid MINUTE timing: polling start must be before order_cutoff")
        if not order_cutoff < regular_close:
            raise ValueError("Invalid MINUTE timing: order_cutoff must be before 16:00:00")

    @classmethod
    def load(cls) -> "AppConfig":
        _load_env_file()
        strategy_defaults = StrategyConfig()
        trading_defaults = TradingConfig()
        minute_defaults = MinuteConfig()

        mode = os.getenv("EXECUTION_MODE", "DRY_RUN").upper()
        live_enabled_raw = os.getenv("LIVE_TRADING_ENABLED", "false").strip().lower()
        live_enabled = live_enabled_raw == "true"
        signal_mode = os.getenv("TRADING_SIGNAL_MODE", "MINUTE").upper()
        if signal_mode != "MINUTE":
            raise ValueError("TRADING_SIGNAL_MODE must be MINUTE; CLOSE is validation-only")
        timeout = int(os.getenv("TIMEOUT_SECONDS", "30"))

        generic_values = {
            "signal_symbol": os.getenv("SIGNAL_SYMBOL"),
            "main_symbol": os.getenv("MAIN_SYMBOL"),
            "safe_symbol": os.getenv("SAFE_SYMBOL"),
            "risk_threshold": os.getenv("RISK_THRESHOLD"),
            "signal_time": os.getenv("SIGNAL_TIME"),
        }
        required_generic_fields = [
            "signal_symbol", "main_symbol", "safe_symbol", "risk_threshold", "signal_time",
        ]
        missing = [name for name in required_generic_fields if generic_values[name] in (None, "")]
        if missing:
            raise ValueError(f"Incomplete generic strategy installation: missing {', '.join(missing)}")
        generic_cfg = GenericStrategyConfig(
            signal_symbol=str(generic_values["signal_symbol"]).upper(),
            main_symbol=str(generic_values["main_symbol"]).upper(),
            safe_symbol=str(generic_values["safe_symbol"]).upper(),
            risk_threshold=float(generic_values["risk_threshold"]),
            signal_time=str(generic_values["signal_time"] or ""),
        )
        if not Decimal(str(generic_cfg.risk_threshold)).is_finite() or generic_cfg.risk_threshold <= 0:
            raise ValueError("RISK_THRESHOLD must be finite and positive")
        strategy_rules = StrategyConfig(
            ma_period=int(os.getenv("MA_PERIOD", str(strategy_defaults.ma_period))),
        )
        buy_amounts = {key: Decimal(os.getenv(key, str(trading_defaults.buy_amounts[key]))) for key in AMOUNT_KEYS}
        if any(not value.is_finite() or value < 0 for value in buy_amounts.values()):
            raise ValueError("All twelve buy amounts must be finite and non-negative")
        fg_low = Decimal(os.getenv("FEAR_GREED_LOW_THRESHOLD", "10"))
        fg_high = Decimal(os.getenv("FEAR_GREED_HIGH_THRESHOLD", "45"))
        if not fg_low.is_finite() or not fg_high.is_finite() or fg_low < 0 or fg_high > 100 or fg_low >= fg_high:
            raise ValueError("FEAR_GREED_LOW_THRESHOLD must be below FEAR_GREED_HIGH_THRESHOLD")
        cash_multiplier = Decimal(os.getenv("CASH_TARGET_MULTIPLIER", "5"))
        if not cash_multiplier.is_finite() or cash_multiplier < 0:
            raise ValueError("CASH_TARGET_MULTIPLIER must be finite and non-negative")
        trade_cfg = TradingConfig(
            min_order_amount_usd=float(os.getenv("MIN_ORDER_AMOUNT_USD", str(trading_defaults.min_order_amount_usd))),
            candle_lookback_days=int(os.getenv("CANDLE_LOOKBACK_DAYS", str(trading_defaults.candle_lookback_days))),
            fear_greed_low_threshold=fg_low,
            fear_greed_high_threshold=fg_high,
            cash_target_multiplier=cash_multiplier,
            buy_amounts=buy_amounts,
        )
        minute_cfg = MinuteConfig(
            polling_interval_seconds=float(os.getenv("MINUTE_POLLING_INTERVAL_SECONDS", str(minute_defaults.polling_interval_seconds))),
            order_cutoff=os.getenv("MINUTE_ORDER_CUTOFF", minute_defaults.order_cutoff),
        )
        if strategy_rules.ma_period <= 0 or trade_cfg.candle_lookback_days <= 0:
            raise ValueError("MA_PERIOD and CANDLE_LOOKBACK_DAYS must be positive")
        if not Decimal(str(trade_cfg.min_order_amount_usd)).is_finite() or trade_cfg.min_order_amount_usd < 0:
            raise ValueError("MIN_ORDER_AMOUNT_USD must be finite and non-negative")
        if not Decimal(str(minute_cfg.polling_interval_seconds)).is_finite() or minute_cfg.polling_interval_seconds <= 0:
            raise ValueError("MINUTE_POLLING_INTERVAL_SECONDS must be finite and positive")
        if signal_mode == "MINUTE":
            cls._validate_minute_timing(generic_cfg.signal_time, minute_cfg)

        return cls(
            execution_mode=mode,
            live_trading_enabled=live_enabled,
            signal_mode=signal_mode,
            timeout_seconds=timeout,
            kb_client_id=os.getenv("KB_CLIENT_ID", ""),
            kb_client_secret=os.getenv("KB_CLIENT_SECRET", ""),
            kb_api_base_url=os.getenv("KB_API_BASE_URL", "https://developer.kbsec.com:32484"),
            kb_account_no=normalize_kb_account_no(os.getenv("KB_ACCOUNT_NO", None)),
            telegram_bot_token=os.getenv("TELEGRAM_BOT_TOKEN", ""),
            telegram_chat_id=os.getenv("TELEGRAM_ALERT_CHAT_ID", ""),
            telegram_enabled=os.getenv("TELEGRAM_ENABLED", "false").lower() == "true",
            strategy_rules=strategy_rules,
            strategy=generic_cfg,
            trading=trade_cfg,
            minute=minute_cfg,
            storage=StorageConfig(),
        )
