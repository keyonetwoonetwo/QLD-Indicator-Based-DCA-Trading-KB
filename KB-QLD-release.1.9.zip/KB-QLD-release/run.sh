#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"
[[ -f .env ]] || { echo ".env is missing; run ./configure.sh" >&2; exit 1; }
[[ -x .venv/bin/python ]] || { echo ".venv is missing; run ./install.sh" >&2; exit 1; }
exec .venv/bin/python "$ROOT/app/main.py"
