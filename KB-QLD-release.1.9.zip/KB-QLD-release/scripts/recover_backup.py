#!/usr/bin/env python3
"""Fail-closed disaster recovery using a verified 3.91-compatible backup."""
import argparse
import json
import os
import tempfile
from contextlib import nullcontext
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Dict, Optional

try:
    from backup_common import atomic_place_pair, validate_restore_identity, verify_archive
    from reconcile_workflow import _portfolio
    from recovery_scheduler import RecoveryScheduler
    from release_common import ROOT, read_env, runtime_context
except ModuleNotFoundError:
    from scripts.backup_common import atomic_place_pair, validate_restore_identity, verify_archive
    from scripts.reconcile_workflow import _portfolio
    from scripts.recovery_scheduler import RecoveryScheduler
    from scripts.release_common import ROOT, read_env, runtime_context


def _restore_originals(originals: Dict[Path, Optional[bytes]]) -> None:
    """Rollback the pre-recovery local pair without mixing it with backup data."""
    for target, contents in originals.items():
        if contents is None:
            target.unlink(missing_ok=True)
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        temporary = target.with_suffix(target.suffix + ".recovery-rollback")
        temporary.write_bytes(contents)
        os.chmod(temporary, 0o600)
        os.replace(temporary, target)


def _preserve_local_pair(originals: Dict[Path, Optional[bytes]], root: Path = ROOT) -> Path:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S-UTC")
    destination = root / "data" / f"pre-recovery-local-{stamp}"
    destination.mkdir(parents=True, exist_ok=False)
    os.chmod(destination, 0o700)
    metadata = {}
    for target, contents in originals.items():
        metadata[target.name] = "present" if contents is not None else "absent"
        if contents is not None:
            (destination / target.name).write_bytes(contents)
            os.chmod(destination / target.name, 0o600)
    (destination / "manifest.json").write_text(
        json.dumps(metadata, indent=2, sort_keys=True) + "\n", encoding="utf-8",
    )
    return destination


def _backup_signal_identity(files) -> Dict[str, str]:
    """Read only the two recovery-selectable identity values from verified bytes."""
    try:
        state = json.loads(files["state.json"].decode("utf-8"))
        identity = state["installation_identity"]
        mode = str(identity["signal_mode"]).strip().upper()
        signal_time = str(identity["signal_time"]).strip()
    except (KeyError, TypeError, ValueError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeError("backup installation identity is invalid") from exc
    if mode not in {"CLOSE", "MINUTE"} or not signal_time:
        raise RuntimeError("backup signal mode/time is invalid")
    return {"signal_mode": mode, "signal_time": signal_time}


def _choose_signal_recovery(backup_signal, values, choice=None, input_fn=input):
    current = {
        "signal_mode": str(values.get("TRADING_SIGNAL_MODE", "")).strip().upper(),
        "signal_time": str(values.get("SIGNAL_TIME", "")).strip(),
    }
    if current == backup_signal:
        return "CURRENT", current
    if choice is None:
        print(
            "Backup and current trading methods differ.\n\n"
            f"Backup: {backup_signal['signal_mode']} / {backup_signal['signal_time']}\n"
            f"Current: {current['signal_mode']} / {current['signal_time']}\n\n"
            "[1] Restore strategy state only (keep current trading method)\n"
            "[2] Restore strategy state + trading method (update .env from backup)"
        )
        choice = input_fn("Select recovery method [1/2]: ").strip()
    choice = str(choice).strip()
    if choice == "1":
        return "CURRENT", current
    if choice == "2":
        return "BACKUP", dict(backup_signal)
    raise RuntimeError("recovery method must be 1 or 2")


def _atomic_update_signal_env(path: Path, signal: Dict[str, str]) -> None:
    """Update approved trading keys, preserving the existing single .env."""
    if not path.is_file():
        raise RuntimeError(f".env not found: {path}")
    with path.open(encoding="utf-8",newline="") as stream:
        original = stream.read()
    replacements = ({"TRADING_SIGNAL_MODE": signal["signal_mode"], "SIGNAL_TIME": signal["signal_time"]}
                    if "signal_mode" in signal else dict(signal))
    seen = set()
    lines = []
    for line in original.splitlines(keepends=True):
        stripped = line.strip()
        key = stripped.split("=", 1)[0].strip() if "=" in stripped else ""
        if key in replacements and not stripped.startswith("#"):
            ending = "\r\n" if line.endswith("\r\n") else "\n" if line.endswith("\n") else ""
            lines.append(f"{key}={replacements[key]}{ending}")
            seen.add(key)
        else:
            lines.append(line)
    if lines and not lines[-1].endswith(("\n", "\r")):
        lines[-1] += "\n"
    for key, value in replacements.items():
        if key not in seen:
            lines.append(f"{key}={value}\n")
    temporary = path.with_suffix(path.suffix + ".recovery-update")
    try:
        temporary.write_text("".join(lines), encoding="utf-8", newline="")
        os.chmod(temporary, 0o600)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _reconcile_temporary(files, manifest, context_factory=runtime_context, allow_symbols=False):
    """Validate and reconcile only temporary files; never submit/cancel orders."""
    from app.execution import WorkflowExecutor, WorkflowReconciler
    from app.models.common import ExecutionMode
    from app.storage import OrderLedgerStore, StateStore

    config, broker, adapter, _, _, identity = context_factory()
    if config.execution_mode != "DRY_RUN" or config.live_trading_enabled:
        raise RuntimeError(
            "recovery requires EXECUTION_MODE=DRY_RUN and LIVE_TRADING_ENABLED=false"
        )
    with tempfile.TemporaryDirectory(prefix="kb-qld-trader-recovery-") as directory:
        state_path = Path(directory) / "state.json"
        ledger_path = Path(directory) / "order_ledger.json"
        state_path.write_bytes(files["state.json"])
        ledger_path.write_bytes(files["order_ledger.json"])
        state_store = StateStore(state_path)
        ledger_store = OrderLedgerStore(ledger_path)
        state = state_store.load_state_strict()
        ledger = ledger_store.load_strict()
        backup_identity = dict(identity)
        stored_identity = state.get("installation_identity") or {}
        # Recovery may select a different final mode/time. All immutable identity
        # fields still come from current configuration and must match the backup.
        backup_identity["signal_mode"] = stored_identity.get("signal_mode")
        backup_identity["signal_time"] = stored_identity.get("signal_time")
        symbols_differ = any(stored_identity.get(k) != identity.get(k) for k in ("signal_symbol", "main_symbol", "safe_symbol"))
        if symbols_differ and allow_symbols:
            if ledger.get("active_workflow"):
                raise RuntimeError("ETF recovery blocked: active backup workflow")
            if any(o.get("status") not in {"FILLED", "CANCELED", "CANCELLED", "REJECTED"} for o in ledger.get("orders", [])) or broker.get_orders(status="OPEN"):
                raise RuntimeError("ETF recovery blocked: unresolved orders")
            for key in ("signal_symbol", "main_symbol", "safe_symbol"):
                backup_identity[key] = stored_identity.get(key)
        validate_restore_identity(state, manifest, backup_identity, str(config.kb_account_no or ""))
        active = ledger.get("active_workflow")
        if active:
            state_store.assert_identity_values(
                active.get("installation_identity") or {}, backup_identity,
            )

        portfolio = _portfolio(config, broker, adapter, identity)
        actual_account = state_store.account_snapshot(portfolio)
        for key in ("account_no", "account_binding"):
            if str(actual_account.get(key, "")).strip() != str(identity.get(key, "")).strip():
                raise RuntimeError(f"recovery broker account mismatch: {key}")
        result = WorkflowReconciler(ledger_store, broker).reconcile_active()
        if result.outcome == "READY_TO_COMMIT":
            active = ledger_store.load().get("active_workflow") or {}
            if ExecutionMode(str(active.get("execution_mode"))) != ExecutionMode.LIVE:
                raise RuntimeError("non-LIVE workflow may not advance state during recovery")
            WorkflowExecutor(None, ledger_store, adapter).commit_confirmed_state(
                state_store, portfolio,
            )
            result.outcome = "COMPLETED"
            result.message = "Broker-confirmed fills committed"
        if result.outcome == "BLOCKED":
            raise RuntimeError(f"workflow reconciliation blocked: {result.message}")
        if result.outcome not in {"CLEAN", "ABORTED", "DRY_RUN_CLEARED", "COMPLETED"}:
            raise RuntimeError(f"unexpected workflow reconciliation result: {result.outcome}")

        reconciled_state = state_store.load_state_strict()
        reconciled_ledger = ledger_store.load_strict()
        if reconciled_ledger.get("active_workflow"):
            raise RuntimeError("active workflow remains after reconciliation")
        # Make the recovered checkpoint valid for subsequent normal executions.
        # This recovery-only migration changes no strategy memory.
        reconciled_state["installation_identity"] = dict(identity)
        state_store.save_state(reconciled_state)
        if not (symbols_differ and allow_symbols):
            state_store.assert_reconciled(reconciled_state, portfolio, identity)
        else:
            # Never treat prior role snapshots as current-symbol holdings.
            reconciled_state["last_minute_decision"] = None
        # The backup snapshot is not current reality. Refresh it only after all
        # durable strategy and broker checks succeeded.
        reconciled_state["last_account_snapshot"] = state_store.account_snapshot(portfolio)
        state_store.save_state(reconciled_state)
        return (
            config, identity, portfolio, result,
            {"state.json": state_path.read_bytes(), "order_ledger.json": ledger_path.read_bytes()},
        )


def recover(
    archive: Path, context_factory=runtime_context, scheduler=None,
    root: Path = ROOT, values: Optional[Dict[str, str]] = None,
    recovery_choice: Optional[str] = None,
    input_fn: Callable[[str], str] = input,
):
    from app.storage import ProcessLock

    archive = archive.expanduser().resolve()
    files, manifest = verify_archive(archive)
    values = values if values is not None else read_env()
    if values.get("EXECUTION_MODE", "DRY_RUN") != "DRY_RUN" or values.get("LIVE_TRADING_ENABLED", "false").lower() != "false":
        raise RuntimeError("set EXECUTION_MODE=DRY_RUN and LIVE_TRADING_ENABLED=false before recovery")
    backup_signal = _backup_signal_identity(files)
    from config.config import SYMBOL_KEYS, SCHEDULE_KEYS, TRADING_BACKUP_KEYS, AppConfig
    settings = json.loads(files["trading_settings.json"]) if "trading_settings.json" in files else {}
    stored_identity = json.loads(files["state.json"]).get("installation_identity") or {}
    for key in SYMBOL_KEYS:
        if key in settings and settings[key].upper() != str(stored_identity.get(key.lower(), "")).upper():
            raise RuntimeError(f"backup settings/state symbol mismatch: {key}")
    updates = {k: v for k, v in settings.items() if k not in SYMBOL_KEYS + SCHEDULE_KEYS}
    try:
        from release_common import validate_bar_time_basis
    except ModuleNotFoundError:
        from scripts.release_common import validate_bar_time_basis
    if not str(values.get("KB_BAR_TIME_BASIS", "")).strip().strip("'\""):
        updates["KB_BAR_TIME_BASIS"] = "START_NY"
    validate_bar_time_basis(dict(values, **updates))
    if settings:
        different_symbols = [k for k in SYMBOL_KEYS if k in settings and values.get(k) != settings[k]]
        if different_symbols:
            print("[ETF 종목 설정 차이]\n설정                 현재       백업")
            for key in SYMBOL_KEYS:
                print(f"{key}: {values.get(key, '')} / {settings.get(key, '(누락)')}")
            if input_fn("백업의 종목 설정을 적용하시겠습니까? [y/N]: ").strip().lower() in {"y", "yes"}:
                updates.update({k: settings[k] for k in SYMBOL_KEYS if k in settings})
        different_times = [k for k in SCHEDULE_KEYS if k in settings and values.get(k) != settings[k]]
        selection = "CURRENT"
        if different_times:
            print("[거래시간 설정 차이]")
            for key in different_times:
                print(f"{key}: 현재 {values.get(key, '')} / 백업 {settings[key]}")
            if input_fn("백업 거래시간을 적용하시겠습니까? [y/N]: ").strip().lower() in {"y", "yes"}:
                updates.update({k: settings[k] for k in SCHEDULE_KEYS if k in settings})
                selection = "BACKUP"
        final_signal = {"signal_mode": updates.get("TRADING_SIGNAL_MODE", values.get("TRADING_SIGNAL_MODE")),
                        "signal_time": updates.get("SIGNAL_TIME", values.get("SIGNAL_TIME"))}
    else:
        print("오래된 백업: 거래 설정 데이터 없음; 현재 거래 설정을 유지합니다.")
        selection, final_signal = _choose_signal_recovery(backup_signal, values, recovery_choice, input_fn)
        if selection == "BACKUP":
            updates.update(TRADING_SIGNAL_MODE=final_signal["signal_mode"], SIGNAL_TIME=final_signal["signal_time"])
    final_values = dict(values)
    env_path = root / ".env"
    env_original = env_path.read_bytes() if env_path.exists() else None
    env_mode = env_path.stat().st_mode if env_path.exists() else None
    environment_original = {key: os.environ.get(key) for key in updates}
    env_changed = False
    final_values.update(updates)
    scheduler_needed = not settings or any(final_values.get(k) != values.get(k) for k in SCHEDULE_KEYS)
    scheduler = scheduler or RecoveryScheduler(root)
    state_path = root / "data" / "state.json"
    ledger_path = root / "data" / "order_ledger.json"
    originals = {
        state_path: state_path.read_bytes() if state_path.exists() else None,
        ledger_path: ledger_path.read_bytes() if ledger_path.exists() else None,
    }
    for name, path in (("trade_history.csv", root / "data" / "history" / "trade_history.csv"),
                       ("dry_run_validation.json", root / "data" / "dry_run_validation.json")):
        if name in files:
            originals[path] = path.read_bytes() if path.exists() else None
    placed = False
    scheduler_quiesced = False
    preserved = None
    recovery_lock = ProcessLock(root / "data" / "trader.lock")
    recovery_lock.__enter__()
    try:
        # Capture rollback bytes only after excluding the normal trader.
        originals = {path: path.read_bytes() if path.exists() else None for path in originals}
        if updates:
            # Reuse configuration validation before mutating any durable data.
            saved_environment = dict(os.environ)
            try:
                os.environ.update(final_values)
                if settings:
                    AppConfig.load()
                    try:
                        from setup_wizard import canonical_time
                    except ModuleNotFoundError:
                        from scripts.setup_wizard import canonical_time
                    if final_values.get("BACKUP_TIME"):
                        canonical_time(final_values["BACKUP_TIME"])
            finally:
                os.environ.clear()
                os.environ.update(saved_environment)
            _atomic_update_signal_env(env_path, updates)
            env_changed = True
            os.environ.update(updates)
        if hasattr(scheduler, 'needs_repair'):
            scheduler_needed = scheduler.needs_repair(final_values)
        if scheduler_needed:
            scheduler_quiesced = True
            scheduler.quiesce()
        config, identity, portfolio, reconciliation, recovered = _reconcile_temporary(
            files, manifest, context_factory, allow_symbols=bool(settings),
        )
        preserved = _preserve_local_pair(originals, root)
        with nullcontext():
            from app.storage import OrderLedgerStore
            if settings and state_path.exists():
                from app.storage import StateStore
                local_state = StateStore(state_path).load_state_strict()
                restored_state = json.loads(recovered["state.json"])
                if (local_state.get("last_execution_date") or "") > (restored_state.get("last_execution_date") or ""):
                    raise RuntimeError("local execution checkpoint is newer than backup; rollback of daily guard blocked")
            if settings and ledger_path.exists():
                local = OrderLedgerStore(ledger_path).load_strict()
                if local.get("active_workflow"):
                    raise RuntimeError("local unresolved workflow blocks overwrite during recovery")
                backed_ids = {o.get("client_order_id") for o in json.loads(recovered["order_ledger.json"]).get("orders", [])}
                if any(o.get("status") not in {"FILLED", "CANCELED", "CANCELLED", "REJECTED"}
                       or (o.get("status") == "FILLED" and o.get("record_kind") != "SIMULATED_INTENT"
                           and not str(o.get("broker_order_id", "")).startswith("SIM-")
                           and o.get("client_order_id") not in backed_ids)
                       for o in local.get("orders", [])):
                    raise RuntimeError("local orders are unresolved or newer than backup; automatic overwrite blocked")
            atomic_place_pair(
                state_path, ledger_path, recovered, allow_overwrite=True,
            )
            placed = True
            for name, path in (("trade_history.csv", root / "data" / "history" / "trade_history.csv"),
                               ("dry_run_validation.json", root / "data" / "dry_run_validation.json")):
                if name in files:
                    path.parent.mkdir(parents=True, exist_ok=True)
                    temporary = path.with_suffix(".restore-tmp")
                    content = files[name]
                    if name == "trade_history.csv" and originals[path]:
                        import csv
                        import io
                        current_rows = list(csv.reader(io.StringIO(originals[path].decode("utf-8-sig"))))
                        backup_rows = list(csv.reader(io.StringIO(content.decode("utf-8-sig"))))
                        if current_rows and backup_rows and current_rows[0] != backup_rows[0]:
                            raise RuntimeError("trade history columns differ; lossless automatic merge blocked")
                        merged = current_rows or backup_rows[:1]
                        from collections import Counter
                        existing_counts = Counter(tuple(row) for row in merged[1:])
                        for row in backup_rows[1:]:
                            if existing_counts[tuple(row)]:
                                existing_counts[tuple(row)] -= 1
                            else:
                                merged.append(row)
                        output = io.StringIO(newline="")
                        csv.writer(output).writerows(merged)
                        content = output.getvalue().encode("utf-8")
                    temporary.write_bytes(content)
                    os.replace(temporary, path)
        if scheduler_needed:
            schedule_report = scheduler.install(final_values)
            if hasattr(scheduler, "verify"):
                scheduler.verify(final_values)
        else:
            if hasattr(scheduler, 'verify'):
                scheduler.verify(final_values)
            try:
                from recovery_scheduler import SchedulerReport
            except ModuleNotFoundError:
                from scripts.recovery_scheduler import SchedulerReport
            schedule_report = scheduler.preserved_report(final_values) if hasattr(scheduler,'preserved_report') else SchedulerReport(getattr(scheduler, "platform", "existing"), "CURRENT_PRESERVED", "CURRENT_PRESERVED")
        return {
            "archive": archive.name,
            "identity": identity,
            "portfolio": portfolio,
            "reconciliation": reconciliation,
            "scheduler": schedule_report,
            "local_backup": preserved,
            "signal_recovery": selection,
            "signal_mode": final_signal["signal_mode"],
            "signal_time": final_signal["signal_time"],
        }
    except Exception:
        try:
            if placed:
                _restore_originals(originals)
        finally:
            try:
                if scheduler_quiesced:
                    scheduler.rollback()
            except Exception as rollback_error:
                print(f"스케줄러 롤백 실패: {rollback_error}. DRY_RUN/LIVE 차단을 유지하고 수동 점검하십시오.")
            if env_changed:
                if env_original is None:
                    env_path.unlink(missing_ok=True)
                else:
                    rollback = env_path.with_suffix(env_path.suffix + ".recovery-rollback")
                    rollback.write_bytes(env_original)
                    if env_mode is not None:
                        os.chmod(rollback, env_mode)
                    os.replace(rollback, env_path)
                for key, value in environment_original.items():
                    if value is None:
                        os.environ.pop(key, None)
                    else:
                        os.environ[key] = value
        raise
    finally:
        recovery_lock.__exit__(None, None, None)


def main() -> None:
    parser = argparse.ArgumentParser(
        usage="./recover_backup.sh /path/to/kb-qld-trader-backup-YYYYMMDD-HHMMSS-UTC.tar.gz",
    )
    parser.add_argument("archive")
    args = parser.parse_args()
    archive = Path(args.archive).expanduser()
    if archive.is_dir():
        candidates = sorted(archive.glob("kb-qld-trader-backup-*.tar.gz"), key=lambda p: p.stat().st_mtime, reverse=True)
        if not candidates:
            parser.error("no backup archive found in directory")
        for number, candidate in enumerate(candidates, 1):
            print(f"[{number}] {candidate.name}")
        if len(candidates) == 1:
            archive = candidates[0]
        else:
            choice = input("복구할 백업 번호: ").strip()
            if not choice.isdigit() or not 1 <= int(choice) <= len(candidates):
                parser.error("invalid backup selection")
            archive = candidates[int(choice) - 1]
    if not archive.is_file() or not archive.name.endswith(".tar.gz"):
        parser.error("an existing .tar.gz backup file is required")
    report = recover(archive)
    scheduler = report["scheduler"]
    print("Recovery completed successfully.\n")
    print(f"Backup:\n{report['archive']}\n")
    print("Strategy state restore: OK")
    print("Ledger restore: OK")
    print("Installation identity: OK")
    mode_label = "backup restored" if report["signal_recovery"] == "BACKUP" else "current preserved"
    print(f"Trading method: {report['signal_mode']} / {report['signal_time']} ({mode_label})")
    print("KB account connection: OK")
    print("Portfolio reconciliation: OK")
    print(f"Workflow reconciliation: OK ({report['reconciliation'].outcome})\n")
    portfolio = report["portfolio"]
    print("Current KB portfolio:")
    print(f"MAIN quantity: {portfolio.main_quantity} (average: {portfolio.main_avg_price})")
    print(f"SAFE quantity: {portfolio.safe_quantity}")
    print(f"Available USD cash: {portfolio.available_cash_usd}\n")
    print("Scheduler:")
    print(f"Trading schedule: {scheduler.trading}")
    print(f"Backup schedule: {scheduler.backup}")
    if scheduler.platform == "termux":
        print(f"Public IP monitor: {scheduler.public_ip_monitor}")
        print(f"Termux Boot: {scheduler.termux_boot}")
        print(f"crond: {scheduler.crond}")
        print('Boot 스크립트 구성은 확인했으며, Termux:Boot Android 앱·배터리 예외·Wake Lock은 기기에서 확인하세요.')
    print("\nTrading state:\nLIVE_TRADING_ENABLED=false")
    print(f"Pre-recovery local backup: {report['local_backup']}")
    print("\nReview the result and enable LIVE trading only when ready.")


if __name__ == "__main__":
    main()
