"""Refresh this host's KB scheduler; direct script invocation is supported."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))

try:
    from recovery_scheduler import RecoveryScheduler
    from release_common import ROOT, read_env
except ModuleNotFoundError:
    from scripts.recovery_scheduler import RecoveryScheduler
    from scripts.release_common import ROOT, read_env


def main() -> None:
    from app.storage import ProcessLock
    values=read_env()
    scheduler=RecoveryScheduler(ROOT)
    with ProcessLock(ROOT/'data/trader.lock'):
        if not scheduler.needs_repair(values):
            print('KB scheduler: CURRENT_PRESERVED ('+scheduler.platform+')')
            return
        try:
            scheduler.quiesce()
            report=scheduler.install(values)
            scheduler.verify(values)
        except Exception:
            try:
                scheduler.rollback()
            except Exception as rollback_error:
                print('Scheduler rollback incomplete; manual review required: '+str(rollback_error))
            raise
    print('KB scheduler verified: '+str(report))
    if scheduler.platform=='termux':
        print('Termux:Boot Android 앱 설치 및 배터리 예외/Wake Lock은 기기에서 확인하세요.')


if __name__ == '__main__':
    main()
