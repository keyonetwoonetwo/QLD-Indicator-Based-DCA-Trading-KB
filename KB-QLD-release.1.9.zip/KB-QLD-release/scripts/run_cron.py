#!/usr/bin/env python3
"""Run the common trader entrypoint from Termux cron with bounded logs."""
import subprocess
import time
from datetime import datetime
from zoneinfo import ZoneInfo
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAX_LOG_BYTES = 5 * 1024 * 1024


def rotate_log(path: Path) -> None:
    if path.exists() and path.stat().st_size >= MAX_LOG_BYTES:
        rotated = path.with_suffix(path.suffix + ".1")
        rotated.unlink(missing_ok=True)
        path.replace(rotated)


def main() -> int:
    if len(sys.argv) != 2 or sys.argv[1] not in {"minute", "close"}:
        raise SystemExit("usage: run_cron.py minute|close")
    if sys.argv[1] == "minute":
        second = datetime.now(ZoneInfo("America/New_York")).second
        if second < 10:
            time.sleep(10 - second)
    log_dir = ROOT / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / f"cron-{sys.argv[1]}.log"
    rotate_log(log_path)
    with log_path.open("ab") as log:
        return subprocess.run([str(ROOT / "run.sh")], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=False).returncode


if __name__ == "__main__":
    raise SystemExit(main())
