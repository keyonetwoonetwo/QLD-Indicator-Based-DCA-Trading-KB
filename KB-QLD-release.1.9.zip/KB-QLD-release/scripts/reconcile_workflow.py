#!/usr/bin/env python3
"""Official operator workflow reconciliation command; never submits orders."""
import os
from decimal import Decimal

try:
    from release_common import ROOT, runtime_context
except ModuleNotFoundError:
    from scripts.release_common import ROOT, runtime_context


def _portfolio(config, broker, adapter, identity):
    profile = config.resolved_strategy()
    raw_prices = broker.get_prices([profile.main_symbol, profile.safe_symbol])
    prices = {
        item["symbol"]: Decimal(str(item["lastPrice"]))
        for item in raw_prices
        if item.get("symbol") and item.get("lastPrice") is not None
    }
    return adapter.get_portfolio_state(
        identity["account_binding"], identity["account_no"], prices,
        profile.main_symbol, profile.safe_symbol,
    )


def _commit_ready_live(result, active, executor_factory, state_store, portfolio):
    """Commit broker-confirmed state only for a persisted LIVE workflow."""
    from app.models.common import ExecutionMode

    if result.outcome != "READY_TO_COMMIT":
        return False
    mode = ExecutionMode(str(active["execution_mode"]))
    if mode != ExecutionMode.LIVE:
        result.outcome = "BLOCKED"
        result.message = "Non-LIVE workflow may not advance strategy state during reconciliation"
        return False
    executor_factory(mode).commit_confirmed_state(state_store, portfolio)
    result.outcome = "COMPLETED"
    result.message = "Broker-confirmed fills committed and active workflow closed"
    return True


def main() -> int:
    os.chdir(ROOT)
    from app.execution import OrderManager, WorkflowExecutor, WorkflowReconciler
    from app.notification import TelegramNotifier
    from app.storage import ProcessLock

    config, broker, adapter, state_store, ledger_store, identity = runtime_context()
    notifier = TelegramNotifier(config.telegram_bot_token, config.telegram_chat_id, config.telegram_enabled)
    with ProcessLock(config.storage.process_lock_file):
        state = state_store.load_state_strict()
        ledger = ledger_store.load_strict()
        active = ledger.get("active_workflow")
        if active and not WorkflowReconciler.is_qld_workflow(active):
            WorkflowReconciler.assert_legacy_account(active, state, identity)
        else:
            state_store.assert_installation_identity(state, identity)
        if active and WorkflowReconciler.is_qld_workflow(active):
            state_store.assert_identity_values(
                active.get("installation_identity") or {}, identity,
            )

        portfolio = _portfolio(config, broker, adapter, identity)
        profile = config.resolved_strategy()
        print("현재 KB portfolio")
        print(f"- MAIN {profile.main_symbol}: {portfolio.main_quantity} (avg {portfolio.main_avg_price})")
        print(f"- SAFE {profile.safe_symbol}: {portfolio.safe_quantity}")
        print(f"- available USD cash: {portfolio.available_cash_usd}")

        result = WorkflowReconciler(ledger_store, broker).reconcile_active()
        print(f"workflow: {result.workflow_id or 'NONE'}")
        for order in result.orders:
            print(
                f"- {order.get('symbol')} orderId={order.get('broker_order_id')} "
                f"requested={order.get('requested_quantity')} filled={order.get('filled_quantity')} "
                f"avg={order.get('average_filled_price')} status={order.get('broker_status')} "
                f"canceled={order.get('canceled')}"
            )

        if result.outcome == "READY_TO_COMMIT":
            active = ledger_store.load()["active_workflow"]
            _commit_ready_live(
                result, active,
                lambda mode: WorkflowExecutor(OrderManager(broker, mode), ledger_store, adapter),
                state_store, portfolio,
            )

        message = f"Workflow reconciliation {result.outcome}: {result.workflow_id or 'NONE'} - {result.message}"
        if result.outcome == "BLOCKED":
            notifier.notify_warning(message)
            print(message)
            return 2
        notifier.send_message(message)
        print(message)
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
