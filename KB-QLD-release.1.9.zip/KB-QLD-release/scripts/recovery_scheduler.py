"""Transactional reuse of the existing Linux/Termux scheduler installers."""
from dataclasses import dataclass
from pathlib import Path
import os
import subprocess
import tempfile
from typing import Dict, Optional

try:
    from platform_deploy import (
        install_termux_boot, install_termux_cron, replace_marker_block,
        selected_platform, validate_termux_runtime,
        cron_block, marker_spans, read_crontab, write_crontab, BOOT_CONTENT, BEGIN, END,
    )
    from setup_wizard import enable_timer, service_unit, timer_unit, trading_schedule
    from release_common import ROOT
except ModuleNotFoundError:
    from scripts.platform_deploy import (
        install_termux_boot, install_termux_cron, replace_marker_block,
        selected_platform, validate_termux_runtime,
        cron_block, marker_spans, read_crontab, write_crontab, BOOT_CONTENT, BEGIN, END,
    )
    from scripts.setup_wizard import enable_timer, service_unit, timer_unit, trading_schedule
    from scripts.release_common import ROOT
from config.defaults import DEFAULT_BACKUP_TIME, NY_ZONE


LINUX_UNITS = (
    "kb-qld-trader.service", "kb-qld-trader.timer",
    "kb-qld-trader-backup.service", "kb-qld-trader-backup.timer",
)


def backup_enabled(values: Dict[str, str]) -> bool:
    chat = values.get("TELEGRAM_BACKUP_CHAT_ID", "").strip() or values.get("TELEGRAM_ALERT_CHAT_ID", "").strip()
    return (
        values.get("TELEGRAM_ENABLED", "false").lower() == "true"
        and bool(values.get("TELEGRAM_BOT_TOKEN", "").strip()) and bool(chat)
    )


@dataclass
class SchedulerReport:
    platform: str
    trading: str = "NOT_INSTALLED"
    backup: str = "DISABLED"
    public_ip_monitor: str = "NOT_APPLICABLE"
    termux_boot: str = "NOT_APPLICABLE"
    crond: str = "NOT_APPLICABLE"


class RecoveryScheduler:
    """Quiesce before recovery, install after reconcile, and rollback on error."""

    def __init__(self, root: Path = ROOT, run=subprocess.run, unit_root=None, home=None):
        self.root = root
        self.run = run
        self.platform = selected_platform(root)
        self.unit_root=Path(unit_root) if unit_root is not None else Path('/etc/systemd/system')
        self.home=Path(home) if home is not None else Path.home()
        self._repair=None
        self._touched=set()
        self._cron: Optional[str] = None
        self._boot_existed = False
        self._boot_contents: Optional[bytes] = None
        self._boot_captured = False
        self._linux_units: Dict[str, Optional[bytes]] = {}
        self._linux_enabled = False
        self._linux_active = False
        self._linux_timer_states = {}
        self._boot_mode=0o700

    def _spec(self,values):
        _,_,schedule=trading_schedule(values)
        backup_time=values.get('BACKUP_TIME',DEFAULT_BACKUP_TIME).strip() or DEFAULT_BACKUP_TIME
        return {
            'trade':('kb-qld-trader.service','kb-qld-trader.timer',
                service_unit(self.root,'kb-qld-trader.service','run.sh','KB QLD Trader one-shot run'),
                timer_unit('Schedule KB QLD Trader one-shot run',schedule,'kb-qld-trader.service')),
            'backup':('kb-qld-trader-backup.service','kb-qld-trader-backup.timer',
                service_unit(self.root,'kb-qld-trader-backup.service','backup.sh','KB QLD Trader state backup'),
                timer_unit('Schedule KB QLD Trader state backup',f'*-*-* {backup_time} {NY_ZONE}','kb-qld-trader-backup.service'))}

    def needs_repair(self,values):
        """Read only this platform's real KB installation, never backup metadata."""
        repair=set()
        if self.platform=='termux':
            actual=read_crontab(self.run)
            spans=marker_spans(actual)
            backup_time=values.get('BACKUP_TIME',DEFAULT_BACKUP_TIME).strip() or DEFAULT_BACKUP_TIME
            expected=cron_block(self.root,values,backup_enabled(values),backup_time)
            if len(spans)!=1 or actual[spans[0][0]:spans[0][1]]!=expected:
                repair.add('cron')
            boot=self.home/'.termux/boot/start-kb-qld-trader'
            if not boot.is_file() or boot.read_bytes()!=BOOT_CONTENT.encode() or not os.access(boot,os.X_OK):
                repair.add('boot')
            if self.run(['pgrep','-x','crond'],capture_output=True).returncode!=0:
                repair.add('daemon')
        elif self.platform=='linux':
            for role,spec in self._spec(values).items():
                if role=='backup' and not backup_enabled(values):
                    if any(self.run(['systemctl',test,spec[1]],capture_output=True).returncode==0 for test in ('is-enabled','is-active')):
                        repair.add('backup_off')
                    continue
                if any(not (self.unit_root/name).is_file() or (self.unit_root/name).read_text()!=contents
                       for name,contents in zip(spec[:2],spec[2:])):
                    repair.add(role)
                else:
                    for name in spec[:2]:
                        loaded=self.run(['systemctl','show',name,'-p','DropInPaths','-p','NeedDaemonReload'],capture_output=True,text=True)
                        if loaded.returncode!=0:
                            raise RuntimeError('Cannot inspect loaded KB systemd unit; scheduler unchanged')
                        properties=dict(line.split('=',1) for line in loaded.stdout.splitlines() if '=' in line)
                        if properties.get('DropInPaths','').strip():
                            raise RuntimeError('KB systemd unit has external drop-ins; manual review required')
                        if properties.get('NeedDaemonReload')=='yes': repair.add(role)
                    status=self.run(['systemctl','show',spec[1],'-p','AccuracyUSec','-p','RandomizedDelayUSec'],capture_output=True,text=True)
                    if status.returncode!=0:
                        raise RuntimeError('Cannot inspect KB systemd timer; scheduler unchanged')
                    if set(status.stdout.splitlines())!={'AccuracyUSec=1s','RandomizedDelayUSec=0'}:
                        repair.add(role)
        else:
            raise RuntimeError('Unsupported scheduler platform')
        self._repair=repair
        return bool(repair)

    def preserved_report(self,values):
        return SchedulerReport(self.platform,'CURRENT_PRESERVED',
            'CURRENT_PRESERVED' if backup_enabled(values) else 'DISABLED',
            'CURRENT_PRESERVED' if self.platform=='termux' else 'NOT_APPLICABLE',
            'CURRENT_PRESERVED' if self.platform=='termux' else 'NOT_APPLICABLE',
            'RUNNING' if self.platform=='termux' else 'NOT_APPLICABLE')

    def quiesce(self) -> None:
        if self.platform == "termux":
            validate_termux_runtime()
            self._touched=set(self._repair if self._repair is not None else {'cron','boot','daemon'})
            self._cron=read_crontab(self.run)
            boot = self.home / ".termux" / "boot" / "start-kb-qld-trader"
            self._boot_existed = boot.exists()
            self._boot_contents = boot.read_bytes() if boot.exists() else None
            self._boot_mode=boot.stat().st_mode & 0o777 if boot.exists() else 0o700
            self._boot_captured = True
            # Keep the KB block's position so restoring CRON_TZ does not move
            # it across unrelated user jobs after recovery.
            placeholder=BEGIN+'\n'+END+'\n' if marker_spans(self._cron) else ''
            cleaned = replace_marker_block(self._cron, placeholder)
            if 'cron' in self._touched and cleaned!=self._cron: write_crontab(cleaned,self.run)
            return

        self._touched=set(self._repair if self._repair is not None else {'trade','backup'})
        unit_root = self.unit_root
        self._linux_units = {
            name: (unit_root / name).read_bytes() if (unit_root / name).exists() else None
            for name in LINUX_UNITS
        }
        self._linux_enabled = self.run(
            ["systemctl", "is-enabled", "kb-qld-trader.timer"], capture_output=True, text=True,
        ).returncode == 0
        self._linux_active = self.run(
            ["systemctl", "is-active", "kb-qld-trader.timer"], capture_output=True, text=True,
        ).returncode == 0
        self._linux_timer_states["kb-qld-trader.timer"] = (self._linux_enabled, self._linux_active)
        backup_timer = "kb-qld-trader-backup.timer"
        self._linux_timer_states[backup_timer] = (
            self.run(["systemctl", "is-enabled", backup_timer], capture_output=True, text=True).returncode == 0,
            self.run(["systemctl", "is-active", backup_timer], capture_output=True, text=True).returncode == 0,
        )
        for name in self._linux_timer_states:
            role='backup' if 'backup' in name else 'trade'
            if (role in self._touched or role+'_off' in self._touched) and self._linux_units.get(name) is not None:
                self.run(["sudo", "systemctl", "disable", "--now", name], check=True, text=True)

    def install(self, values: Dict[str, str]) -> SchedulerReport:
        if self._repair==set() and not self._touched:
            return self.preserved_report(values)
        enabled = backup_enabled(values)
        backup_time = values.get("BACKUP_TIME", DEFAULT_BACKUP_TIME).strip() or DEFAULT_BACKUP_TIME
        _, _, schedule = trading_schedule(values)
        if self.platform == "termux":
            repair=self._touched or self._repair or {'cron','boot','daemon'}
            if 'cron' in repair: install_termux_cron(self.root, values, enabled, backup_time,run=self.run)
            if 'boot' in repair: install_termux_boot(self.root,self.home)
            if self.run(['pgrep','-x','crond'],capture_output=True).returncode!=0:
                self.run(["sh", "-c", "pgrep -x crond >/dev/null 2>&1 || crond"], check=True, text=True)
            if self.run(['pgrep','-x','crond'],capture_output=True).returncode!=0:
                raise RuntimeError('crond is not running; Termux scheduler installation incomplete')
            return SchedulerReport(
                "termux", "INSTALLED", "INSTALLED" if enabled else "DISABLED",
                "INSTALLED", "INSTALLED", "RUNNING",
            )

        repair=self._touched or self._repair
        if enabled and (repair is None or 'backup' in repair):
            enable_timer(
                "kb-qld-trader-backup.service", "kb-qld-trader-backup.timer",
                service_unit(self.root, "kb-qld-trader-backup.service", "backup.sh", "KB QLD Trader state backup"),
                timer_unit("Schedule KB QLD Trader state backup", f"*-*-* {backup_time} {NY_ZONE}", "kb-qld-trader-backup.service"),
            )
        if repair is None or 'trade' in repair:
            enable_timer(
            "kb-qld-trader.service", "kb-qld-trader.timer",
            service_unit(self.root, "kb-qld-trader.service", "run.sh", "KB QLD Trader one-shot run"),
            timer_unit("Schedule KB QLD Trader one-shot run", schedule, "kb-qld-trader.service"),
            )
        # Preserve intentional disabled/inactive states of existing timers.
        for name,(was_enabled,was_active) in self._linux_timer_states.items():
            role='backup' if 'backup' in name else 'trade'
            if repair and role in repair and self._linux_units.get(name) is not None:
                self.run(['sudo','systemctl','enable' if was_enabled else 'disable',name],check=True,text=True)
                self.run(['sudo','systemctl','start' if was_active else 'stop',name],check=True,text=True)
        return SchedulerReport('linux','INSTALLED' if repair is None or 'trade' in repair else 'CURRENT_PRESERVED',
            ('INSTALLED' if repair is None or 'backup' in repair else 'CURRENT_PRESERVED') if enabled else 'DISABLED')

    def rollback(self) -> None:
        if self.platform == "termux":
            errors=[]
            try:
                if self._cron is not None:
                    current=read_crontab(self.run)
                    original_other=replace_marker_block(self._cron,'')
                    current_other=replace_marker_block(current,'')
                    restored=self._cron if current_other==original_other else replace_marker_block(current,''.join(self._cron[a:b] for a,b in marker_spans(self._cron)))
                    if current!=restored: write_crontab(restored,self.run)
            except Exception:
                errors.append('crontab')
            try:
                boot = self.home / ".termux" / "boot" / "start-kb-qld-trader"
                if 'boot' in self._touched and self._boot_existed and self._boot_contents is not None:
                    boot.parent.mkdir(parents=True, exist_ok=True)
                    boot.write_bytes(self._boot_contents)
                    boot.chmod(self._boot_mode)
                elif 'boot' in self._touched and self._boot_captured and not self._boot_existed:
                    boot.unlink(missing_ok=True)
            except Exception:
                errors.append('Termux Boot')
            if errors:
                raise RuntimeError('Termux rollback incomplete; manual review required: '+', '.join(errors))
            return

        errors=[]
        def attempt(args,label):
            try:
                self.run(args,check=True,text=True)
            except Exception:
                errors.append(label)
        for name in self._linux_timer_states:
            role='backup' if 'backup' in name else 'trade'
            if (role in self._touched or role+'_off' in self._touched) and self._linux_units.get(name) is None and (self.unit_root/name).exists():
                attempt(['sudo','systemctl','disable','--now',name],name+' disable')
        for name,contents in self._linux_units.items():
            role='backup' if 'backup' in name else 'trade'
            if role not in self._touched and role+'_off' not in self._touched: continue
            target=str(self.unit_root/name)
            if contents is None:
                attempt(['sudo','rm','-f',target],name+' remove')
            else:
                temporary=None
                try:
                    with tempfile.NamedTemporaryFile('wb',delete=False) as handle:
                        handle.write(contents); temporary=handle.name
                    attempt(['sudo','install','-m','0644',temporary,target],name+' restore')
                except Exception:
                    errors.append(name+' restore')
                finally:
                    if temporary is not None: Path(temporary).unlink(missing_ok=True)
        attempt(['sudo','systemctl','daemon-reload'],'daemon-reload')
        for name,(enabled,active) in self._linux_timer_states.items():
            role='backup' if 'backup' in name else 'trade'
            if role not in self._touched and role+'_off' not in self._touched: continue
            if self._linux_units.get(name) is None and not enabled and not active: continue
            attempt(['sudo','systemctl','enable' if enabled else 'disable',name],name+' enabled state')
            attempt(['sudo','systemctl','start' if active else 'stop',name],name+' active state')
        if errors:
            raise RuntimeError('systemd rollback incomplete; manual review required: '+', '.join(errors))

    def verify(self, values: Dict[str, str]) -> None:
        """Never report success before cron/Boot/daemon or both units agree."""
        if self.needs_repair(values):
            kind='cron differs or Boot/crond incomplete' if self.platform=='termux' else 'systemd differs'
            raise RuntimeError('installed '+kind+': '+', '.join(sorted(self._repair)))
