#!/usr/bin/env python3
"""Safe LIVE disable: refuse to create a mode-mismatched active workflow."""
from release_common import ROOT, read_env, write_env


def main() -> None:
    values = read_env()
    # This only reads local durable state; no broker mutation or network call is performed.
    import os
    os.chdir(ROOT)
    from config.config import AppConfig
    from app.storage import OrderLedgerStore
    config = AppConfig.load()
    ledger_store = OrderLedgerStore(config.storage.order_ledger_file)
    ledger = ledger_store.load_strict()
    if ledger.get("active_workflow"):
        raise RuntimeError("active workflow가 있습니다. 현재 실행 모드에서 먼저 복구해야 하므로 LIVE 해제를 중단합니다.")
    values["EXECUTION_MODE"] = "DRY_RUN"
    values["LIVE_TRADING_ENABLED"] = "false"
    write_env(values, backup=True)
    print("LIVE가 해제되었습니다. 이후 실행은 DRY_RUN입니다.")


if __name__ == "__main__":
    main()
