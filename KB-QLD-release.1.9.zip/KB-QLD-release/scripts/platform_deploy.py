"""Platform-specific deployment helpers; trading execution stays in run.sh."""
from datetime import datetime, timedelta
from pathlib import Path
import os
import re
import shutil
import subprocess
import sys
from config.defaults import DEFAULT_BACKUP_TIME, NY_ZONE, SEOUL_ZONE

BEGIN = "# BEGIN KB-QLD-TRADER"
END = "# END KB-QLD-TRADER"
BOOT_CONTENT = "#!/data/data/com.termux/files/usr/bin/sh\npgrep -x crond >/dev/null 2>&1 || crond\n"
def _cron_time(value: str, *, next_minute: bool = False) -> tuple[int, int, str]:
    """Return cron minute/hour/weekdays for an NY wall-clock setting."""
    try:
        parsed = datetime.strptime(value, "%H:%M:%S")
    except (TypeError, ValueError) as exc:
        raise RuntimeError(f"잘못된 scheduler 시각: {value!r}; HH:MM:SS 형식이어야 합니다.") from exc
    if next_minute:
        original_date = parsed.date()
        parsed += timedelta(minutes=1)
        weekdays = "2-6" if parsed.date() != original_date else "1-5"
    else:
        weekdays = "1-5"
    return parsed.minute, parsed.hour, weekdays


def selected_platform(root: Path) -> str:
    # Metadata may have travelled with a WSL/Termux backup; inspect this host.
    if os.environ.get('INSTALL_PLATFORM','').strip() not in {'','linux','termux'}:
        raise RuntimeError('Unsupported INSTALL_PLATFORM; scheduler unchanged')
    prefix=os.environ.get('PREFIX','')
    if prefix.startswith('/data/data/com.termux/') or re.match(r'/data/user/\d+/com\.termux/',prefix):
        validate_termux_runtime()
        return 'termux'
    if sys.platform.startswith('linux') and Path('/run/systemd/system').is_dir():
        for command in ('systemctl','sudo','install'):
            if not shutil.which(command): raise RuntimeError('Required systemd command unavailable: '+command)
        return 'linux'
    raise RuntimeError('Unsupported execution environment: require running systemd or native Termux; scheduler unchanged')


def cron_block(root: Path, values: dict, backup_enabled: bool, backup_time: str = DEFAULT_BACKUP_TIME) -> str:
    root_text = root.as_posix()
    backup_path = "'" + f"{root_text}/backup.sh".replace("'", "'\\''") + "'"
    python_path = "'" + f"{root_text}/.venv/bin/python".replace("'", "'\\''") + "'"
    monitor_path = "'" + f"{root_text}/scripts/check_public_ip.py".replace("'", "'\\''") + "'"
    cron_runner_path = "'" + f"{root_text}/scripts/run_cron.py".replace("'", "'\\''") + "'"
    mode = values.get("TRADING_SIGNAL_MODE", "MINUTE").upper()
    if mode == "MINUTE":
        minute, hour, weekdays = _cron_time(values.get("SIGNAL_TIME", ""), next_minute=True)
        trade = f"{minute} {hour} * * {weekdays} {python_path} {cron_runner_path} minute"
        trade_early = f"{minute} {hour - 3} * * {weekdays} {python_path} {cron_runner_path} minute"
    else:
        raise RuntimeError(f"지원하지 않는 TRADING_SIGNAL_MODE: {mode}")
    lines = [BEGIN, f"CRON_TZ={NY_ZONE}", trade_early, trade]
    if backup_enabled:
        hour, minute, _ = backup_time.split(":")
        lines.append(f"{int(minute)} {int(hour)} * * * {backup_path}")
    lines.extend([f"CRON_TZ={SEOUL_ZONE}", f"0 22 * * * {python_path} {monitor_path}"])
    lines.append(END)
    return "\n".join(lines) + "\n"


def replace_marker_block(existing: str, block: str) -> str:
    spans=marker_spans(existing)
    if not spans:
        return existing + ('\n' if existing and not existing.endswith('\n') and block else '') + block
    parts=[]; last=0
    for index,(start,end) in enumerate(spans):
        parts.append(existing[last:start])
        if index==0: parts.append(block)
        last=end
    parts.append(existing[last:])
    return ''.join(parts)


def marker_spans(existing: str):
    spans=[]; start=None; offset=0
    for line in existing.splitlines(keepends=True):
        if line.strip()==BEGIN:
            if start is not None: raise RuntimeError('Nested KB cron marker; manual review required')
            start=offset
        elif line.strip()==END:
            if start is None: raise RuntimeError('Unmatched KB cron marker; manual review required')
            spans.append((start,offset+len(line))); start=None
        offset+=len(line)
    if start is not None: raise RuntimeError('Unterminated KB cron marker; manual review required')
    return spans


def read_crontab(run=subprocess.run):
    result=run(['crontab','-l'],capture_output=True)
    if result.returncode==0:
        return result.stdout.decode('utf-8') if isinstance(result.stdout,bytes) else result.stdout
    error=result.stderr.decode('utf-8',errors='replace') if isinstance(result.stderr,bytes) else (result.stderr or '')
    if 'no crontab' in error.lower(): return ''
    raise RuntimeError('Existing crontab unavailable; scheduler unchanged')


def write_crontab(contents,run=subprocess.run):
    run(['crontab','-'],input=contents.encode('utf-8'),check=True)


def install_termux_cron(root: Path, values: dict, backup_enabled: bool, backup_time: str = DEFAULT_BACKUP_TIME, run=None) -> None:
    (root / "logs").mkdir(parents=True, exist_ok=True)
    run=run or subprocess.run
    current=read_crontab(run)
    updated = replace_marker_block(current, cron_block(root, values, backup_enabled, backup_time))
    if updated!=current: write_crontab(updated,run)


def install_termux_boot(root: Path, home: Path | None = None) -> Path:
    home = home or Path.home()
    target = home / ".termux" / "boot" / "start-kb-qld-trader"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(BOOT_CONTENT, encoding="utf-8",newline="")
    target.chmod(0o700)
    return target


def validate_termux_runtime() -> None:
    prefix = os.environ.get("PREFIX", "")
    if not (prefix.startswith("/data/data/com.termux/") or re.match(r"/data/user/\d+/com\.termux/", prefix)):
        raise RuntimeError("실제 Termux 환경이 아닙니다. 설치를 안전하게 중단합니다.")
    for command in ("crontab", "crond", "pgrep", "sh"):
        if not shutil.which(command):
            raise RuntimeError(f"필수 Termux 명령을 찾을 수 없습니다: {command}")
