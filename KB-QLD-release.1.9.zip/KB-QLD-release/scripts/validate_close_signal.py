#!/usr/bin/env python3
"""Read-only post-close validation of the last persisted MINUTE decision."""
import json
from decimal import Decimal

try:
    from release_common import ROOT, runtime_context
except ModuleNotFoundError:
    from scripts.release_common import ROOT, runtime_context

from app.market import IndicatorCalculator, MarketDataService


def main() -> None:
    config, broker, _adapter, state_store, _ledger, identity = runtime_context()
    state = state_store.load_state_strict()
    state_store.assert_installation_identity(state, identity)
    minute = state.get("last_minute_decision")
    if not isinstance(minute, dict) or not minute.get("market_date"):
        raise RuntimeError("No persisted MINUTE decision is available for CLOSE validation")

    market_date = str(minute["market_date"])
    profile = config.resolved_strategy()
    market = MarketDataService(broker)
    signal = market.fetch_daily_candles(profile.signal_symbol, config.strategy_rules.ma_period + 1)
    main_candles = market.fetch_daily_candles(profile.main_symbol, 2)
    market.assert_latest_daily_candle_confirmed(signal, market_date)
    market.assert_latest_daily_candle_confirmed(main_candles, market_date)
    indicators = IndicatorCalculator.calculate_indicators(
        signal, config.strategy_rules.ma_period, 0, profile.signal_symbol,
    )
    main = max(main_candles, key=lambda candle: candle.timestamp)
    regime = "RISK_ON" if indicators.current_close >= indicators.ma200 * Decimal(str(profile.risk_threshold)) else "RISK_OFF"
    direction = "GREEN" if main.close >= main.open else "RED"
    score = Decimal(str(minute["fear_greed_score"]))
    low = config.trading.fear_greed_low_threshold
    high = config.trading.fear_greed_high_threshold
    band = "FG_LOW" if score < low else "FG_MID" if score < high else "FG_HIGH"
    key = f"{regime}_{direction}_{band}_USD"
    amount = config.trading.buy_amounts[key]
    result = {
        "market_date": market_date,
        "regime": regime,
        "main_direction": direction,
        "fear_greed_band": band,
        "fear_greed_score": str(score),
        "condition_key": key,
        "amount_usd": str(amount),
        "matches_minute": key == minute.get("condition_key") and str(amount) == str(minute.get("configured_amount")),
        "trading_enabled": False,
    }
    output = ROOT / "data" / "history" / f"close_validation_{market_date}.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(".tmp")
    temporary.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    temporary.replace(output)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
