#!/usr/bin/env python3
"""Interactive creation of a secret-safe .env file."""
from decimal import Decimal, InvalidOperation
from getpass import getpass
from pathlib import Path
try:
    from release_common import ENV_PATH, ROOT, read_env, write_env
except ModuleNotFoundError:
    from scripts.release_common import ENV_PATH, ROOT, read_env, write_env
from config.config import AMOUNT_KEYS, AppConfig, MinuteConfig, StrategyConfig, TradingConfig, normalize_kb_account_no
from config.defaults import DEFAULT_BACKUP_TIME


def ask_symbol(label: str, default: str) -> str:
    value = (input(f"{label} [{default}]: ").strip() or default).upper()
    if not value or any(ch in value for ch in "=\n\r"):
        raise ValueError(f"{label} must be a non-empty symbol")
    return value


def ask_decimal(label: str, default: str = "", allow_zero: bool = False) -> str:
    suffix = f" [{default}]" if default != "" else ""
    value = input(f"{label}{suffix}: ").strip() or default
    try:
        parsed = Decimal(value)
        if not parsed.is_finite() or parsed < 0 or (parsed == 0 and not allow_zero):
            raise ValueError
    except (InvalidOperation, ValueError):
        qualifier = "non-negative" if allow_zero else "positive"
        raise ValueError(f"{label} must be a finite {qualifier} Decimal")
    return value


def ask_yes_no(label: str) -> bool:
    value = input(f"{label} [y/N]: ").strip().lower()
    return value in {"y", "yes"}


def ask_yes_no_default_yes(label: str) -> bool:
    value = input(f"{label} [Y/n]: ").strip().lower()
    return value not in {"n", "no"}


def main() -> None:
    app_defaults = AppConfig()
    strategy_defaults = StrategyConfig()
    trading_defaults = TradingConfig()
    minute_defaults = MinuteConfig()
    old_values = read_env() if ENV_PATH.exists() else None
    if old_values is not None and not ask_yes_no("기존 .env가 있습니다. 백업 후 덮어쓰시겠습니까?"):
        raise SystemExit("변경된 파일이 없습니다.")
    print("모든 신호 시각은 America/New_York 기준입니다. 설치는 항상 DRY_RUN으로 시작합니다.")
    mode = "MINUTE"
    print("실행 방식 TRADING_SIGNAL_MODE: MINUTE (CLOSE는 사후 검증 전용)")
    signal_time = input(f"신호 시각 SIGNAL_TIME [HH:MM:SS, {app_defaults.strategy.signal_time}]: ").strip() or app_defaults.strategy.signal_time
    from datetime import time
    import re
    if not re.fullmatch(r"\d{2}:\d{2}:\d{2}", signal_time):
        raise ValueError("SIGNAL_TIME은 정확한 HH:MM:SS 형식이어야 합니다.")
    time.fromisoformat(signal_time)
    AppConfig._validate_minute_timing(signal_time, minute_defaults)
    signal_symbol = ask_symbol("SIGNAL_SYMBOL", app_defaults.strategy.signal_symbol)
    main_symbol = ask_symbol("MAIN_SYMBOL", app_defaults.strategy.main_symbol)
    safe_symbol = ask_symbol("SAFE_SYMBOL", app_defaults.strategy.safe_symbol)
    risk_threshold = ask_decimal("RISK_THRESHOLD", "1")
    fg_low = ask_decimal("CNN Fear & Greed 낮음 구간 상한", str(trading_defaults.fear_greed_low_threshold), allow_zero=True)
    fg_high = ask_decimal("CNN Fear & Greed 중간 구간 상한", str(trading_defaults.fear_greed_high_threshold), allow_zero=True)
    if Decimal(fg_low) >= Decimal(fg_high):
        raise ValueError("CNN Fear & Greed 낮음 구간 상한은 중간 구간 상한보다 작아야 합니다.")
    cash_multiplier = ask_decimal("SAFE 목표현금 배수", str(trading_defaults.cash_target_multiplier))
    values = {
        "EXECUTION_MODE": "DRY_RUN", "LIVE_TRADING_ENABLED": "false",
        "KB_BAR_TIME_BASIS": "START_NY",
        "SIGNAL_SYMBOL": signal_symbol, "MAIN_SYMBOL": main_symbol, "SAFE_SYMBOL": safe_symbol,
        "RISK_THRESHOLD": risk_threshold,
        "TRADING_SIGNAL_MODE": mode, "SIGNAL_TIME": signal_time,
        "MA_PERIOD": str(strategy_defaults.ma_period),
        "FEAR_GREED_LOW_THRESHOLD": fg_low,
        "FEAR_GREED_HIGH_THRESHOLD": fg_high,
        "CASH_TARGET_MULTIPLIER": cash_multiplier,
        "MIN_ORDER_AMOUNT_USD": str(trading_defaults.min_order_amount_usd),
        "CANDLE_LOOKBACK_DAYS": str(trading_defaults.candle_lookback_days),
        "MINUTE_POLLING_INTERVAL_SECONDS": str(minute_defaults.polling_interval_seconds),
        "MINUTE_ORDER_CUTOFF": minute_defaults.order_cutoff,
        "TIMEOUT_SECONDS": str(app_defaults.timeout_seconds),
        "BACKUP_TIME": DEFAULT_BACKUP_TIME,
        "KB_CLIENT_ID": input("KB_CLIENT_ID: ").strip(), "KB_CLIENT_SECRET": getpass("KB_CLIENT_SECRET: "),
        "KB_API_BASE_URL": input("KB_API_BASE_URL [https://developer.kbsec.com:32484]: ").strip() or "https://developer.kbsec.com:32484",
        "KB_ACCOUNT_NO": normalize_kb_account_no(input("KB_ACCOUNT_NO: ").strip()) or "",
        "KB_IP_ADDR": input("KB 등록 IPv4 주소: ").strip(),
        "KB_MAC_ADDR": input("KB 등록 MAC 주소: ").strip(),
    }
    for symbol in {signal_symbol, main_symbol, safe_symbol}:
        values[f"KB_EXCHANGE_{symbol}"] = input(f"{symbol}의 KB 거래소 코드 (예: NAS/AMS/NYSE): ").strip().upper()
    print("12개 조건별 MAIN 매수금액을 입력하세요. Enter는 표시된 기본값을 사용합니다.")
    for key in AMOUNT_KEYS:
        values[key] = ask_decimal(key, str(trading_defaults.buy_amounts[key]), allow_zero=True)
    if not all(values[k] for k in ("KB_CLIENT_ID", "KB_CLIENT_SECRET", "KB_ACCOUNT_NO", "KB_IP_ADDR", "KB_MAC_ADDR")):
        raise ValueError("KB credentials, account number and registered IP/MAC are required")
    if any(not values[f"KB_EXCHANGE_{symbol}"] for symbol in {signal_symbol, main_symbol, safe_symbol}):
        raise ValueError("KB exchange code is required for every managed symbol")
    telegram = ask_yes_no_default_yes("Telegram 알림을 사용하시겠습니까?")
    values["TELEGRAM_ENABLED"] = "true" if telegram else "false"
    values["TELEGRAM_BOT_TOKEN"] = getpass("Telegram Bot Token: ") if telegram else ""
    values["TELEGRAM_ALERT_CHAT_ID"] = input("데이터 및 거래 알림 Chat ID: ").strip() if telegram else ""
    values["TELEGRAM_BACKUP_CHAT_ID"] = input("백업 데이터 Chat ID [Enter = 알림 대화방과 동일]: ").strip() if telegram else ""
    if telegram and not values["TELEGRAM_BOT_TOKEN"]:
        raise ValueError("Telegram 기능에는 Bot Token이 필요합니다.")
    if telegram and not values["TELEGRAM_ALERT_CHAT_ID"]:
        raise ValueError("Telegram 일반 알림에는 TELEGRAM_ALERT_CHAT_ID가 필요합니다.")
    identity_keys = {
        "SIGNAL_SYMBOL", "MAIN_SYMBOL", "SAFE_SYMBOL",
        "TRADING_SIGNAL_MODE", "SIGNAL_TIME", "KB_ACCOUNT_NO",
    }
    if old_values is not None and any(old_values.get(key, "") != values[key] for key in identity_keys):
        if (ROOT / "data" / "state.json").exists() or (ROOT / "data" / "order_ledger.json").exists():
            raise RuntimeError("identity fields changed while approved state/ledger exists; disable/recover then explicitly reinitialize")
    masked = "*" * max(0, len(values["KB_ACCOUNT_NO"]) - 3) + values["KB_ACCOUNT_NO"][-3:]
    print("\n설치 설정 요약 (민감정보 숨김):")
    for key in ("SIGNAL_SYMBOL", "MAIN_SYMBOL", "SAFE_SYMBOL", "RISK_THRESHOLD", "FEAR_GREED_LOW_THRESHOLD", "FEAR_GREED_HIGH_THRESHOLD", "CASH_TARGET_MULTIPLIER", "TRADING_SIGNAL_MODE", "SIGNAL_TIME", *AMOUNT_KEYS):
        print(f"{key}: {values[key]}")
    backup_target = "별도 백업 대화방" if values["TELEGRAM_BACKUP_CHAT_ID"] else "알림 대화방과 동일"
    print(f"KB 계좌: {masked}\nTelegram: {'활성' if telegram else '비활성'}\nTelegram 백업: {backup_target if telegram else '비활성'}\n실행 모드: DRY_RUN\n실거래: 비활성")
    if not ask_yes_no("이 설정으로 .env를 생성하시겠습니까?"):
        raise SystemExit("변경된 파일이 없습니다.")
    write_env(values, backup=ENV_PATH.exists())
    print(".env를 권한 0600으로 생성했습니다. 다음 단계는 ./initialize.sh입니다.")


if __name__ == "__main__":
    main()
