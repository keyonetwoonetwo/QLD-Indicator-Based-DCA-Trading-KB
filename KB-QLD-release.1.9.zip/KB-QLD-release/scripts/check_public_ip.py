#!/usr/bin/env python3
"""Independent public IPv4 monitor; never reads trading state or ledger."""
import ipaddress
import os
import urllib.request
from pathlib import Path
from typing import Callable, Optional, Tuple

try:
    from release_common import ROOT, read_env
except ModuleNotFoundError:
    from scripts.release_common import ROOT, read_env

IP_PATH = ROOT / "data" / "public_ip.txt"
IPV4_ENDPOINT = "https://api4.ipify.org"


def fetch_public_ipv4() -> str:
    request = urllib.request.Request(IPV4_ENDPOINT, headers={"User-Agent": "kb-qld-trader-ip-monitor/1"})
    with urllib.request.urlopen(request, timeout=15) as response:
        value = response.read(64).decode("ascii").strip()
    parsed = ipaddress.ip_address(value)
    if parsed.version != 4:
        raise ValueError("IPv4 응답이 아닙니다.")
    return str(parsed)


def telegram_sender() -> Callable[[str], bool]:
    from app.notification import TelegramNotifier
    values = read_env()
    notifier = TelegramNotifier(
        values.get("TELEGRAM_BOT_TOKEN", ""),
        values.get("TELEGRAM_ALERT_CHAT_ID", ""),
        values.get("TELEGRAM_ENABLED", "false").lower() == "true",
    )
    return notifier.send_message


def atomic_write(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(value + "\n", encoding="ascii")
    os.replace(temporary, path)


def check_public_ip(
    fetcher: Callable[[], str] = fetch_public_ipv4,
    sender: Optional[Callable[[str], bool]] = None,
    path: Path = IP_PATH,
) -> Tuple[str, Optional[str]]:
    sender = sender or telegram_sender()
    try:
        current = str(ipaddress.IPv4Address(fetcher().strip()))
    except Exception:
        sender("[경고] 공인 IPv4 확인 실패\n\n기존 IP 정보는 유지했습니다.\n네트워크 연결 상태를 확인하세요.")
        return "ERROR", None
    previous = path.read_text(encoding="ascii").strip() if path.exists() else ""
    if not previous:
        atomic_write(path, current)
        return "BASELINE", current
    if current == previous:
        return "UNCHANGED", current
    atomic_write(path, current)
    sender(
        "[경고] 공인 IPv4 변경 감지\n\n"
        f"이전 IP: {previous}\n현재 IP: {current}\n\n"
        "KB Open API 허용 IP 등록 상태를 확인하세요."
    )
    return "CHANGED", current


def main() -> None:
    status, current = check_public_ip()
    if status == "BASELINE":
        print(f"공인 IPv4 기준값을 저장했습니다: {current}")
    elif status == "CHANGED":
        print("공인 IPv4 변경을 감지하여 알림을 전송했습니다.")
    elif status == "ERROR":
        print("공인 IPv4 확인에 실패했습니다. 기존 기준값은 유지했습니다.")


if __name__ == "__main__":
    main()
