#!/usr/bin/env python3
"""Validate and restore a local Telegram-downloaded backup without enabling LIVE."""
import argparse
import tempfile
from pathlib import Path

try:
    from backup_common import atomic_place_pair, validate_restore_identity, verify_archive
    from release_common import runtime_context
except ModuleNotFoundError:
    from scripts.backup_common import atomic_place_pair, validate_restore_identity, verify_archive
    from scripts.release_common import runtime_context


def main() -> None:
    parser = argparse.ArgumentParser(description="Telegram에서 직접 내려받은 KB QLD Trader tar.gz 백업을 복구합니다.")
    parser.add_argument("archive", nargs="?")
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    if not args.archive:
        args.archive = input("복구할 로컬 tar.gz 파일 경로: ").strip()
    archive = Path(args.archive).expanduser() if args.archive else Path()
    if not args.archive or not archive.name.endswith(".tar.gz") or not archive.is_file():
        raise SystemExit("존재하는 로컬 .tar.gz 백업 파일 경로가 필요합니다.")
    if args.overwrite and input("계속하려면 OVERWRITE EXISTING APPROVED STATE를 정확히 입력하세요: ").strip() != "OVERWRITE EXISTING APPROVED STATE":
        raise SystemExit("복구가 취소되었습니다.")
    files, manifest = verify_archive(archive)
    with tempfile.TemporaryDirectory(prefix="kb-qld-trader-restore-") as directory:
        from app.storage import OrderLedgerStore, ProcessLock, StateStore
        state_temp = Path(directory) / "state.json"
        ledger_temp = Path(directory) / "order_ledger.json"
        state_temp.write_bytes(files["state.json"])
        ledger_temp.write_bytes(files["order_ledger.json"])
        state = StateStore(state_temp).load_state_strict()
        OrderLedgerStore(ledger_temp).load_strict()
        expected_config, _, _, _, _, expected_identity = runtime_context()
        validate_restore_identity(state, manifest, expected_identity, str(expected_config.kb_account_no or ""))
        state_store = StateStore(expected_config.storage.state_file)
        ledger_store = OrderLedgerStore(expected_config.storage.order_ledger_file)
        with ProcessLock(expected_config.storage.process_lock_file):
            atomic_place_pair(state_store.state_file_path, ledger_store.path, files, allow_overwrite=args.overwrite)
    print("복구가 완료되었습니다. LIVE 설정은 변경하지 않았습니다. ./run.sh 전에 ./validate.sh를 실행하세요.")


if __name__ == "__main__":
    main()
