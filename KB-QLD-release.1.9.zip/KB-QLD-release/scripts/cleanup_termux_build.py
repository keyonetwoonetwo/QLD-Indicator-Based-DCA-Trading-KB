#!/usr/bin/env python3
"""Best-effort post-success Termux build cleanup; durable/runtime data is untouched."""
import shutil
import subprocess
from pathlib import Path


def cleanup(home: Path | None = None, runner=subprocess.run) -> dict:
    home = home or Path.home()
    result = {"pip": True}
    try:
        runner([str(Path(__import__("sys").executable)), "-m", "pip", "cache", "purge"], check=False, capture_output=True, text=True)
        shutil.rmtree(home / ".cache" / "pip", ignore_errors=True)
    except Exception:
        result["pip"] = False
    return result


def main() -> None:
    result = cleanup()
    print("\n빌드 정리:")
    print(f"pip cache 정리 {'완료' if result['pip'] else '경고: 일부 실패'}")


if __name__ == "__main__":
    main()
