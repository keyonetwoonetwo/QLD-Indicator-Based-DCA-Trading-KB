#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ $# -ne 1 || ( ! -f "$1" && ! -d "$1" ) ]]; then
    echo "Usage: ./recover_backup.sh /path/to/backup.tar.gz-or-directory" >&2
    exit 2
fi
cd "$ROOT"
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"
exec .venv/bin/python "$ROOT/scripts/recover_backup.py" "$1"
