from app.runners.minute_runner import MinuteRunner

RUNNERS = {"MINUTE": MinuteRunner}

__all__ = ["MinuteRunner", "RUNNERS"]
