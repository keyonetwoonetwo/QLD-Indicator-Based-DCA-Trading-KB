import logging
from decimal import Decimal
from typing import Dict, List, Optional
from app.api.base_broker import BaseBrokerAPI
from app.api.client import KBAPIClient
from app.models.portfolio import PortfolioState, PositionItem

logger = logging.getLogger(__name__)


class FractionalManagedPositionError(RuntimeError):
    """A managed role is fractional although this installation is integer-only."""


class PortfolioAdapter:
    """Adapts raw broker account and holdings API responses into standardized PortfolioState."""

    def __init__(self, broker_api: BaseBrokerAPI, client: Optional[KBAPIClient] = None):
        self.broker_api = broker_api
        self.client = client

    def resolve_account_binding(self, target_account_no: Optional[str] = None) -> str:
        """Bind local state to the configured KB app/account context."""
        if not target_account_no:
            raise RuntimeError("KB_ACCOUNT_NO is required; automatic account selection is disabled.")
        return self.broker_api.connect_account(target_account_no)

    def get_portfolio_state(
        self,
        account_binding: str,
        account_no: str,
        current_prices: Optional[Dict[str, Decimal]],
        main_symbol: str,
        safe_symbol: str,
    ) -> PortfolioState:
        """Queries broker holdings and buying power, then transforms into PortfolioState."""
        holdings_resp = self.broker_api.get_holdings()
        buying_power_resp = self.broker_api.get_buying_power(currency="USD")

        cash_usd_str = buying_power_resp.get("cashBuyingPower", "0")
        available_cash_usd = Decimal(str(cash_usd_str))

        positions: Dict[str, PositionItem] = {}
        raw_items: List[Dict] = holdings_resp.get("items", [])

        main_qty = Decimal("0")
        main_avg_price = Decimal("0")
        safe_qty = Decimal("0")

        for item in raw_items:
            sym = item.get("symbol", "")
            qty = Decimal(str(item.get("quantity", "0")))
            avg_price = Decimal(str(item.get("averagePurchasePrice", "0")))
            last_price = Decimal(str(item.get("lastPrice", "0")))
            market_val = Decimal(str(item.get("marketValue", {}).get("amount", "0")))

            pos = PositionItem(
                symbol=sym,
                name=item.get("name", ""),
                quantity=qty,
                average_purchase_price=avg_price,
                last_price=last_price,
                market_value=market_val,
                currency=item.get("currency", "USD"),
            )
            positions[sym] = pos

            if sym == main_symbol:
                main_qty = qty
                main_avg_price = avg_price
            elif sym == safe_symbol:
                safe_qty = qty

        prices = current_prices or {}

        # The strategy submits quantity-based integer orders only.  Do not
        # silently floor a broker-reported managed position (e.g. 10.5 -> 10)
        # and then commit a false lifecycle transition.
        for role, symbol, quantity in (
            ("safe", safe_symbol, safe_qty),
        ):
            if quantity != quantity.to_integral_value():
                raise FractionalManagedPositionError(
                    f"Fractional {role} holding for managed symbol {symbol}: {quantity}; "
                    "manual integer-share recovery is required"
                )

        state = PortfolioState(
            account_no=account_no,
            account_binding=account_binding,
            main_quantity=main_qty,
            main_avg_price=main_avg_price,
            safe_quantity=safe_qty,
            available_cash_usd=available_cash_usd,
            positions=positions,
            prices=prices,
        )

        logger.info(
            f"PortfolioState: {main_symbol}={main_qty} (avg={main_avg_price}), "
            f"{safe_symbol}={safe_qty}, Cash=${available_cash_usd}"
        )
        return state

    def get_sellable_quantity(self, symbol: str) -> Decimal:
        """Broker truth immediately before a sell order."""
        response = self.broker_api.get_sellable_quantity(symbol)
        quantity = Decimal(str(response.get("sellableQuantity", "0")))
        if quantity != quantity.to_integral_value():
            raise FractionalManagedPositionError(
                f"Fractional sellable quantity for managed symbol {symbol}: {quantity}; "
                "manual integer-share recovery is required"
            )
        return quantity

    def get_buying_power(self) -> Decimal:
        """Broker truth immediately before a buy order."""
        response = self.broker_api.get_buying_power(currency="USD")
        return Decimal(str(response.get("cashBuyingPower", "0")))

    def get_execution_price(self, symbol: str) -> Decimal:
        """Fetch the latest KB execution quote."""
        response = self.broker_api.get_prices([symbol])
        for item in response:
            if item.get("symbol") == symbol and item.get("lastPrice") is not None:
                price = Decimal(str(item["lastPrice"]))
                if price > 0:
                    if hasattr(self.broker_api, "assert_quote_fresh"):
                        self.broker_api.assert_quote_fresh(symbol)
                    return price
        raise RuntimeError(f"No valid current execution quote for {symbol}")
