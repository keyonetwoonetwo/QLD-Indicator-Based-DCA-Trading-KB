from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Optional


@dataclass
class Candle:
    timestamp: datetime
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal
    volume: Decimal
    currency: str = "USD"


@dataclass
class IndicatorResult:
    symbol: str
    current_close: Decimal
    ma200: Decimal
    prev_close: Decimal
    prev_ma200: Decimal
    is_above_ma200: bool
    is_prev_above_ma200: bool
    overheat_price: Decimal


@dataclass
class MarketSessionInfo:
    is_business_day: bool
    is_regular_market_open: bool
    date_str: str
    regular_start: Optional[datetime] = None
    regular_end: Optional[datetime] = None
    after_start: Optional[datetime] = None
    after_end: Optional[datetime] = None
    # Date supplied by the broker calendar, not inferred from weekdays.
    previous_business_date: Optional[str] = None
