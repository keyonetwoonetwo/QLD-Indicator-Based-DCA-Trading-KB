from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any, Dict, List, Optional
from app.models.common import OrderSide, OrderType, OrderStatus, TimeInForce


@dataclass
class OrderItem:
    symbol: str
    side: OrderSide
    quantity: Decimal
    order_type: OrderType = OrderType.LIMIT
    time_in_force: Optional[TimeInForce] = TimeInForce.DAY
    price: Optional[Decimal] = None
    reason: str = ""
    client_order_id: Optional[str] = None
    order_amount: Optional[Decimal] = None


@dataclass
class OrderPlan:
    strategy_name: str
    decision: str
    reason: str
    orders: List[OrderItem] = field(default_factory=list)
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def has_orders(self) -> bool:
        return len(self.orders) > 0


@dataclass
class ExecutionRecord:
    order_id: str
    symbol: str
    side: OrderSide
    quantity: Decimal
    status: OrderStatus
    client_order_id: Optional[str] = None
    price: Optional[Decimal] = None
    filled_quantity: Decimal = Decimal("0")
    average_filled_price: Optional[Decimal] = None
    filled_amount: Optional[Decimal] = None
    commission: Optional[Decimal] = None
    tax: Optional[Decimal] = None
    ordered_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    filled_at: Optional[datetime] = None
    reason: str = ""
    strategy: str = ""
    requested_amount: Optional[Decimal] = None


@dataclass
class StrategyDecision:
    """A strategy event.  It contains no broker-side state mutation."""

    strategy_name: str
    decision: str
    reason: str
    event: str
    pending_state_transition: Dict[str, Any] = field(default_factory=dict)
    # Notification-only inputs from the exact conditional decision.
    signal_symbol: Optional[str] = None
    signal_close: Optional[Decimal] = None
    signal_ma200: Optional[Decimal] = None
    risk_on_price: Optional[Decimal] = None
    display_decision: Optional[str] = None
    regime: Optional[str] = None
    main_direction: Optional[str] = None
    fear_greed_band: Optional[str] = None
    fear_greed_score: Optional[Decimal] = None
    configured_amount: Optional[Decimal] = None
    selected_amount: Optional[Decimal] = None
    condition_key: Optional[str] = None


@dataclass
class LedgerOrder:
    """Durable description of a single broker order leg."""

    client_order_id: str
    workflow_id: str
    leg: str
    symbol: str
    side: str
    requested_quantity: int
    price: Optional[str] = None
    status: str = "INTENT_RECORDED"
    broker_order_id: Optional[str] = None
    filled_quantity: str = "0"
    average_filled_price: Optional[str] = None
    filled_amount: Optional[str] = None
    submitted_at: Optional[str] = None
    last_checked_at: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return self.__dict__.copy()
