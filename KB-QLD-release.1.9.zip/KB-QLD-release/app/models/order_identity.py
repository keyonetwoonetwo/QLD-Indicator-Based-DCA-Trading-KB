"""Deterministic, broker-bounded identifiers for durable workflow orders."""
import hashlib
import re
from typing import Any, Dict


CLIENT_ORDER_ID_MAX_LENGTH = 36
LEGACY_CLIENT_ORDER_ID_SCHEME = "PREFIX_V1"
CURRENT_CLIENT_ORDER_ID_SCHEME = "HASH_V2"


def make_client_order_id(
    workflow_id: str,
    leg: str,
    scheme: str = CURRENT_CLIENT_ORDER_ID_SCHEME,
) -> str:
    """Return a deterministic ID whose uniqueness survives the 36-char limit."""
    candidate = f"{workflow_id}-{leg.lower()}"
    if scheme == LEGACY_CLIENT_ORDER_ID_SCHEME:
        return candidate[:CLIENT_ORDER_ID_MAX_LENGTH]
    if scheme != CURRENT_CLIENT_ORDER_ID_SCHEME:
        raise ValueError(f"Unsupported client order id scheme: {scheme}")
    safe_candidate = re.sub(r"[^a-zA-Z0-9\-_]", "_", candidate)
    if safe_candidate == candidate and len(safe_candidate) <= CLIENT_ORDER_ID_MAX_LENGTH:
        return safe_candidate
    digest = hashlib.sha256(candidate.encode("utf-8")).hexdigest()[:10]
    prefix_length = CLIENT_ORDER_ID_MAX_LENGTH - len(digest) - 1
    return f"{safe_candidate[:prefix_length]}-{digest}"


def workflow_client_order_id(workflow: Dict[str, Any], leg: str) -> str:
    # Workflows created before HASH_V2 intentionally keep their persisted
    # mapping. Reinterpreting a possibly submitted intent would violate
    # exactly-once execution.
    overrides = workflow.get("legacy_client_order_id_overrides") or {}
    if leg in overrides:
        return str(overrides[leg])
    scheme = workflow.get("client_order_id_scheme", LEGACY_CLIENT_ORDER_ID_SCHEME)
    return make_client_order_id(str(workflow["workflow_id"]), leg, str(scheme))


def workflow_step_client_ids(workflow: Dict[str, Any]) -> list[str]:
    return [
        workflow_client_order_id(workflow, str(step.get("leg", "")))
        for step in workflow.get("steps", [])
    ]
