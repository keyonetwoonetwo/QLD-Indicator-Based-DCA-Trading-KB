import logging
import sys
from datetime import date, datetime, timezone
from decimal import Decimal
from app.api import KBAuthManager, KBAPIClient, KBBrokerAPI
from config.config import AppConfig
from app.execution import OrderManager, WorkflowExecutor, WorkflowBlocked, WorkflowReconciler
from app.market import MarketCalendarService, MarketDataService
from app.models.common import ExecutionMode, OrderSide, OrderType
from app.models.orders import OrderItem
from app.notification import TelegramNotifier
from app.portfolio import PortfolioAdapter
from app.storage import StateStore, CSVStore, OrderLedgerStore, ProcessLock, LedgerCorruptionError
from app.storage.state_store import StateIntegrityError
from app.strategy import GenericStrategy
from app.strategy.generic_strategy import fetch_fear_greed
from app.runners import RUNNERS
from app.runners.common import ExpectedNoOp

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger("KBQLDTrader")


def run_system() -> None:
    logger.info("=== Starting KB QLD Trader ===")

    # 1. Load configuration
    try:
        config = AppConfig.load()
    except Exception as e:
        logger.error(f"Failed to load configuration: {e}")
        return
    profile_for_log = config.resolved_strategy()
    logger.info(
        "Runtime config loaded: conditional accumulation risk=%s ma_period=%s "
        "FG=%s/%s target_cash=$%s min_order=$%s lookback=%s "
        "minute_poll=%ss minute_cutoff=%s timeout=%ss",
        profile_for_log.risk_threshold, config.strategy_rules.ma_period,
        config.trading.fear_greed_low_threshold, config.trading.fear_greed_high_threshold,
        config.target_cash, config.trading.min_order_amount_usd,
        config.trading.candle_lookback_days, config.minute.polling_interval_seconds,
        config.minute.order_cutoff, config.timeout_seconds,
    )

    # 2. Setup Notification
    notifier = TelegramNotifier(
        bot_token=config.telegram_bot_token,
        chat_id=config.telegram_chat_id,
        enabled=config.telegram_enabled,
    )

    runner_class = RUNNERS.get(config.signal_mode)
    if runner_class is None:
        notifier.notify_error(f"Execution blocked: invalid TRADING_SIGNAL_MODE '{config.signal_mode}'.")
        logger.error("Invalid TRADING_SIGNAL_MODE '%s'; fail-closed.", config.signal_mode)
        return
    try:
        mode_enum = ExecutionMode(config.execution_mode)
    except Exception:
        logger.warning(f"Invalid execution mode '{config.execution_mode}'. Defaulting to DRY_RUN.")
        mode_enum = ExecutionMode.DRY_RUN

    date_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    notifier.notify_startup(mode=mode_enum.value, date_str=date_str)

    # LIVE requires two independently persisted, explicit operator choices.
    # PAPER remains unavailable because it has no broker-isolated implementation.
    if mode_enum == ExecutionMode.PAPER:
        notifier.notify_error("PAPER execution is unavailable; use DRY_RUN or the approved LIVE promotion flow.")
        logger.error("Refusing PAPER execution.")
        return
    if mode_enum == ExecutionMode.LIVE and not config.live_trading_enabled:
        notifier.notify_error("LIVE requires LIVE_TRADING_ENABLED=true from enable-live.sh.")
        logger.error("Refusing LIVE execution without the explicit release gate.")
        return

    lock = ProcessLock(config.storage.process_lock_file)
    try:
        lock.__enter__()
    except Exception as e:
        notifier.notify_error(f"Execution blocked: {e}")
        logger.error("Execution lock unavailable: %s", e)
        return

    workflow_executor = None
    try:
        # 3. Auth & API Client
        auth_mgr = KBAuthManager(
            base_url=config.kb_api_base_url,
            client_id=config.kb_client_id,
            client_secret=config.kb_client_secret,
            timeout_seconds=config.timeout_seconds,
        )
        client = KBAPIClient(
            base_url=config.kb_api_base_url,
            auth_manager=auth_mgr,
            timeout_seconds=config.timeout_seconds,
        )
        broker_api = KBBrokerAPI(client=client)
        # Quote/portfolio refresh is also required for recovery.  Calendar
        # session validation remains deferred until a *new* workflow starts.
        market_svc = MarketDataService(broker_api=broker_api)

        # Load and identity-check durable state before any runner can reject a
        # restarted MINUTE workflow for being outside its *new* admission window.
        state_store = StateStore(state_file_path=config.storage.state_file)
        ledger_store = OrderLedgerStore(config.storage.order_ledger_file)
        profile = config.resolved_strategy()
        state_data = state_store.load_state_strict()
        ledger_data = ledger_store.load() if mode_enum == ExecutionMode.DRY_RUN else ledger_store.load_strict()
        ledger_store.validate_active_workflow(ledger_data)
        active_workflow = ledger_data.get("active_workflow")
        symbols = [profile.main_symbol, profile.safe_symbol]
        portfolio_adapter = PortfolioAdapter(broker_api=broker_api, client=client)
        account_binding = portfolio_adapter.resolve_account_binding(target_account_no=config.kb_account_no)
        installation_identity = profile.installation_identity(config.signal_mode, config.kb_account_no or "", account_binding)
        if active_workflow and not WorkflowReconciler.is_qld_workflow(active_workflow):
            WorkflowReconciler.assert_legacy_account(active_workflow, state_data, installation_identity)
            result = WorkflowReconciler(ledger_store, broker_api).reconcile_active()
            raise WorkflowBlocked(result.message)
        if active_workflow:
            state_store.assert_installation_identity(state_data, installation_identity)
            if (active_workflow.get("execution_core") not in {"CLOSE", "MINUTE"}
                    or not isinstance(active_workflow.get("execution_policy"), dict)):
                raise WorkflowBlocked("Active workflow has no durable execution core/policy; operator recovery required")
            try:
                state_store.assert_identity_values(
                    active_workflow.get("installation_identity") or {}, installation_identity,
                )
            except Exception as exc:
                raise WorkflowBlocked(
                    f"Active workflow installation identity mismatch; automatic conversion is forbidden: {exc}"
                ) from exc
        current_prices = market_svc.fetch_current_prices(symbols)
        portfolio = portfolio_adapter.get_portfolio_state(
            account_binding,
            installation_identity["account_no"],
            current_prices,
            main_symbol=profile.main_symbol,
            safe_symbol=profile.safe_symbol,
        )
        order_mgr = OrderManager(broker_api=broker_api, execution_mode=mode_enum)
        from zoneinfo import ZoneInfo
        state_data = state_store.apply_symbol_change(
            state_data, installation_identity, ledger_data, broker_api, portfolio,
            datetime.now(ZoneInfo("America/New_York")).date().isoformat(),
        )
        state_store.assert_installation_identity(state_data, installation_identity)
        workflow_executor = WorkflowExecutor(order_mgr, ledger_store, portfolio_adapter, Decimal(str(config.trading.min_order_amount_usd)))

        def refresh_portfolio():
            refreshed_prices = market_svc.fetch_current_prices(symbols)
            return portfolio_adapter.get_portfolio_state(
                account_binding,
                installation_identity["account_no"],
                refreshed_prices,
                main_symbol=profile.main_symbol,
                safe_symbol=profile.safe_symbol,
            )

        if active_workflow:
            # Recovery uses only the persisted execution core/policy.  It does
            # not call a runner or derive anything from current market data.
            records, completed = workflow_executor.resume(portfolio, refresh_portfolio)
            for warning in workflow_executor.warnings:
                notifier.notify_warning(warning)
            if not completed:
                raise WorkflowBlocked("Recovered workflow did not reach a confirmed terminal state")
            if mode_enum == ExecutionMode.DRY_RUN:
                ledger_store.complete_workflow()
            else:
                workflow_executor.commit_confirmed_state(state_store, refresh_portfolio())
            logger.info("Recovered workflow %s using persisted %s core.", active_workflow["workflow_id"], active_workflow["execution_core"])
            return

        # 4. Existing MINUTE runner owns session/data validation.
        calendar_svc = MarketCalendarService(broker_api=broker_api)
        prepared = runner_class().prepare(config, calendar_svc, market_svc)
        session_info = prepared.session
        indicators = prepared.indicators
        logger.info("Prepared generic/%s signal price: $%s", config.signal_mode, prepared.decision_price)

        # 5. Fetch executable prices; strategy signal remains the runner's
        # prepared close and is never replaced by current quotes.
        current_prices = market_svc.fetch_current_prices(symbols)

        logger.info(
            f"Indicators: {prepared.signal_symbol} Close=${indicators.current_close:.2f}, "
            f"200MA=${indicators.ma200:.2f}, Prev Close=${indicators.prev_close:.2f}, "
            f"Prev 200MA=${indicators.prev_ma200:.2f}"
        )

        # 6. Account & Portfolio State
        portfolio = portfolio_adapter.get_portfolio_state(
            account_binding=account_binding,
            account_no=installation_identity["account_no"],
            current_prices=current_prices,
            main_symbol=profile.main_symbol,
            safe_symbol=profile.safe_symbol,
        )

        # 7. State already passed identity verification before runner admission.
        if state_data.get("last_execution_date") == session_info.date_str:
            logger.info(f"Strategy already executed for market date {session_info.date_str}. Exiting.")
            return

        state_store.assert_reconciled(state_data, portfolio, installation_identity)

        # 8. Strategy Evaluation
        strategy = GenericStrategy(profile, config.strategy_rules, config.trading)
        if prepared.main_regular_open is None or prepared.main_provisional_close is None:
            raise ValueError("MINUTE runner did not provide MAIN open/provisional close")
        fear_greed_score, _fear_greed_rating, fear_greed_at = fetch_fear_greed()
        decision, plan = strategy.evaluate_decision(
            indicators, portfolio, state_data, prepared.main_provisional_close,
            prepared.main_regular_open, fear_greed_score,
        )
        decision.pending_state_transition["last_minute_decision"].update({
            "market_date": session_info.date_str,
            "retrieved_at": fear_greed_at.isoformat(),
        })

        current_day = date.fromisoformat(session_info.date_str)
        previous_day = date.fromisoformat(session_info.previous_business_date) if session_info.previous_business_date else None
        first_session = previous_day is None or previous_day.isocalendar()[:2] != current_day.isocalendar()[:2]
        if first_session:
            safe_price = current_prices.get(profile.safe_symbol)
            if safe_price is None or safe_price <= 0:
                raise ValueError("SAFE current price unavailable for weekly cash management")
            gap = config.target_cash - portfolio.available_cash_usd
            quantity = 0
            side = None
            if gap > 0:
                quantity = min(
                    int(portfolio.safe_quantity),
                    int((gap / safe_price).to_integral_value(rounding="ROUND_CEILING")),
                )
                side = OrderSide.SELL if quantity else None
            elif gap < 0:
                quantity = int(((-gap) / safe_price).to_integral_value(rounding="ROUND_FLOOR"))
                side = OrderSide.BUY if quantity else None
            if side and quantity > 0:
                plan.orders.insert(0, OrderItem(
                    symbol=profile.safe_symbol, side=side, quantity=Decimal(quantity),
                    order_type=OrderType.LIMIT, time_in_force=None, price=safe_price,
                    reason=f"Weekly SAFE cash target ${config.target_cash}",
                ))

        logger.info(f"Strategy Decision: {decision.decision} -> Reason: {decision.reason}")

        # 9. Order Execution
        workflow_executor.start(
            session_info.date_str, decision, plan, portfolio,
            signal_mode=config.signal_mode,
            execution_policy=prepared.execution_policy,
            installation_identity=installation_identity,
        )
        execution_records, completed = workflow_executor.resume(portfolio, refresh_portfolio)
        for warning in workflow_executor.warnings:
            notifier.notify_warning(warning)
        if not completed:
            raise WorkflowBlocked("Workflow did not reach a confirmed terminal state")
        # DRY_RUN records simulated legs but must never pretend the broker
        # portfolio changed or advance confirmed strategy state.
        if mode_enum == ExecutionMode.DRY_RUN:
            ledger_store.complete_workflow()
            final_portfolio = portfolio
            updated_state = state_data
        else:
            final_portfolio = refresh_portfolio()
            updated_state = workflow_executor.commit_confirmed_state(state_store, final_portfolio)

        # 10. Persist History
        csv_store = CSVStore(
            daily_history_file=config.storage.daily_history_file,
            trade_history_file=config.storage.trade_history_file,
        )
        csv_store.record_daily_history(
            date_str=session_info.date_str,
            tqqq_close=float(prepared.main_lifecycle_price or indicators.current_close),
            tqqq_ma200=float(indicators.ma200),
            position_state=decision.regime or "UNKNOWN",
            portfolio=final_portfolio,
            plan=plan,
        )
        csv_store.record_trade_history(records=execution_records)

        # 11. Send Telegram Notification
        notifier.notify_decision(
            decision=decision,
            plan=plan,
            portfolio=portfolio,
            main_symbol=profile.main_symbol,
            safe_symbol=profile.safe_symbol,
        )
        if execution_records:
            notifier.notify_execution(records=execution_records)

        logger.info("=== KB QLD Trader completed successfully ===")

    except ExpectedNoOp as e:
        logger.info("%s", e)
    except (StateIntegrityError, LedgerCorruptionError, WorkflowBlocked) as e:
        logger.error("Safety stop: %s", e)
        if isinstance(e, WorkflowBlocked) and workflow_executor is not None:
            blocked_records = workflow_executor.last_execution_records
            if blocked_records:
                notifier.notify_execution(blocked_records)
        notifier.notify_error(f"Safety stop: {e}")
    except Exception as e:
        logger.exception(f"Unhandled error during trading execution: {e}")
        notifier.notify_error(error_message=str(e))
    finally:
        lock.__exit__(None, None, None)


if __name__ == "__main__":
    run_system()
