"""Stepwise, fail-closed execution of strategy events."""
from decimal import Decimal, ROUND_DOWN
from copy import deepcopy
import time
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Tuple

from app.execution.order_manager import OrderManager
from app.models.common import ExecutionMode, OrderSide, OrderStatus, OrderType, TimeInForce
from app.models.orders import ExecutionRecord, OrderItem, OrderPlan, StrategyDecision
from app.models.portfolio import PortfolioState
from app.models.order_identity import (
    CURRENT_CLIENT_ORDER_ID_SCHEME,
    LEGACY_CLIENT_ORDER_ID_SCHEME,
    make_client_order_id,
    workflow_client_order_id,
    workflow_step_client_ids,
)
from app.portfolio.adapter import PortfolioAdapter
from app.storage.order_ledger_store import OrderLedgerStore
from app.execution.close_execution import CloseExecution
from app.execution.minute_execution import MinuteExecution
from app.execution.workflow_reconciler import WorkflowReconciler
from config.defaults import DEFAULT_SAFE_SYMBOL


BLOCKING_ORDER_STATUSES = {
    "UNKNOWN", "PENDING", "PENDING_CANCEL", "PENDING_REPLACE",
    "PARTIAL_FILLED", "PARTIAL_FILLED_BLOCKED", "REJECTED",
    "FILLED_INTEGRITY_ERROR",
}


class WorkflowBlocked(RuntimeError):
    pass


class WorkflowExecutor:
    """Builds dependent order legs only after preceding legs are FILLED."""

    def __init__(
        self,
        order_manager: OrderManager,
        ledger_store: OrderLedgerStore,
        portfolio_adapter: PortfolioAdapter,
        min_order_amount: Decimal = Decimal("10"),
        now_fn: Optional[Callable[[], datetime]] = None,
        sleep_fn: Optional[Callable[[float], None]] = None,
        poll_interval_seconds: float = 1.0,
    ):
        self.order_manager = order_manager
        self.ledger_store = ledger_store
        self.portfolio_adapter = portfolio_adapter
        self.min_order_amount = min_order_amount
        self.now_fn = now_fn or (lambda: datetime.now(timezone.utc))
        self.sleep_fn = sleep_fn or time.sleep
        self.poll_interval_seconds = poll_interval_seconds
        self.warnings: List[str] = []
        # Diagnostic-only copy for notification when fail-closed execution
        # raises before ``resume`` can return its records to the caller.
        self.last_execution_records: List[ExecutionRecord] = []
        self._virtual_buying_power: Optional[Decimal] = None

    def _now_utc(self) -> datetime:
        now = self.now_fn()
        if now.tzinfo is None:
            raise WorkflowBlocked("Execution clock must be timezone-aware")
        return now.astimezone(timezone.utc)

    @staticmethod
    def _policy_time(policy: Dict[str, Any], name: str) -> datetime:
        raw = policy.get(name)
        if not raw:
            raise WorkflowBlocked(f"MINUTE workflow policy missing {name}")
        try:
            value = datetime.fromisoformat(str(raw))
        except ValueError as exc:
            raise WorkflowBlocked(f"MINUTE workflow policy has invalid {name}") from exc
        if value.tzinfo is None:
            raise WorkflowBlocked(f"MINUTE workflow policy {name} must be timezone-aware")
        return value.astimezone(timezone.utc)

    def _assert_admission_open(self, signal_mode: str, policy: Dict[str, Any]) -> None:
        try:
            if signal_mode == "MINUTE":
                MinuteExecution.validate_admission(policy, self._now_utc())
            else:
                raise ValueError("unsupported execution core")
        except ValueError as exc:
            raise WorkflowBlocked(str(exc)) from exc

    def _assert_step_permitted(self, workflow: Dict[str, Any], step: Dict[str, Any], ledger: Dict[str, Any]) -> None:
        """Apply the workflow's persisted policy, never the current process mode."""
        mode = workflow.get("execution_core")
        policy = workflow.get("execution_policy")
        if mode != "MINUTE" or not isinstance(policy, dict):
            raise WorkflowBlocked("Active workflow has missing or unsupported signal execution policy")
        try:
            now = self._now_utc()
            allowed = MinuteExecution.step_permitted(workflow, step, ledger, now)
            broker = getattr(self.order_manager, "broker_api", None)
            client = getattr(broker, "client", None)
            if client is not None:
                client.order_deadline = MinuteExecution._time(policy, "new_leg_deadline")
        except ValueError as exc:
            raise WorkflowBlocked(str(exc)) from exc
        if allowed:
            return
        self.ledger_store.update_workflow(
            status="BLOCKED",
            blocked_reason="MINUTE execution policy forbids every new order leg at/after regular close",
        )
        raise WorkflowBlocked("MINUTE execution policy forbids every new order leg at/after regular close")

    @staticmethod
    def workflow_id(signal_date: str, decision: StrategyDecision) -> str:
        code = decision.event.lower().replace("_", "-")
        if decision.strategy_name != "generic":
            raise WorkflowBlocked("Only the generic strategy may start a new workflow")
        return f"g-{signal_date.replace('-', '')}-{code}"[:36]

    @staticmethod
    def client_order_id(
        workflow_id: str, leg: str,
        scheme: str = CURRENT_CLIENT_ORDER_ID_SCHEME,
    ) -> str:
        return make_client_order_id(workflow_id, leg, scheme)

    def start(
        self,
        signal_date: str,
        decision: StrategyDecision,
        plan: OrderPlan,
        portfolio: PortfolioState,
        signal_mode: str = "CLOSE",
        execution_policy: Optional[Dict[str, Any]] = None,
        installation_identity: Optional[Dict[str, str]] = None,
    ) -> None:
        """Persist a workflow before any order is created."""
        if self.ledger_store.load().get("active_workflow"):
            raise WorkflowBlocked("Existing workflow must be reconciled first")
        if signal_mode != "MINUTE":
            raise WorkflowBlocked("New trading workflows are MINUTE-only; CLOSE is validation-only")
        policy = dict(execution_policy or {"kind": "CLOSE", "market_date": signal_date})
        self._assert_admission_open(signal_mode, policy)
        
        safe_sym = (installation_identity or {}).get("safe_symbol", DEFAULT_SAFE_SYMBOL)

        steps = self._build_steps(decision, plan, safe_sym)
        workflow = {
            "workflow_id": self.workflow_id(signal_date, decision),
            "client_order_id_scheme": CURRENT_CLIENT_ORDER_ID_SCHEME,
            "signal_date": signal_date,
            "market_date": signal_date,
            "signal_mode": signal_mode,
            "execution_core": signal_mode,
            "execution_mode": self.order_manager.execution_mode.value,
            "strategy_name": decision.strategy_name,
            "installation_identity": dict(installation_identity or {}),
            "execution_policy": policy,
            "event": decision.event,
            "decision": decision.decision,
            "reason": decision.reason,
            "status": "RUNNING",
            "next_index": 0,
            "steps": steps,
            "pending_state_transition": decision.pending_state_transition,
            "main_average_purchase_price": str(portfolio.main_avg_price),
            "tqqq_average_purchase_price": str(portfolio.main_avg_price),
        }
        self.ledger_store.begin_workflow(workflow)

    def _build_steps(
        self,
        decision: StrategyDecision,
        plan: OrderPlan,
        safe_symbol: str = DEFAULT_SAFE_SYMBOL,
    ) -> List[Dict[str, Any]]:
        if decision.event == "CONDITIONAL_ACCUMULATION":
            steps = []
            for index, order in enumerate(plan.orders, 1):
                if order.order_amount is not None:
                    kind = "MAIN_AMOUNT_BUY"
                elif order.symbol == safe_symbol and order.side == OrderSide.SELL:
                    kind = "SAFE_CASH_SELL"
                elif order.symbol == safe_symbol and order.side == OrderSide.BUY:
                    kind = "SAFE_CASH_BUY"
                else:
                    raise WorkflowBlocked("Conditional plan contains an unsupported order")
                steps.append(self._static_step(order, f"{kind}_{index}", kind))
            return steps
        raise WorkflowBlocked(f"Removed legacy strategy event cannot start a workflow: {decision.event}")

    @staticmethod
    def _static_step(order: OrderItem, leg: str, kind: str = "SELL") -> Dict[str, Any]:
        return {
            "leg": leg, "kind": kind, "symbol": order.symbol,
            "quantity": str(order.quantity),
            "order_amount": str(order.order_amount) if order.order_amount is not None else None,
            "price": str(order.price) if order.price else None,
            "required": kind != "MAIN_AMOUNT_BUY",
        }

    def resume(
        self,
        portfolio: PortfolioState,
        refresh_portfolio: Callable[[], PortfolioState],
    ) -> Tuple[List[ExecutionRecord], bool]:
        """Run as many known-safe legs as possible. Returns (records, completed)."""
        self.last_execution_records = []
        ledger = self.ledger_store.load()
        workflow = ledger.get("active_workflow")
        if not workflow:
            return [], False
        if not WorkflowReconciler.is_qld_workflow(workflow):
            result = WorkflowReconciler(self.ledger_store, self.order_manager.broker_api).reconcile_active()
            raise WorkflowBlocked(result.message)
        # Older unit-level workflow fixtures do not carry a mode. Production
        # startup rejects such persisted active workflows in ledger validation.
        persisted_mode = workflow.get("execution_mode", self.order_manager.execution_mode.value)
        if persisted_mode != self.order_manager.execution_mode.value:
            raise WorkflowBlocked(
                f"Workflow execution mode mismatch: persisted={persisted_mode}, current={self.order_manager.execution_mode.value}"
            )
        workflow = self._ensure_unambiguous_client_order_ids(workflow, ledger)
        ledger = self.ledger_store.load()
        if self.order_manager.execution_mode == ExecutionMode.DRY_RUN:
            self._virtual_buying_power = portfolio.available_cash_usd
            for order in ledger.get("orders", []):
                if order.get("workflow_id") == workflow.get("workflow_id") and order.get("status") == "FILLED":
                    amount = Decimal(str(order.get("filled_amount") or "0"))
                    self._virtual_buying_power += amount if order.get("side") == "SELL" else -amount
        else:
            self._virtual_buying_power = None
        if workflow.get("status") in {"BLOCKED", "UNKNOWN", "PARTIAL_FILLED_BLOCKED", "FILLED_INTEGRITY_ERROR"}:
            raise WorkflowBlocked(f"Workflow is blocked: {workflow['status']}")
        records = self.last_execution_records
        current = portfolio
        for index in range(int(workflow.get("next_index", 0)), len(workflow["steps"])):
            step = workflow["steps"][index]
            deterministic_id = workflow_client_order_id(workflow, step["leg"])
            prior = next((x for x in ledger["orders"] if x.get("client_order_id") == deterministic_id), None)
            if prior:
                if prior.get("status") == "FILLED":
                    self.ledger_store.update_workflow(next_index=index + 1)
                    current = refresh_portfolio()
                    ledger = self.ledger_store.load()
                    workflow = ledger["active_workflow"]
                    continue
                if prior.get("status") in {"PENDING", "PENDING_CANCEL", "PENDING_REPLACE", "SUBMITTED"}:
                    item = self._item_from_intent(workflow, prior)
                    record = self._poll_pending_order(workflow, item, ledger, prior.get("broker_order_id"))
                    records.append(record)
                    if record.status == OrderStatus.FILLED:
                        self.ledger_store.update_workflow(next_index=index + 1)
                        current = self._apply_virtual_fill(current, item, record) if self._virtual_buying_power is not None else refresh_portfolio()
                        ledger = self.ledger_store.load()
                        workflow = ledger["active_workflow"]
                        continue
                    self.ledger_store.update_workflow(status="BLOCKED", blocked_reason=record.reason)
                    raise WorkflowBlocked(f"Existing order is not FILLED: {self._ledger_status(item.client_order_id)}")
                self.ledger_store.update_workflow(status="BLOCKED", blocked_reason=f"Existing {prior.get('status')} order")
                raise WorkflowBlocked(f"Existing order is not safely resumable: {prior.get('status')}")
            # Existing FILLED intents above are recovery bookkeeping, not a
            # new submission. Apply time policy only before a new broker leg.
            self._assert_step_permitted(workflow, step, ledger)
            item = self._prepare_step(workflow, step, current, ledger)
            if item is None:
                self.ledger_store.update_workflow(next_index=index + 1)
                continue
            self._record_intent(workflow, item, step["leg"])
            record = self.order_manager.submit_ledger_order(item, workflow["decision"], self.ledger_store)
            records.append(record)
            if record.status != OrderStatus.FILLED:
                record = self._poll_pending_order(workflow, item, ledger, self._broker_order_id(item.client_order_id))
                records[-1] = record
            if record.status != OrderStatus.FILLED:
                status = self.ledger_store.load()["orders"][-1].get("status", "UNKNOWN")
                block_status = "PARTIAL_FILLED_BLOCKED" if status == "PARTIAL_FILLED_BLOCKED" else "BLOCKED"
                self.ledger_store.update_workflow(status=block_status, blocked_reason=record.reason)
                raise WorkflowBlocked(f"Order {step['leg']} is not FILLED: {status}")
            self.ledger_store.update_workflow(next_index=index + 1)
            # This refresh is mandatory after every fill; it is the source of
            # truth for the next leg's sellable quantity/buying power.
            current = self._apply_virtual_fill(current, item, record) if self._virtual_buying_power is not None else refresh_portfolio()
            ledger = self.ledger_store.load()
            workflow = ledger["active_workflow"]
        self.ledger_store.update_workflow(status="READY_TO_COMMIT")
        return records, True

    def _broker_order_id(self, client_order_id: Optional[str]) -> Optional[str]:
        if not client_order_id:
            return None
        for order in self.ledger_store.load().get("orders", []):
            if order.get("client_order_id") == client_order_id:
                return order.get("broker_order_id")
        return None

    def _item_from_intent(self, workflow: Dict[str, Any], order: Dict[str, Any]) -> OrderItem:
        price = order.get("price")
        amount = order.get("requested_order_amount")
        return OrderItem(
            symbol=str(order["symbol"]), side=OrderSide(str(order["side"])),
            quantity=Decimal(str(order["requested_quantity"])), price=Decimal(str(price)) if price is not None else None,
            order_type=OrderType(str(order.get("order_type") or ("MARKET" if amount is not None else "LIMIT"))),
            reason=str(workflow.get("reason", "")), time_in_force=None if amount is not None else self._time_in_force_for(workflow),
            client_order_id=str(order["client_order_id"]),
            order_amount=Decimal(str(amount)) if amount is not None else None,
        )

    def _execution_deadline(self, workflow: Dict[str, Any]) -> datetime:
        policy = workflow["execution_policy"]
        return CloseExecution._deadline(policy) if workflow.get("execution_core") == "CLOSE" else MinuteExecution._time(policy, "new_leg_deadline")

    def _poll_pending_order(
        self, workflow: Dict[str, Any], item: OrderItem, ledger: Dict[str, Any], order_id: Optional[str],
    ) -> ExecutionRecord:
        if not order_id:
            raise WorkflowBlocked("Submitted order has no persisted broker orderId")
        while self._now_utc() < self._execution_deadline(workflow):
            record = self.order_manager.refresh_ledger_order(item, workflow["decision"], self.ledger_store, order_id)
            status = self._ledger_status(item.client_order_id)
            if record.status == OrderStatus.FILLED or status not in {"PENDING", "PENDING_CANCEL", "PENDING_REPLACE", "SUBMITTED"}:
                return record
            remaining = (self._execution_deadline(workflow) - self._now_utc()).total_seconds()
            if remaining <= 0:
                break
            self.sleep_fn(min(self.poll_interval_seconds, remaining))
        return self._reconcile_pending_at_deadline(workflow, item, order_id)

    def _ledger_status(self, client_order_id: Optional[str]) -> str:
        for order in self.ledger_store.load().get("orders", []):
            if order.get("client_order_id") == client_order_id:
                return str(order.get("status", "UNKNOWN"))
        return "UNKNOWN"

    def _reconcile_pending_at_deadline(self, workflow: Dict[str, Any], item: OrderItem, order_id: str) -> ExecutionRecord:
        record = self.order_manager.refresh_ledger_order(item, workflow["decision"], self.ledger_store, order_id)
        if record.status == OrderStatus.FILLED:
            return record
        if self.order_manager.execution_mode == ExecutionMode.LIVE:
            try:
                self.order_manager.broker_api.cancel_order(order_id)
            except Exception as exc:
                self.ledger_store.update_order(item.client_order_id or "", status="UNKNOWN", error=f"deadline cancel failed: {exc}")
                return ExecutionRecord(order_id, item.symbol, item.side, item.quantity, OrderStatus.PENDING, client_order_id=item.client_order_id, reason="Deadline cancel failed; trading blocked", strategy=workflow["decision"])
            record = self.order_manager.refresh_ledger_order(item, workflow["decision"], self.ledger_store, order_id)
            if record.status == OrderStatus.FILLED:
                return record
        return record

    def _apply_virtual_fill(self, portfolio: PortfolioState, item: OrderItem, record: ExecutionRecord) -> PortfolioState:
        """Keep DRY_RUN legs internally consistent without mutating broker state."""
        result = deepcopy(portfolio)
        amount = record.filled_amount or item.order_amount or (Decimal(item.quantity) * (record.average_filled_price or item.price or Decimal("0")))
        if item.side == OrderSide.SELL:
            self._virtual_buying_power = (self._virtual_buying_power or Decimal("0")) + amount
        else:
            self._virtual_buying_power = max(Decimal("0"), (self._virtual_buying_power or Decimal("0")) - amount)
        result.available_cash_usd = self._virtual_buying_power or Decimal("0")
        position = result.positions.get(item.symbol)
        if position is not None:
            position.quantity += record.filled_quantity if item.side == OrderSide.BUY else -record.filled_quantity
        return result

    def _record_intent(self, workflow: Dict[str, Any], item: OrderItem, leg: str) -> None:
        client_id = workflow_client_order_id(workflow, leg)
        item.client_order_id = client_id
        existing = self.ledger_store.load()
        if any(order.get("client_order_id") == client_id for order in existing["orders"]):
            raise WorkflowBlocked(f"Order intent already exists: {client_id}")
        self.ledger_store.append_intent({
            "client_order_id": client_id,
            "workflow_id": workflow["workflow_id"],
            "leg": leg,
            "symbol": item.symbol,
            "side": item.side.value,
            "requested_quantity": str(item.quantity),
            "requested_order_amount": str(item.order_amount) if item.order_amount is not None else None,
            "order_type": item.order_type.value,
            "price": str(item.price) if item.price is not None else None,
            "record_kind": "SIMULATED_INTENT" if self.order_manager.execution_mode == ExecutionMode.DRY_RUN else "LIVE_INTENT",
            "status": "INTENT_RECORDED",
        })

    def _ensure_unambiguous_client_order_ids(
        self, workflow: Dict[str, Any], ledger: Dict[str, Any],
    ) -> Dict[str, Any]:
        ids = workflow_step_client_ids(workflow)
        if len(ids) == len(set(ids)):
            return workflow
        workflow_orders = [
            order for order in ledger.get("orders", [])
            if order.get("workflow_id") == workflow.get("workflow_id")
        ]
        scheme = workflow.get("client_order_id_scheme", LEGACY_CLIENT_ORDER_ID_SCHEME)
        if scheme == LEGACY_CLIENT_ORDER_ID_SCHEME:
            steps = list(workflow.get("steps", []))
            step_legs = [str(step.get("leg", "")) for step in steps]
            orders_by_leg = {}
            safely_migratable = True
            first_unfilled_seen = False
            for leg in step_legs:
                matching = [order for order in workflow_orders if str(order.get("leg", "")) == leg]
                if len(matching) > 1:
                    safely_migratable = False
                    break
                order = matching[0] if matching else None
                if order is None:
                    first_unfilled_seen = True
                    continue
                if first_unfilled_seen:
                    # Sequential execution cannot have a later intent while an
                    # earlier leg has no intent. Treat such data as ambiguous.
                    safely_migratable = False
                    break
                expected_legacy_id = make_client_order_id(
                    str(workflow["workflow_id"]), leg, LEGACY_CLIENT_ORDER_ID_SCHEME,
                )
                if order.get("client_order_id") != expected_legacy_id:
                    safely_migratable = False
                    break
                orders_by_leg[leg] = order
                if order.get("status") != "FILLED":
                    first_unfilled_seen = True
            if len(orders_by_leg) != len(workflow_orders):
                safely_migratable = False
            if safely_migratable:
                overrides = {
                    leg: str(order.get("client_order_id"))
                    for leg, order in orders_by_leg.items()
                }
                next_index = 0
                for leg in step_legs:
                    order = orders_by_leg.get(leg)
                    if not order or order.get("status") != "FILLED":
                        break
                    next_index += 1
                changes = {
                    "client_order_id_scheme": CURRENT_CLIENT_ORDER_ID_SCHEME,
                    "legacy_client_order_id_overrides": overrides,
                    "client_order_id_migrated_from": LEGACY_CLIENT_ORDER_ID_SCHEME,
                    "client_order_id_migrated_at": datetime.now(timezone.utc).isoformat(),
                    # Repair the old collision path that could advance past a
                    # leg for which no durable intent was ever recorded.
                    "next_index": next_index,
                }
                if workflow.get("status") == "READY_TO_COMMIT" and next_index < len(steps):
                    changes.update(status="RUNNING", blocked_reason=None)
                self.ledger_store.update_workflow(**changes)
            if safely_migratable:
                upgraded = self.ledger_store.load().get("active_workflow") or {}
                upgraded_ids = workflow_step_client_ids(upgraded)
                if len(upgraded_ids) == len(set(upgraded_ids)):
                    return upgraded
        reason = (
            "Ambiguous legacy clientOrderId mapping; persisted orders require "
            "operator reconciliation and no new order may be submitted"
        )
        self.ledger_store.update_workflow(status="BLOCKED", blocked_reason=reason)
        raise WorkflowBlocked(reason)

    @staticmethod
    def _normalize_us_limit_price(price: Decimal) -> Decimal:
        """Compatibility normalizer for broker fakes in offline tests."""
        quantum = Decimal("0.0001") if price < Decimal("1") else Decimal("0.01")
        normalized = price.quantize(quantum, rounding=ROUND_DOWN)
        if normalized <= 0:
            raise WorkflowBlocked("Normalized LIMIT price is non-positive")
        return normalized

    def _step_price(self, workflow: Dict[str, Any], symbol: str, portfolio: PortfolioState, side: OrderSide) -> Decimal:
        core = workflow.get("execution_core")
        if core not in {"MINUTE", "CLOSE"}:
            price = portfolio.prices.get(symbol)
            if price is None or price <= 0:
                raise WorkflowBlocked(f"No valid price for {symbol}")
            return price
        try:
            reference = self.portfolio_adapter.get_execution_price(symbol)
        except Exception as exc:
            raise WorkflowBlocked(f"No valid current execution quote for {symbol}: {exc}") from exc
        # Both cores use the target symbol's execution quote, never the
        # strategy signal candle. Broker price/session restrictions still apply.
        multiplier = Decimal("1.001") if side == OrderSide.BUY else Decimal("0.999")
        candidate = reference * multiplier
        broker = getattr(self.order_manager, "broker_api", None)
        if broker and hasattr(broker, "normalize_limit_price"):
            return broker.normalize_limit_price(symbol, candidate, side.value)
        return self._normalize_us_limit_price(candidate)

    @staticmethod
    def _time_in_force_for(workflow: Dict[str, Any]) -> Optional[TimeInForce]:
        # KB requests omit a time-in-force field; this value is durable metadata.
        return None if workflow.get("execution_core") == "CLOSE" else TimeInForce.DAY

    def _prepare_step(self, workflow: Dict[str, Any], step: Dict[str, Any], portfolio: PortfolioState, ledger: Dict[str, Any]) -> Optional[OrderItem]:
        if not WorkflowReconciler.is_qld_workflow(workflow):
            raise WorkflowBlocked("Legacy workflow cannot prepare new orders")
        symbol = step["symbol"]

        if step["kind"] == "MAIN_AMOUNT_BUY":
            amount = Decimal(str(step.get("order_amount") or "0"))
            if amount <= 0:
                return None
            buying_power = self._virtual_buying_power if self._virtual_buying_power is not None else self.portfolio_adapter.get_buying_power()
            if amount > buying_power:
                raise WorkflowBlocked(
                    f"MAIN buy ${amount} exceeds actual post-fill USD buying power ${buying_power}"
                )
            reference = self._step_price(workflow, symbol, portfolio, OrderSide.BUY)
            return OrderItem(
                symbol=symbol, side=OrderSide.BUY, quantity=Decimal("0"),
                order_type=OrderType.LIMIT, time_in_force=None, price=reference,
                order_amount=amount, reason=workflow["reason"],
            )

        if step["kind"] in {"SAFE_CASH_BUY", "SAFE_CASH_SELL"}:
            quantity = Decimal(str(step.get("quantity") or "0"))
            if not quantity.is_finite() or quantity != quantity.to_integral_value():
                raise WorkflowBlocked("SAFE quantity must be finite whole shares")
            quantity = quantity.to_integral_value()
            if quantity <= 0:
                return None
            side = OrderSide.BUY if step["kind"] == "SAFE_CASH_BUY" else OrderSide.SELL
            reference = self._step_price(workflow, symbol, portfolio, side)
            if side == OrderSide.SELL:
                sellable = self.portfolio_adapter.get_sellable_quantity(symbol)
                if sellable < quantity:
                    raise WorkflowBlocked(f"Sellable SAFE quantity insufficient: {sellable} < {quantity}")
            else:
                buying_power = self._virtual_buying_power if self._virtual_buying_power is not None else self.portfolio_adapter.get_buying_power()
                if quantity * reference > buying_power:
                    raise WorkflowBlocked("SAFE parking buy exceeds actual USD buying power")
            return OrderItem(
                symbol=symbol, side=side, quantity=quantity,
                order_type=OrderType.LIMIT, time_in_force=TimeInForce.DAY,
                price=reference, reason=workflow["reason"],
            )

        raise WorkflowBlocked(f"Removed legacy order step cannot be prepared: {step['kind']}")

    def commit_confirmed_state(self, state_store: Any, portfolio: PortfolioState) -> Dict[str, Any]:
        """Idempotently apply a workflow only after all legs are FILLED."""
        ledger = self.ledger_store.load()
        workflow = ledger.get("active_workflow")
        if not workflow or workflow.get("status") != "READY_TO_COMMIT":
            raise WorkflowBlocked("No workflow ready to commit")
        if not WorkflowReconciler.is_qld_workflow(workflow):
            raise WorkflowBlocked("Legacy workflow cannot automatically commit or advance strategy state")
        state = state_store.load_state_strict()
        if state.get("last_completed_workflow_id") != workflow["workflow_id"]:
            state.update(workflow.get("pending_state_transition", {}))
            # This marker is committed atomically with strategy state before
            # the workflow is cleared.  A crash at any later point cannot
            # cause the same market date to start a second workflow.
            state["last_execution_date"] = workflow["signal_date"]
            state["last_completed_workflow_id"] = workflow["workflow_id"]
            state["last_account_snapshot"] = state_store.account_snapshot(portfolio)
            state_store.save_state(state)
        self.ledger_store.complete_workflow()
        return state
