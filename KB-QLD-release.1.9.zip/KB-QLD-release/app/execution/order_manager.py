import logging
import uuid
from datetime import datetime, timezone
from decimal import Decimal
from app.api.base_broker import BaseBrokerAPI
from app.models.common import ExecutionMode, OrderStatus, OrderType
from app.models.orders import ExecutionRecord, OrderItem
from app.storage.order_ledger_store import OrderLedgerStore

logger = logging.getLogger(__name__)


class OrderManager:
    """Manages order validation, duplicate prevention (clientOrderId), and execution across DRY_RUN and LIVE modes."""

    def __init__(
        self,
        broker_api: BaseBrokerAPI,
        execution_mode: ExecutionMode = ExecutionMode.DRY_RUN,
    ):
        self.broker_api = broker_api
        self.execution_mode = execution_mode

    def generate_client_order_id(self, date_str: str, symbol: str, side: str, index: int) -> str:
        """Generates an alphanumeric idempotency key (max 36 chars) for clientOrderId."""
        clean_date = date_str.replace("-", "")
        uid_part = uuid.uuid4().hex[:6]
        side_char = "B" if side.upper() == "BUY" else "S"
        key = f"O{clean_date}-{symbol}-{side_char}{index}-{uid_part}"
        return key[:36]

    def _execute_dry_run(self, item: OrderItem, strategy_name: str) -> ExecutionRecord:
        if item.order_amount is not None:
            if item.price is None or item.price <= 0:
                raise ValueError("DRY_RUN amount order requires a positive reference price")
            filled_quantity = item.order_amount / item.price
            filled_amount = item.order_amount
        else:
            filled_quantity = Decimal(item.quantity)
            filled_amount = (filled_quantity * item.price) if item.price else None
        logger.info(
            f"[DRY_RUN] SIMULATED ORDER: {item.side.value} {item.symbol} "
            f"{item.order_amount if item.order_amount is not None else item.quantity} "
            f"{'USD' if item.order_amount is not None else 'shares'} "
            f"@ {item.price or 'MARKET'} (clientOrderId={item.client_order_id})"
        )
        now_ts = datetime.now(timezone.utc)
        return ExecutionRecord(
            order_id=f"SIM-{uuid.uuid4().hex[:12]}",
            client_order_id=item.client_order_id,
            symbol=item.symbol,
            side=item.side,
            quantity=item.quantity,
            price=item.price,
            status=OrderStatus.FILLED,
            filled_quantity=filled_quantity,
            average_filled_price=item.price,
            filled_amount=filled_amount,
            commission=Decimal("0"),
            tax=Decimal("0"),
            ordered_at=now_ts,
            filled_at=now_ts,
            reason=item.reason,
            strategy=strategy_name,
            requested_amount=item.order_amount,
        )

    def submit_ledger_order(
        self,
        item: OrderItem,
        strategy_name: str,
        ledger: OrderLedgerStore,
    ) -> ExecutionRecord:
        """Submit one already-recorded intent and persist its observed status.

        This method deliberately does not retry an uncertain submission.  The
        caller must block the workflow when the broker cannot identify it.
        """
        if not item.client_order_id:
            raise ValueError("A durable order requires client_order_id")

        if self.execution_mode != ExecutionMode.LIVE:
            record = self._execute_dry_run(item, strategy_name)
            ledger.update_order(
                item.client_order_id,
                status="FILLED",
                broker_order_id=record.order_id,
                filled_quantity=str(record.filled_quantity),
                average_filled_price=str(record.average_filled_price) if record.average_filled_price is not None else None,
                filled_amount=str(record.filled_amount) if record.filled_amount is not None else None,
            )
            return record

        try:
            response = self.broker_api.create_order(
                symbol=item.symbol,
                side=item.side.value,
                order_type=item.order_type.value,
                quantity=None if item.order_amount is not None else item.quantity,
                price=str(item.price) if item.order_type == OrderType.LIMIT and item.price else None,
                time_in_force=item.time_in_force.value if item.time_in_force is not None else None,
                client_order_id=item.client_order_id,
                order_amount=str(item.order_amount) if item.order_amount is not None else None,
            )
            order_id = response.get("orderId")
            if not order_id:
                raise RuntimeError("Broker response missing orderId")
            ledger.update_order(item.client_order_id, status="SUBMITTED", broker_order_id=order_id)
        except Exception as exc:
            ledger.update_order(item.client_order_id, status="UNKNOWN", error=str(exc))
            return ExecutionRecord(
                order_id="UNKNOWN",
                client_order_id=item.client_order_id,
                symbol=item.symbol,
                side=item.side,
                quantity=item.quantity,
                status=OrderStatus.PENDING,
                reason="Submission result unknown; trading blocked",
                strategy=strategy_name,
                requested_amount=item.order_amount,
            )

        return self.refresh_ledger_order(item, strategy_name, ledger, order_id)

    def refresh_ledger_order(
        self,
        item: OrderItem,
        strategy_name: str,
        ledger: OrderLedgerStore,
        order_id: str,
    ) -> ExecutionRecord:
        """Read broker truth for a submitted order; no polling/retry occurs."""
        try:
            detail = self.broker_api.get_order_detail(order_id)
            raw_status = detail.get("status", "PENDING")
            execution = detail.get("execution", {})
            try:
                status = OrderStatus(raw_status)
            except ValueError:
                status = OrderStatus.PENDING
                raw_status = "UNKNOWN"
            filled_quantity = Decimal(str(execution.get("filledQuantity") or "0"))
            avg = execution.get("averageFilledPrice")
            amount = execution.get("filledAmount")
            ledger_status = raw_status
            integrity_error = None
            if raw_status == "FILLED":
                try:
                    avg_decimal = Decimal(str(avg)) if avg is not None else None
                    amount_decimal = Decimal(str(amount)) if amount is not None else None
                except Exception:
                    avg_decimal = amount_decimal = None
                quantity_mismatch = item.order_amount is None and filled_quantity != Decimal(item.quantity)
                if (
                    quantity_mismatch
                    or filled_quantity <= 0
                    or avg_decimal is None or avg_decimal <= 0
                    or amount_decimal is None or amount_decimal <= 0
                ):
                    integrity_error = (
                        f"FILLED execution integrity error: requested={item.quantity}, filled={filled_quantity}, "
                        f"averageFilledPrice={avg}, filledAmount={amount}"
                    )
                    ledger_status = "FILLED_INTEGRITY_ERROR"
                    status = OrderStatus.PENDING
            if raw_status != "FILLED" and filled_quantity > 0:
                ledger_status = "PARTIAL_FILLED_BLOCKED"
            ledger.update_order(
                item.client_order_id or "",
                status=ledger_status,
                broker_order_id=order_id,
                filled_quantity=str(filled_quantity),
                average_filled_price=str(avg) if avg is not None else None,
                filled_amount=str(amount) if amount is not None else None,
                error=integrity_error,
            )
            return ExecutionRecord(
                order_id=order_id,
                client_order_id=item.client_order_id,
                symbol=item.symbol,
                side=item.side,
                quantity=item.quantity,
                price=item.price,
                status=status,
                filled_quantity=filled_quantity,
                average_filled_price=Decimal(str(avg)) if avg is not None else None,
                filled_amount=Decimal(str(amount)) if amount is not None else None,
                reason=integrity_error or item.reason,
                strategy=strategy_name,
                requested_amount=item.order_amount,
            )
        except Exception as exc:
            ledger.update_order(item.client_order_id or "", status="UNKNOWN", error=str(exc))
            return ExecutionRecord(
                order_id=order_id,
                client_order_id=item.client_order_id,
                symbol=item.symbol,
                side=item.side,
                quantity=item.quantity,
                status=OrderStatus.PENDING,
                reason="Order detail unavailable; trading blocked",
                strategy=strategy_name,
                requested_amount=item.order_amount,
            )
