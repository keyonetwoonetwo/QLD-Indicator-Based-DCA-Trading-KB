import json
import os
import urllib.error
import urllib.request
from datetime import datetime, timezone, timedelta

MUTATIONS = {'skam2101','skam2102','skam2201','skam2202'}
READ_ONLY = {'spqm2226','skqm3350','gss10030','gsc10060','spqm2204',
             'spqm2103','spqm2205','spqm3390','skqm2106','spqn5472'}

class KBAPIClient:
    def __init__(self, base_url, auth_manager, account_binding=None, timeout_seconds=30, opener=None, now_fn=None):
        self.base_url=base_url.rstrip('/')
        self.auth_manager=auth_manager
        self.account_binding=account_binding
        self.timeout_seconds=timeout_seconds
        self._opener=opener or urllib.request.urlopen
        self._now=now_fn or (lambda:datetime.now(timezone.utc))
        self.order_deadline=None

    def set_account_binding(self,value): self.account_binding=value

    def request(self,method,path,params=None,json_data=None,require_account=False,**kwargs):
        tr=path.rsplit('/',1)[-1].lower()
        mutation=tr in MUTATIONS
        if tr not in MUTATIONS | READ_ONLY or path.lower()!='/api/v1/'+tr:
            raise RuntimeError('KB TR path is not approved; request blocked')
        if method.upper()!='POST': raise ValueError('KB TR requests use POST')
        if require_account and not self.account_binding: raise RuntimeError('KB account context not initialized')
        if mutation:
            from app.api.live_contract import require_live_contract, validate_mutation
            approved=require_live_contract(self.account_binding)
            if self.auth_manager.client_id!=approved.get('KB_CLIENT_ID') or self.auth_manager.client_secret!=approved.get('KB_CLIENT_SECRET'):
                raise RuntimeError('KB LIVE credentials differ from approved configuration')
            validate_mutation(tr,json_data or params or {},approved['MAIN_SYMBOL'],approved['SAFE_SYMBOL'])
        token=self.auth_manager.get_access_token()
        if not self.auth_manager.ip_addr or not self.auth_manager.mac_addr: raise RuntimeError('KB IP/MAC required')
        payload={'dataHeader':{'ipAddr':self.auth_manager.ip_addr,'macAddr':self.auth_manager.mac_addr},'dataBody':json_data or params or {}}
        def send(access_token):
            if mutation and tr in {'skam2101','skam2201'}:
                margin=float(os.getenv('KB_SEND_MARGIN_SECONDS','5'))
                if margin<1 or not self.order_deadline or self._now()+timedelta(seconds=margin)>=self.order_deadline: raise RuntimeError('KB submission deadline unavailable or reached')
            request=urllib.request.Request(self.base_url+path,data=json.dumps(payload).encode(),headers={'Authorization':f'Bearer {access_token}','Content-Type':'application/json'},method='POST')
            with self._opener(request,timeout=self.timeout_seconds) as response: return json.loads(response.read().decode())
        try: body=send(token)
        except urllib.error.HTTPError as error:
            if error.code==401 and not mutation:
                try: body=send(self.auth_manager.issue_token())
                except Exception: raise RuntimeError('KB read authentication retry failed') from None
            else: raise RuntimeError(f'KB HTTP {error.code}; request not replayed') from None
        except Exception: raise RuntimeError('KB transport failure; mutation not replayed') from None
        header=body.get('dataHeader',{}) if isinstance(body,dict) else {}
        if str(header.get('resultCode'))!='200' or header.get('processFlag')!='A': raise RuntimeError('KB business result requires review; not a zero balance')
        data=body.get('dataBody')
        if not isinstance(data,dict): raise RuntimeError('KB response missing dataBody')
        if str(data.get('cutn_mtr_err_cd','')).strip(): raise RuntimeError('KB order warning requires review')
        return data
