from datetime import datetime, time, timedelta
from functools import lru_cache
from zoneinfo import ZoneInfo

NY = ZoneInfo('America/New_York')

def session_timing(close, signal_time='15:58:00', order_cutoff='15:59:35'):
    if close.tzinfo is None:
        raise ValueError('Session close must have timezone')
    close = close.astimezone(NY)
    normal = close.replace(hour=16, minute=0, second=0, microsecond=0)
    h, m, s = map(int, signal_time.split(':'))
    offset = normal - normal.replace(hour=h, minute=m, second=s)
    if offset < timedelta(minutes=2):
        raise ValueError('Signal must start at least two minutes before close')
    signal = close - offset
    ch, cm, cs = map(int, order_cutoff.split(':'))
    admission = close - (normal - normal.replace(hour=ch, minute=cm, second=cs))
    if not signal + timedelta(minutes=1) < admission < close:
        raise ValueError('Session polling and cutoff must precede close')
    return dict(signal=signal, poll=signal+timedelta(minutes=1), admission=admission, close=close, execution=signal+timedelta(minutes=1, seconds=10))

@lru_cache(maxsize=8)
def _nyse_days(year):
    """Separate full closures from early closes; no federal-calendar fallback."""
    try:
        import holidays
        from holidays.constants import PUBLIC, HALF_DAY
        years=range(year-1,year+2)
        public=holidays.financial_holidays('XNYS',years=years,categories=PUBLIC)
        if not {PUBLIC,HALF_DAY}.issubset(public.supported_categories):
            raise RuntimeError('XNYS HALF_DAY unsupported')
        half=holidays.financial_holidays('XNYS',years=years,categories=HALF_DAY)
        if (set(public.categories)!={PUBLIC} or set(half.categories)!={HALF_DAY}
                or HALF_DAY not in half.supported_categories):
            raise RuntimeError('XNYS categories unavailable')
        closed,early=frozenset(public),frozenset(half)
        if closed & early:
            raise RuntimeError('XNYS PUBLIC/HALF_DAY overlap')
        return closed,early
    except Exception:
        raise RuntimeError('NYSE XNYS calendar generation failed or HALF_DAY unsupported; install holidays==0.97; no fallback') from None


def market_calendar(date_str=None):
    day = datetime.fromisoformat(date_str).date() if date_str else datetime.now(NY).date()
    # Historic exchange hours are outside this modern-session implementation.
    if day.year<2000 or day.year>2098:
        raise RuntimeError('NYSE calendar requires modern years 2000..2098')
    closed,early=_nyse_days(day.year)
    def is_open(value):
        return value.weekday()<5 and value not in closed
    def entry(value):
        return dict(date=value.isoformat(),regularMarket=dict(
            startTime=datetime.combine(value,time(9,30),NY).isoformat(),
            endTime=datetime.combine(value,time(13 if value in early else 16),NY).isoformat()))
    def neighbor(step):
        for offset in range(1,371):
            value=day+timedelta(days=step*offset)
            if is_open(value): return entry(value)
        raise RuntimeError('NYSE calendar unavailable or incomplete: adjacent business day')
    return dict(today=entry(day) if is_open(day) else dict(date=day.isoformat(),regularMarket=None),
                previousBusinessDay=neighbor(-1),nextBusinessDay=neighbor(1))
