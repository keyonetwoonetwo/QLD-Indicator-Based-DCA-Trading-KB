from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional


class BaseBrokerAPI(ABC):
    @abstractmethod
    def get_us_market_calendar(self, date_str: Optional[str] = None) -> Dict[str, Any]:
        """Fetch US market calendar."""
        pass

    @abstractmethod
    def get_candles(
        self,
        symbol: str,
        interval: str = "1d",
        count: int = 200,
        before: Optional[str] = None,
        adjusted: bool = True,
    ) -> Dict[str, Any]:
        """Fetch candle data."""
        pass

    @abstractmethod
    def get_prices(self, symbols: List[str]) -> List[Dict[str, Any]]:
        """Fetch current prices for symbols."""
        pass

    @abstractmethod
    def get_accounts(self) -> List[Dict[str, Any]]:
        """Fetch user accounts."""
        pass

    @abstractmethod
    def get_holdings(self, symbol: Optional[str] = None) -> Dict[str, Any]:
        """Fetch account holdings."""
        pass

    @abstractmethod
    def get_buying_power(self, currency: str = "USD") -> Dict[str, Any]:
        """Fetch cash buying power."""
        pass

    @abstractmethod
    def get_sellable_quantity(self, symbol: str) -> Dict[str, Any]:
        """Fetch broker-confirmed sellable quantity for a symbol."""
        pass

    @abstractmethod
    def create_order(
        self,
        symbol: str,
        side: str,
        order_type: str,
        quantity: Optional[int] = None,
        price: Optional[str] = None,
        time_in_force: Optional[str] = "DAY",
        client_order_id: Optional[str] = None,
        order_amount: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a new stock order."""
        pass

    @abstractmethod
    def get_orders(self, status: str = "OPEN", symbol: Optional[str] = None) -> List[Dict[str, Any]]:
        """Fetch order list."""
        pass

    @abstractmethod
    def get_order_detail(self, order_id: str) -> Dict[str, Any]:
        """Fetch order detail by order ID."""
        pass

    @abstractmethod
    def cancel_order(self, order_id: str) -> Dict[str, Any]:
        """Cancel an open broker order."""
        pass
