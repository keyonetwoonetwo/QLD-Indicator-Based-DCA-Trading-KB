"""Local validation/approval gates, never proof of first live execution."""
import hashlib
import json
import os
from decimal import Decimal, InvalidOperation
from pathlib import Path

CONTRACT_VERSION = 'KB_LIMIT_V1'
ROOT = Path(__file__).resolve().parents[2]


def check_validation_record(record, identity):
    if not isinstance(record,dict):
        raise RuntimeError('KB LIVE locked: validation record is invalid; run validate.sh again')
    digest=hashlib.sha256(json.dumps(identity,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    if (record.get('result')!='PASS' or record.get('execution_mode')!='DRY_RUN'
            or record.get('live_trading_enabled') is not False
            or record.get('kb_contract_version')!=CONTRACT_VERSION
            or record.get('identity_hash')!=digest
            or record.get('account_binding')!=identity.get('account_binding')
            or record.get('account_no')!=identity.get('account_no')):
        raise RuntimeError('KB LIVE locked: validation/account identity mismatch; run validate.sh again')
    return digest


def validate_mutation(code,body,main_symbol,safe_symbol):
    """Check documented KB wire fields without sending a trial order."""
    def positive(field,integer=False):
        try:
            value=Decimal(str(body.get(field,'')))
            if not value.is_finite() or value<=0 or (integer and value!=value.to_integral_value()):
                raise ValueError
        except (InvalidOperation,ValueError):
            raise RuntimeError('KB order contract invalid field='+field) from None
    if code in {'skam2101','skam2201'}:
        common={'is_cd','trd_dl_ccd','frgn_ordr_typ_cd','frgn_ordr_prc_p4'}
        expected=common|({'amt_q_clsf','crncy_ccd','ordr_amt'} if code=='skam2201' else {'frgn_ordr_q'})
        if set(body)!=expected or body.get('frgn_ordr_typ_cd')!='2':
            raise RuntimeError('KB LIMIT request fields/type mismatch')
        positive('frgn_ordr_prc_p4')
        if code=='skam2201':
            if (body.get('is_cd')!=main_symbol or body.get('trd_dl_ccd')!='02'
                    or body.get('amt_q_clsf')!='0' or body.get('crncy_ccd')!='1'):
                raise RuntimeError('KB MAIN requires USD amount LIMIT BUY')
            positive('ordr_amt')
        else:
            if body.get('is_cd')!=safe_symbol or body.get('trd_dl_ccd') not in {'01','02'}:
                raise RuntimeError('KB SAFE instrument/side mismatch')
            positive('frgn_ordr_q',True)
    elif code=='skam2202':
        if set(body)!={'orgn_ordr_no'}: raise RuntimeError('KB fractional cancel fields mismatch')
        positive('orgn_ordr_no',True)
    elif code=='skam2102':
        if (set(body)!={'crct_cncl_clsf','is_cd','orgn_ordr_no','frgn_ordr_prc_p4'}
                or body.get('crct_cncl_clsf')!='2' or body.get('is_cd')!=safe_symbol):
            raise RuntimeError('KB SAFE cancellation contract mismatch')
        positive('orgn_ordr_no',True); positive('frgn_ordr_prc_p4')
    else:
        raise RuntimeError('KB mutation TR is not approved')


def require_live_contract(binding=None):
    """Every mutation independently checks persisted mode, proof and app binding."""
    try:
        values={}
        for line in (ROOT/'.env').read_text(encoding='utf-8').splitlines():
            line=line.strip()
            if line and not line.startswith('#') and '=' in line:
                key,value=line.split('=',1); values[key.strip()]=value.strip().strip("'\"")
        if values.get('EXECUTION_MODE')!='LIVE' or values.get('LIVE_TRADING_ENABLED','').lower()!='true':
            raise ValueError
        for key in ('EXECUTION_MODE','LIVE_TRADING_ENABLED','KB_BAR_TIME_BASIS','KB_CLIENT_ID','KB_ACCOUNT_NO'):
            if key in os.environ and os.environ[key]!=values.get(key): raise ValueError
        if values.get('KB_BAR_TIME_BASIS')!='START_NY': raise ValueError
        from config.config import GenericStrategyConfig,normalize_kb_account_no
        account=normalize_kb_account_no(values.get('KB_ACCOUNT_NO'))
        key=values.get('KB_CLIENT_ID','')
        if not account or not key: raise ValueError
        expected=hashlib.sha256(('KB:'+key+':'+account).encode()).hexdigest()
        if binding!=expected: raise ValueError
        profile=GenericStrategyConfig(values['SIGNAL_SYMBOL'],values['MAIN_SYMBOL'],values['SAFE_SYMBOL'],
                                      signal_time=values['SIGNAL_TIME'])
        identity=profile.installation_identity(values['TRADING_SIGNAL_MODE'],account,expected)
        record=json.loads((ROOT/'data/dry_run_validation.json').read_text(encoding='utf-8'))
        digest=check_validation_record(record,identity)
        if values.get('KB_LIVE_IDENTITY_HASH')!=digest or values.get('KB_LIVE_CONTRACT_VERSION')!=CONTRACT_VERSION:
            raise ValueError
        return values
    except (OSError,ValueError,KeyError,TypeError):
        raise RuntimeError('KB LIVE locked: approval unverified or account/mode changed; use enable-live.sh') from None
