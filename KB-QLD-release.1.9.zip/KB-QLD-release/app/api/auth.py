"""KB OAuth JSON contract from token.json and revoke.json.

Authentication proves app credentials, not a particular configured account number.
"""
import json
import logging
import math
import os
import socket
import time
import urllib.error
import urllib.request


logger = logging.getLogger(__name__)


def _failure(message):
    # Only locally constructed diagnostics may reach logs or notifications.
    logger.error(message)
    raise RuntimeError(message) from None


def _server_diagnostic(result):
    """Map untrusted server codes/messages to fixed, non-sensitive labels."""
    known_codes = {'invalid_request', 'invalid_client', 'invalid_grant',
                   'unauthorized_client', 'unsupported_grant_type', 'invalid_scope',
                   'server_error', 'temporarily_unavailable',
                   '400', '401', '403', '408', '429', '500', '502', '503', '504'}
    header = result.get('dataHeader') if isinstance(result, dict) else None
    body = result.get('dataBody') if isinstance(result, dict) else None
    sources = [v for v in (result, header, body) if isinstance(v, dict)]
    code = 'unrecognized(redacted)'
    for source in sources:
        for field in ('error', 'errorCode', 'resultCode', 'processCode'):
            value = source.get(field)
            if isinstance(value, (str, int)) and str(value) in known_codes:
                code = str(value)
                break
        if code != 'unrecognized(redacted)':
            break
    # Never print the server text, even when its code was recognized.
    messages = [source.get(key) for source in sources
                for key in ('error_description', 'resultMessage', 'processMessage', 'message')]
    categories = {
        'invalid client': 'client_authentication_failed',
        'invalid_client': 'client_authentication_failed',
        'invalid client credentials': 'client_authentication_failed',
        '인증 실패': 'authentication_failed',
        '인증에 실패했습니다.': 'authentication_failed',
        'too many requests': 'rate_limited',
        'temporarily unavailable': 'temporarily_unavailable',
    }
    category = next((categories[m.strip().lower()] for m in messages
                     if isinstance(m, str) and m.strip().lower() in categories), 'redacted')
    return f'server_code={code} server_message_category={category}'


class KBAuthManager:
    def __init__(self, base_url, client_id, client_secret, timeout_seconds=30,
                 ip_addr=None, mac_addr=None, opener=None, clock=None):
        self.base_url = base_url.rstrip('/')
        self.client_id, self.client_secret = client_id, client_secret
        self.timeout_seconds = timeout_seconds
        self.ip_addr = ip_addr if ip_addr is not None else os.getenv('KB_IP_ADDR','')
        self.mac_addr = mac_addr if mac_addr is not None else os.getenv('KB_MAC_ADDR','')
        self._opener = opener or urllib.request.urlopen
        self._clock = clock or time.time
        self._access_token, self._expires_at = None, 0

    @property
    def has_valid_token(self):
        return bool(self._access_token and self._clock() < self._expires_at - 60)

    def get_access_token(self, force_refresh=False):
        if not force_refresh and self.has_valid_token:
            return self._access_token
        return self.issue_token()

    def _request(self, path, data):
        if not all((self.client_id,self.client_secret,self.ip_addr,self.mac_addr)):
            raise ValueError('KB credentials and KB_IP_ADDR/KB_MAC_ADDR must be configured')
        body = {'dataHeader':{'ipAddr':self.ip_addr,'macAddr':self.mac_addr},
                'dataBody':dict(appKey=self.client_id,appSecret=self.client_secret,**data)}
        request = urllib.request.Request(self.base_url+path,
            data=json.dumps(body).encode('utf-8'),
            headers={'Content-Type':'application/json','Accept':'application/json'},method='POST')
        try:
            with self._opener(request,timeout=self.timeout_seconds) as response:
                status = getattr(response, 'status', None)
                raw = b'' if isinstance(status,int) and not 200 <= status < 300 else response.read()
        except urllib.error.HTTPError as error:
            status = error.code if isinstance(error.code, int) and 100 <= error.code <= 599 else 'unknown'
            _failure(f'KB OAuth rejected: HTTP status={status}')
        except (TimeoutError, socket.timeout):
            _failure('KB OAuth transport timeout')
        except urllib.error.URLError as error:
            if isinstance(error.reason, (TimeoutError, socket.timeout)):
                _failure('KB OAuth transport timeout')
            _failure('KB OAuth transport connection_failed')
        except ConnectionError:
            _failure('KB OAuth transport connection_failed')
        except OSError:
            _failure('KB OAuth transport connection_failed')
        except Exception:
            _failure('KB OAuth transport failed: unexpected_transport_error')
        if isinstance(status, int) and not 200 <= status < 300:
            _failure(f'KB OAuth rejected: HTTP status={status if 100 <= status <= 599 else "unknown"}')
        try:
            result = json.loads(raw.decode('utf-8'))
        except (UnicodeError, ValueError, TypeError, AttributeError):
            _failure('KB OAuth response format invalid: JSON decoding/parsing failed')
        if not isinstance(result,dict):
            _failure('KB OAuth response format invalid: root must be an object')
        header = result.get('dataHeader')
        if not isinstance(header,dict):
            if result.get('error'):
                _failure('KB OAuth rejected: '+_server_diagnostic(result))
            _failure('KB OAuth response format invalid: dataHeader missing or invalid')
        if 'resultCode' not in header or 'processFlag' not in header:
            _failure('KB OAuth response format invalid: dataHeader resultCode/processFlag missing')
        if str(header.get('resultCode')) != '200' or header.get('processFlag') != 'A':
            _failure('KB OAuth rejected: '+_server_diagnostic(result))
        data = result.get('dataBody')
        if not isinstance(data,dict):
            _failure('KB OAuth response format invalid: dataBody missing or invalid')
        return data

    def issue_token(self):
        # Never keep using a token after a forced issuance failed.
        self._access_token, self._expires_at = None, 0
        data = self._request('/oauth2/token',{'grantType':'client_credentials'})
        token = data.get('access_token')
        if token is None or (isinstance(token,str) and not token.strip()):
            _failure('KB OAuth validation failed: access_token missing')
        if not isinstance(token,str):
            _failure('KB OAuth validation failed: access_token invalid type')
        token_type = data.get('token_type')
        if token_type is None or (isinstance(token_type,str) and not token_type.strip()):
            _failure('KB OAuth validation failed: token_type missing')
        if not isinstance(token_type,str) or token_type.lower() != 'bearer':
            _failure('KB OAuth validation failed: token_type unexpected')
        if data.get('expires_in') is None or (isinstance(data.get('expires_in'),str) and not data['expires_in'].strip()):
            _failure('KB OAuth validation failed: expires_in missing')
        try:
            lifetime = float(data.get('expires_in'))
        except (TypeError,ValueError,OverflowError):
            _failure('KB OAuth validation failed: expires_in invalid numeric')
        if not math.isfinite(lifetime):
            _failure('KB OAuth validation failed: expires_in invalid nonfinite')
        if lifetime <= 60:
            _failure('KB OAuth validation failed: expires_in invalid (must exceed 60 seconds)')
        self._access_token = token
        self._expires_at = self._clock()+lifetime
        return token

    def revoke_token(self):
        token = self._access_token
        self._access_token, self._expires_at = None, 0
        if not token:
            return
        result = self._request('/oauth2/revoke',{'token':token})
        if result.get('tokenRevoke') != 'Y':
            raise RuntimeError('KB token revocation not confirmed')
