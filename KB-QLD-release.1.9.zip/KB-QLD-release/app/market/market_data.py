import logging
from datetime import datetime
from decimal import Decimal
from typing import Dict, List, Optional
from zoneinfo import ZoneInfo
from app.api.base_broker import BaseBrokerAPI
from app.models.market import Candle
from config.defaults import NY_ZONE

logger = logging.getLogger(__name__)

NY_TZ = ZoneInfo(NY_ZONE)


class MarketDataService:
    """Service to fetch and prepare market candle charts and price quotes."""

    def __init__(self, broker_api: BaseBrokerAPI):
        self.broker_api = broker_api

    def fetch_daily_candles(
        self,
        symbol: str,
        target_count: int = 280,
        adjusted: bool = True,
    ) -> List[Candle]:
        """Fetches daily candles using KB API pagination until target_count is reached or no more candles.

        Returns candles sorted chronologically (oldest first, newest last).
        """
        all_raw_candles = []
        next_before: Optional[str] = None
        remaining = target_count

        while remaining > 0:
            fetch_count = min(remaining, 200)
            resp = self.broker_api.get_candles(
                symbol=symbol,
                interval="1d",
                count=fetch_count,
                before=next_before,
                adjusted=adjusted,
            )

            candles = resp.get("candles", [])
            if not candles:
                break

            all_raw_candles.extend(candles)
            remaining -= len(candles)
            next_before = resp.get("nextBefore")

            if not next_before or len(candles) < fetch_count:
                break

        parsed_candles: List[Candle] = []
        for item in all_raw_candles:
            try:
                ts = datetime.fromisoformat(item["timestamp"])
                c = Candle(
                    timestamp=ts,
                    open=Decimal(item["openPrice"]),
                    high=Decimal(item["highPrice"]),
                    low=Decimal(item["lowPrice"]),
                    close=Decimal(item["closePrice"]),
                    volume=Decimal(item["volume"]),
                    currency=item.get("currency", "USD"),
                )
                parsed_candles.append(c)
            except Exception as e:
                logger.warning(f"Error parsing candle item {item}: {e}")

        # Sort chronologically (oldest -> newest) based on timestamp
        parsed_candles.sort(key=lambda x: x.timestamp)
        logger.info(f"Fetched {len(parsed_candles)} daily candles for {symbol}.")
        return parsed_candles

    def fetch_intraday_candles(self, symbol: str, interval: str = "1m", count: int = 5) -> List[Candle]:
        """Fetch a small chronological intraday series for a time-specific signal."""
        resp = self.broker_api.get_candles(symbol=symbol, interval=interval, count=count, adjusted=True)
        parsed: List[Candle] = []
        for item in resp.get("candles", []):
            try:
                parsed.append(Candle(
                    timestamp=datetime.fromisoformat(item["timestamp"]), open=Decimal(item["openPrice"]),
                    high=Decimal(item["highPrice"]), low=Decimal(item["lowPrice"]),
                    close=Decimal(item["closePrice"]), volume=Decimal(item["volume"]),
                    currency=item.get("currency", "USD"),
                ))
            except Exception as exc:
                logger.warning("Error parsing intraday candle %s: %s", item, exc)
        return sorted(parsed, key=lambda candle: candle.timestamp)

    def fetch_session_minutes(self, symbol: str, market_date: str, max_pages: int = 3) -> List[Candle]:
        """Read the regular opening minute in one bounded KB request."""
        response = self.broker_api.get_candles(symbol=symbol, interval="1m", count=1000, adjusted=True)
        parsed = []
        seen = set()
        for item in response.get("candles", []):
            stamp = datetime.fromisoformat(item["timestamp"])
            if stamp.tzinfo is None:
                raise ValueError("Session minute must be timezone-aware")
            stamp = stamp.astimezone(NY_TZ)
            if stamp.isoformat() in seen:
                raise ValueError("Duplicate session minute")
            seen.add(stamp.isoformat())
            if stamp.date().isoformat() != market_date:
                continue
            parsed.append(Candle(stamp, Decimal(item["openPrice"]), Decimal(item["highPrice"]),
                                 Decimal(item["lowPrice"]), Decimal(item["closePrice"]),
                                 Decimal(item["volume"]), item.get("currency", "USD")))
        if not any(c.timestamp.time().isoformat() == "09:30:00" for c in parsed):
            raise ValueError("MAIN exact regular-session opening minute 09:30 unavailable")
        return sorted(parsed, key=lambda candle: candle.timestamp)

    @staticmethod
    def exclude_market_date(candles: List[Candle], market_date: str) -> List[Candle]:
        """Keep only confirmed candles strictly before the NY market date."""
        result = []
        for candle in candles:
            ny_dt = candle.timestamp.astimezone(NY_TZ) if candle.timestamp.tzinfo else candle.timestamp.replace(tzinfo=NY_TZ)
            if ny_dt.date().isoformat() < market_date:
                result.append(candle)
        return sorted(result, key=lambda candle: candle.timestamp)

    def fetch_current_prices(self, symbols: List[str]) -> Dict[str, Decimal]:
        """Fetches current prices for given symbols.

        Returns mapping: {symbol: Decimal(price)}
        """
        if not symbols:
            return {}

        resp = self.broker_api.get_prices(symbols)
        prices: Dict[str, Decimal] = {}
        for item in resp:
            sym = item.get("symbol")
            last_price = item.get("lastPrice")
            if sym and last_price is not None:
                prices[sym] = Decimal(str(last_price))

        logger.info(f"Fetched current prices: {prices}")
        return prices

    @staticmethod
    def assert_latest_daily_candle_confirmed(candles: List[Candle], current_market_date: str) -> None:
        """Verifies that the latest daily candle is confirmed for today's market date.

        Executed during After-Market hours. The latest candle's US Eastern date
        must strictly equal current_market_date.
        - If latest_date < current_market_date (API update delay): abort safely.
        - If latest_date > current_market_date (invalid/future): abort safely.
        - Only latest_date == current_market_date proceeds with strategy evaluation.
        """
        if not candles:
            raise ValueError("No daily candles available")

        latest_candle = max(candles, key=lambda x: x.timestamp)
        ts = latest_candle.timestamp

        # Convert to America/New_York timezone to determine actual US market date
        if ts.tzinfo is not None:
            ny_dt = ts.astimezone(NY_TZ)
        else:
            ny_dt = ts.replace(tzinfo=NY_TZ)

        latest_ny_date = ny_dt.date().isoformat()

        if latest_ny_date < current_market_date:
            raise ValueError(
                f"Latest daily candle ({latest_ny_date}) is from a prior trading day. "
                f"Confirmed daily candle for {current_market_date} is not yet available in API."
            )
        elif latest_ny_date > current_market_date:
            raise ValueError(
                f"Latest daily candle ({latest_ny_date}) has invalid future date beyond {current_market_date}."
            )

        logger.info(f"Daily candle confirmed: {latest_ny_date} == {current_market_date} (Close=${latest_candle.close})")
