import csv
import logging
from datetime import datetime
from pathlib import Path
from typing import List, Optional
from app.models.orders import ExecutionRecord, OrderPlan
from app.models.portfolio import PortfolioState

logger = logging.getLogger(__name__)

DAILY_HEADERS = [
    "date",
    "main_lifecycle_close",
    "signal_ma200",
    "position_state",
    "main_quantity",
    "main_average_price",
    "safe_quantity",
    "available_cash",
    "strategy",
    "decision",
    "reason",
]

TRADE_HEADERS = [
    "timestamp",
    "symbol",
    "side",
    "quantity",
    "order_id",
    "client_order_id",
    "status",
    "price",
    "average_filled_price",
    "filled_quantity",
    "amount",
    "commission",
    "tax",
    "reason",
    "strategy",
]


class CSVStore:
    """Manages appending daily analysis and trade history to CSV files."""

    def __init__(
        self,
        daily_history_file: str = "data/history/daily_history.csv",
        trade_history_file: str = "data/history/trade_history.csv",
    ):
        self.daily_file = Path(daily_history_file)
        self.trade_file = Path(trade_history_file)

        self._ensure_file(self.daily_file, DAILY_HEADERS)
        self._ensure_file(self.trade_file, TRADE_HEADERS)

    def _ensure_file(self, file_path: Path, headers: List[str]) -> None:
        file_path.parent.mkdir(parents=True, exist_ok=True)
        if not file_path.exists() or file_path.stat().st_size == 0:
            with open(file_path, "w", newline="", encoding="utf-8-sig") as f:
                writer = csv.writer(f)
                writer.writerow(headers)

    def record_daily_history(
        self,
        date_str: str,
        tqqq_close: Optional[float],
        tqqq_ma200: Optional[float],
        position_state: str,
        portfolio: PortfolioState,
        plan: OrderPlan,
    ) -> None:
        """Appends a daily summary record to daily_history.csv."""
        self._ensure_file(self.daily_file, DAILY_HEADERS)
        row = [
            date_str,
            f"{tqqq_close:.4f}" if tqqq_close is not None else "",
            f"{tqqq_ma200:.4f}" if tqqq_ma200 is not None else "",
            position_state,
            str(portfolio.main_quantity),
            str(portfolio.main_avg_price),
            str(portfolio.safe_quantity),
            f"{portfolio.available_cash_usd:.2f}",
            plan.strategy_name,
            plan.decision,
            plan.reason.replace("\n", " "),
        ]
        try:
            with open(self.daily_file, "a", newline="", encoding="utf-8-sig") as f:
                writer = csv.writer(f)
                writer.writerow(row)
            logger.info(f"Recorded daily history to {self.daily_file}")
        except Exception as e:
            logger.error(f"Failed to record daily history: {e}")

    def record_trade_history(self, records: List[ExecutionRecord]) -> None:
        """Appends trade records to trade_history.csv."""
        if not records:
            return

        self._ensure_file(self.trade_file, TRADE_HEADERS)
        try:
            with open(self.trade_file, "a", newline="", encoding="utf-8-sig") as f:
                writer = csv.writer(f)
                for r in records:
                    row = [
                        r.ordered_at.isoformat(),
                        r.symbol,
                        r.side.value,
                        str(r.quantity),
                        r.order_id,
                        r.client_order_id or "",
                        r.status.value,
                        str(r.price) if r.price is not None else "",
                        str(r.average_filled_price) if r.average_filled_price is not None else "",
                        str(r.filled_quantity),
                        str(r.filled_amount) if r.filled_amount is not None else "",
                        str(r.commission) if r.commission is not None else "",
                        str(r.tax) if r.tax is not None else "",
                        r.reason,
                        r.strategy,
                    ]
                    writer.writerow(row)
            logger.info(f"Recorded {len(records)} trade(s) to {self.trade_file}")
        except Exception as e:
            logger.error(f"Failed to record trade history: {e}")
