"""Generic strategy facade with separate signal and lifecycle assets."""
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any, Dict, Optional, Tuple

from config.config import GenericStrategyConfig, TradingConfig
from app.models.market import IndicatorResult
from app.models.common import OrderSide, OrderType
from app.models.orders import OrderItem, OrderPlan, StrategyDecision
from app.models.portfolio import PortfolioState


class GenericStrategy:
    def __init__(
        self,
        profile: GenericStrategyConfig,
        lifecycle_config: Optional[object] = None,
        trading_config: Optional[TradingConfig] = None,
    ) -> None:
        self.profile = profile
        self.strategy_name = "generic"
        self.trading = trading_config or TradingConfig()

    def _regime_indicator(self, indicator: IndicatorResult) -> IndicatorResult:
        if indicator.symbol != self.profile.signal_symbol:
            raise ValueError(f"GenericStrategy requires {self.profile.signal_symbol} indicator, got {indicator.symbol}")
        risk = Decimal(str(self.profile.risk_threshold))
        ma = indicator.ma200 * risk
        prev_ma = indicator.prev_ma200 * risk
        return IndicatorResult(
            symbol=indicator.symbol,
            current_close=indicator.current_close,
            ma200=ma,
            prev_close=indicator.prev_close,
            prev_ma200=prev_ma,
            is_above_ma200=indicator.current_close >= ma,
            is_prev_above_ma200=indicator.prev_close >= prev_ma,
            overheat_price=ma,
        )

    def evaluate(
        self, indicator: IndicatorResult, portfolio: PortfolioState,
        state_data: Dict[str, Any], lifecycle_price: Optional[Decimal] = None,
        main_open: Optional[Decimal] = None, fear_greed_score: Optional[Decimal] = None,
    ) -> Tuple[OrderPlan, Dict[str, Any]]:
        decision, plan = self.evaluate_decision(
            indicator, portfolio, state_data, lifecycle_price, main_open, fear_greed_score,
        )
        updated = dict(state_data)
        updated.update(decision.pending_state_transition)
        return plan, updated

    def evaluate_decision(
        self, indicator: IndicatorResult, portfolio: PortfolioState,
        state_data: Dict[str, Any], lifecycle_price: Optional[Decimal] = None,
        main_open: Optional[Decimal] = None, fear_greed_score: Optional[Decimal] = None,
    ) -> Tuple[StrategyDecision, OrderPlan]:
        lifecycle = lifecycle_price if lifecycle_price is not None else indicator.current_close
        if main_open is None or fear_greed_score is None:
            raise ValueError("Conditional accumulation requires MAIN open and CNN Fear & Greed score")
        if lifecycle <= 0 or main_open <= 0:
            raise ValueError("Conditional accumulation requires positive MAIN prices")
        regime_indicator = self._regime_indicator(indicator)
        regime = "RISK_ON" if regime_indicator.is_above_ma200 else "RISK_OFF"
        direction = "GREEN" if lifecycle >= main_open else "RED"
        low = self.trading.fear_greed_low_threshold
        high = self.trading.fear_greed_high_threshold
        band = "FG_LOW" if fear_greed_score < low else "FG_MID" if fear_greed_score < high else "FG_HIGH"
        condition_key = f"{regime}_{direction}_{band}_USD"
        amount = self.trading.buy_amounts[condition_key]
        code = "CONDITIONAL_ACCUMULATION" if amount > 0 else "SKIP_ZERO_AMOUNT"
        reason = (
            f"{condition_key}: buy ${amount} of {self.profile.main_symbol}"
            if amount > 0 else f"{condition_key}=0; configured no-purchase case"
        )
        orders = []
        if amount > 0:
            orders.append(OrderItem(
                symbol=self.profile.main_symbol, side=OrderSide.BUY, quantity=0,
                order_type=OrderType.LIMIT, time_in_force=None, price=lifecycle,
                order_amount=amount, reason=reason,
            ))
        transition = {
            "last_minute_decision": {
                "regime": regime, "main_direction": direction,
                "fear_greed_band": band, "fear_greed_score": str(fear_greed_score),
                "condition_key": condition_key, "configured_amount": str(amount),
            }
        }
        decision = StrategyDecision(
            strategy_name=self.strategy_name, decision=code, reason=reason,
            event="CONDITIONAL_ACCUMULATION", pending_state_transition=transition,
            signal_symbol=indicator.symbol, signal_close=indicator.current_close,
            signal_ma200=indicator.ma200, risk_on_price=regime_indicator.ma200,
            display_decision=code, regime=regime, main_direction=direction,
            fear_greed_band=band, fear_greed_score=fear_greed_score,
            configured_amount=amount, selected_amount=amount, condition_key=condition_key,
        )
        plan = OrderPlan(self.strategy_name, code, reason, orders)
        return decision, plan


def fetch_fear_greed() -> Tuple[Decimal, str, datetime]:
    """Return the CNN score through the existing third-party package."""
    import fear_greed
    payload = fear_greed.get()
    if not isinstance(payload, dict) or "score" not in payload:
        raise ValueError("fear-greed response has no numeric score")
    score = Decimal(str(payload["score"]))
    if not score.is_finite() or score < 0 or score > 100:
        raise ValueError("CNN Fear & Greed score must be between 0 and 100")
    return score, str(payload.get("rating") or ""), datetime.now(timezone.utc)
