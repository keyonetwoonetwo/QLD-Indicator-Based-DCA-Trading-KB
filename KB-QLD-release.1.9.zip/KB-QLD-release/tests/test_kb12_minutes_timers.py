from datetime import datetime, timedelta
from types import SimpleNamespace
import pytest
from app.api.kb_broker_api import KBBrokerAPI, NY
from app.market.market_data import MarketDataService
from app.runners.minute_runner import MinuteRunner
from scripts.setup_wizard import timer_unit
from scripts import recovery_scheduler


def bar(dt='20261012',tm='093000'):
    return dict(dt=dt,tm=tm,opn_prc_p4='100',hgh_prc_p4='101',lw_prc_p4='99',cls_prc_p4='100',vlm='10')


def kb(monkeypatch,rows):
    monkeypatch.setenv('KB_BAR_TIME_BASIS','START_NY')
    for s in ('QQQ','QLD'): monkeypatch.setenv('KB_EXCHANGE_'+s,'NAS' if s=='QQQ' else 'AMX')
    calls=[]
    def request(method,path,**kw):
        assert path=='/api/v1/gsc10060'
        calls.append(kw['json_data'])
        return {'out2':rows,'mrkt_prc_clsf':'15분지연'}
    return KBBrokerAPI(SimpleNamespace(request=request)),calls


@pytest.mark.parametrize('symbol',['QQQ','QLD'])
def test_target_requests_five_despite_delay_label(monkeypatch,symbol,caplog):
    broker,calls=kb(monkeypatch,[bar()])
    with caplog.at_level('INFO'):
        candles=MarketDataService(broker).fetch_intraday_candles(symbol,count=5)
    assert len(candles)==1 and calls[0]['rcrd_c']=='5'
    assert '15분지연' in caplog.text


def test_opening_single_thousand_request(monkeypatch):
    broker,calls=kb(monkeypatch,[bar(),bar(tm='155800')])
    result=MarketDataService(broker).fetch_session_minutes('QLD','2026-10-12')
    assert len(calls)==1 and calls[0]['rcrd_c']=='1000' and len(result)==2


def test_missing_opening_and_target_fail(monkeypatch):
    broker,calls=kb(monkeypatch,[bar(tm='155700')])
    market=MarketDataService(broker)
    with pytest.raises(ValueError,match='09:30'):
        market.fetch_session_minutes('QLD','2026-10-12')
    with pytest.raises(ValueError,match='unavailable'):
        MinuteRunner.select_signal_candle(market.fetch_intraday_candles('QQQ'),'2026-10-12','15:58:00')


def test_duplicate_and_future_fail(monkeypatch):
    broker,_=kb(monkeypatch,[bar(),bar()])
    with pytest.raises(RuntimeError,match='Duplicate'): broker.get_candles('QQQ','1m',5)
    broker,_=kb(monkeypatch,[bar(dt='20991012')])
    with pytest.raises(RuntimeError,match='future'): broker.get_candles('QQQ','1m',5)


def test_unfinished_candle_excluded(monkeypatch):
    now=datetime.now(NY).replace(second=0,microsecond=0)
    broker,_=kb(monkeypatch,[bar(dt=now.strftime('%Y%m%d'),tm=now.strftime('%H%M%S'))])
    assert broker.get_candles('QQQ','1m',5)['candles']==[]


@pytest.mark.parametrize('service',['kb-qld-trader.service','kb-qld-trader-backup.service'])
def test_install_and_restore_share_precise_template(service):
    assert recovery_scheduler.timer_unit is timer_unit
    content=timer_unit('test','Mon..Fri *-*-* 15:59:10 America/New_York',service)
    assert content.count('AccuracySec=1s')==content.count('RandomizedDelaySec=0')==1
    assert 'OnCalendar=Mon..Fri *-*-* 15:59:10 America/New_York' in content
    assert 'Unit='+service in content
