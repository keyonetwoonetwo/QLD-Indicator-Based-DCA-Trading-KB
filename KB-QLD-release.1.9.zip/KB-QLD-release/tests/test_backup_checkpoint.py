from types import SimpleNamespace

import pytest

from scripts import backup_common


class Notifier:
    def __init__(self):
        self.warnings = []

    def notify_warning(self, message):
        self.warnings.append(message)


@pytest.mark.parametrize("reason", ["PARTIAL", "UNKNOWN", "cancel result unconfirmed"])
def test_blocked_reconciliation_prevents_archive_creation(tmp_path, monkeypatch, reason):
    notifier = Notifier()

    def blocked_snapshot():
        backup_common.enforce_clean_checkpoint(
            SimpleNamespace(outcome="BLOCKED", message=reason), notifier, "wf-1",
        )
        raise AssertionError("snapshot must not continue")

    monkeypatch.setattr(backup_common, "snapshot_under_process_lock", blocked_snapshot)
    with pytest.raises(RuntimeError, match="clean backup blocked"):
        backup_common.build_archive(tmp_path)
    assert not list(tmp_path.glob("*.tar.gz"))
    assert notifier.warnings and "remains active" in notifier.warnings[0]
