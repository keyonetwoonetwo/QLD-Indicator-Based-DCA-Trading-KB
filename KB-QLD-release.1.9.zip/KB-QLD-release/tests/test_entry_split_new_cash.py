from decimal import Decimal
import pytest
from app.execution.workflow_executor import WorkflowExecutor, WorkflowBlocked
from app.execution.order_manager import OrderManager
from app.models.common import ExecutionMode, OrderSide, OrderType
from app.models.orders import OrderItem
from app.models.portfolio import PortfolioState


class Adapter:
    def get_buying_power(self):
        return Decimal("9")
    def get_execution_price(self, symbol):
        return Decimal("100")


def test_main_uses_actual_cash_not_safe_evaluation():
    executor = WorkflowExecutor(None, None, Adapter())
    with pytest.raises(WorkflowBlocked, match="actual post-fill"):
        step = {"kind": "MAIN_AMOUNT_BUY", "symbol": "QLD", "order_amount": "10"}
        executor._prepare_step({"reason": "test", "event": "CONDITIONAL_ACCUMULATION",
                                "execution_core": "MINUTE", "steps": [step]},
                               step, PortfolioState(safe_quantity=Decimal("100")), {})


def test_dry_run_fractional_amount_never_calls_broker():
    class NoOrders:
        def create_order(self, **kwargs):
            raise AssertionError("Real order forbidden")
    manager = OrderManager(NoOrders(), ExecutionMode.DRY_RUN)
    record = manager._execute_dry_run(OrderItem("QLD", OrderSide.BUY, Decimal("0"), order_type=OrderType.MARKET, price=Decimal("100"), order_amount=Decimal("12.34")), "generic")
    assert record.order_id.startswith("SIM-")
    assert record.filled_quantity == Decimal("0.1234")
    assert record.filled_amount == Decimal("12.34")
