"""Legacy workflows must remain readable, but can never trade or auto-complete."""
import json
from datetime import datetime, timezone
from decimal import Decimal
from types import SimpleNamespace

import pytest

from app.execution.order_manager import OrderManager
from app.execution.workflow_executor import WorkflowBlocked, WorkflowExecutor
from app.execution.workflow_reconciler import WorkflowReconciler
from app.models.common import ExecutionMode
from app.models.order_identity import workflow_client_order_id
from app.models.portfolio import PortfolioState
from app.storage.order_ledger_store import OrderLedgerStore
from app.storage.state_store import StateStore
from config.config import AppConfig, GenericStrategyConfig, StorageConfig


CASES = [
    ("ENTRY_SPLIT", "BUY_ENTRY_TRANCHE", "MINUTE"),
    ("OVERHEAT", "BUY_ENTRY_OVERHEAT", "MINUTE"),
    ("MILESTONE", "BUY_MILESTONE_PROFIT", "MINUTE"),
    ("DRAWDOWN", "BUY_SELL_PROCEEDS", "MINUTE"),
    ("RISK_OFF", "SELL_MAIN", "MINUTE"),
    ("RISK_ON_ENTRY", "BUY_ENTRY_SAFE", "MINUTE"),
    ("CONDITIONAL_ACCUMULATION", "MAIN_AMOUNT_BUY", "CLOSE"),
]
IDENTITY = {"account_no": "12345678", "account_binding": "7", "signal_symbol": "QQQ",
            "main_symbol": "QLD", "safe_symbol": "BIL", "signal_mode": "MINUTE", "signal_time": "15:55:00"}


def make_store(tmp_path, event="ENTRY_SPLIT", kind="BUY_ENTRY_TRANCHE", core="MINUTE", *, order=True, mode="LIVE"):
    step = {"leg": "LEG1", "kind": kind, "symbol": "QLD" if kind == "MAIN_AMOUNT_BUY" else "BIL",
            "quantity": "2", "order_amount": "12.34" if kind == "MAIN_AMOUNT_BUY" else None, "budget": "999"}
    active = {
        "workflow_id": "g-20261009-test", "execution_core": core, "event": event,
        "execution_mode": mode, "status": "RUNNING", "next_index": 0,
        "execution_policy": {"kind": "MINUTE_V1", "signal_time": "15:55:00",
                             "admission_deadline": "2026-10-09T20:00:00+00:00",
                             "new_leg_deadline": "2026-10-09T20:00:00+00:00"},
        "steps": [step], "signal_date": "2026-10-09", "decision": "test", "reason": "test",
        "strategy_name": "generic", "installation_identity": dict(IDENTITY),
        "pending_state_transition": {"cycle_state": "LEGACY", "last_milestone": 100},
    }
    store = OrderLedgerStore(tmp_path / "order_ledger.json")
    store.save({"schema_version": 1, "active_workflow": active, "orders": [], "workflow_history": []})
    if order:
        store.append_intent({"workflow_id": active["workflow_id"],
            "client_order_id": workflow_client_order_id(active, "LEG1"), "leg": "LEG1",
            "symbol": step["symbol"], "side": "SELL" if kind.startswith("SELL") else "BUY",
            "requested_quantity": "2", "broker_order_id": "ORDER-OLD", "status": "UNKNOWN"})
    return store


class QueryOnlyBroker:
    def __init__(self, status="FILLED"):
        self.status, self.queries = status, []
    def get_order_detail(self, order_id):
        self.queries.append(order_id)
        if self.status == "OFFLINE":
            raise RuntimeError("offline")
        filled = "2" if self.status == "FILLED" else "1" if self.status == "PARTIAL_FILLED" else "0"
        return {"status": self.status, "execution": {"filledQuantity": filled,
                "averageFilledPrice": "100" if filled != "0" else None,
                "filledAmount": str(Decimal(filled) * 100) if filled != "0" else None}}
    def create_order(self, *args, **kwargs):
        raise AssertionError("legacy must never create orders")
    def cancel_order(self, *args, **kwargs):
        raise AssertionError("legacy must never cancel orders")
    def get_prices(self, symbols):
        return [{"symbol": symbol, "lastPrice": "100"} for symbol in symbols]


class NeverSubmit(OrderManager):
    def submit_ledger_order(self, *args, **kwargs):
        raise AssertionError("legacy submit_ledger_order called")


@pytest.mark.parametrize("event,kind,core", CASES)
@pytest.mark.parametrize("order", [False, True])
def test_saved_legacy_resume_never_submits_and_preserves_workflow(tmp_path, event, kind, core, order):
    store = make_store(tmp_path, event, kind, core, order=order)
    steps = store.load()["active_workflow"]["steps"]
    steps.append(dict(steps[0], leg="UNSUBMITTED_NEXT_LEG"))
    store.update_workflow(steps=steps)
    before = store.load()["active_workflow"]
    broker = QueryOnlyBroker()
    executor = WorkflowExecutor(NeverSubmit(broker, ExecutionMode.LIVE), store, None)
    for _ in range(2):  # retry/restart must not resume a later leg
        with pytest.raises(WorkflowBlocked, match="query-only"):
            executor.resume(PortfolioState(), lambda: pytest.fail("legacy portfolio progression"))
    after = store.load()
    assert after["active_workflow"]["status"] == "BLOCKED"
    assert after["active_workflow"]["next_index"] == 0
    assert after["active_workflow"]["steps"] == before["steps"]
    assert after["active_workflow"]["pending_state_transition"] == before["pending_state_transition"]
    assert len(after["orders"]) == int(order)
    assert broker.queries == (["ORDER-OLD"] * 2 if order else [])
    if order:
        assert after["orders"][0]["status"] == "FILLED"


@pytest.mark.parametrize("method", ["reconcile_active", "pre_backup_cleanup"])
@pytest.mark.parametrize("status", ["PENDING", "PARTIAL_FILLED", "UNKNOWN", "FILLED", "CANCELED", "OFFLINE"])
def test_legacy_reconciles_without_cancel_clear_or_commit(tmp_path, method, status):
    store = make_store(tmp_path)
    broker = QueryOnlyBroker(status)
    result = getattr(WorkflowReconciler(store, broker), method)()
    assert result.outcome == "BLOCKED" and "manual review" in result.message
    assert broker.queries == ["ORDER-OLD"]
    assert store.load()["active_workflow"]["next_index"] == 0
    assert store.load()["workflow_history"] == []
    assert len(store.load()["orders"]) == 1


def test_legacy_commit_and_direct_prepare_are_blocked(tmp_path):
    store = make_store(tmp_path)
    store.update_workflow(status="READY_TO_COMMIT")
    executor = WorkflowExecutor(None, store, None)
    with pytest.raises(WorkflowBlocked, match="Legacy"):
        executor.commit_confirmed_state(None, PortfolioState())
    with pytest.raises(WorkflowBlocked, match="Legacy"):
        executor._prepare_step(store.load()["active_workflow"], store.load()["active_workflow"]["steps"][0], PortfolioState(), store.load())
    assert store.load()["active_workflow"] is not None


def test_legacy_dry_simulation_not_queried_or_erased(tmp_path):
    store = make_store(tmp_path, mode="DRY_RUN")
    order = store.load()["orders"][0]
    store.update_order(order["client_order_id"], broker_order_id="SIM-old")
    broker = QueryOnlyBroker()
    result = WorkflowReconciler(store, broker).reconcile_active()
    assert result.outcome == "BLOCKED" and broker.queries == []
    assert store.load()["active_workflow"] is not None


@pytest.mark.parametrize("kind", ["MAIN_AMOUNT_BUY", "SAFE_CASH_BUY", "SAFE_CASH_SELL"])
def test_current_qld_dry_workflow_still_executes(tmp_path, kind):
    store = make_store(tmp_path, "CONDITIONAL_ACCUMULATION", kind, order=False, mode="DRY_RUN")
    broker = QueryOnlyBroker()
    adapter = SimpleNamespace(get_execution_price=lambda _: Decimal("100"), get_sellable_quantity=lambda _: Decimal("10"))
    p = PortfolioState(available_cash_usd=Decimal("1000"), safe_quantity=Decimal("10"), prices={"BIL": Decimal("100")})
    executor = WorkflowExecutor(OrderManager(broker, ExecutionMode.DRY_RUN), store, adapter,
                                now_fn=lambda: datetime(2026, 10, 9, 19, 56, tzinfo=timezone.utc))
    records, completed = executor.resume(p, lambda: p)
    assert completed and len(records) == 1 and records[0].order_id.startswith("SIM-")
    assert records[0].filled_quantity == (Decimal("12.34") / Decimal("100.10") if kind == "MAIN_AMOUNT_BUY" else Decimal("2"))
    assert broker.queries == []


def test_run_system_queries_legacy_before_role_time_checks(tmp_path, monkeypatch):
    import app.main as main
    store = make_store(tmp_path, core="CLOSE")
    active = store.load()["active_workflow"]
    active["installation_identity"].update(signal_mode="CLOSE", signal_time="16:00:00", main_symbol="OLD")
    store.update_workflow(installation_identity=active["installation_identity"])
    state = StateStore(tmp_path / "state.json")
    state.initialize_approved_state({"installation_identity": active["installation_identity"],
                                    "last_account_snapshot": {"account_no": "12345678", "account_binding": "7"}})
    config = AppConfig(kb_account_no="12345678", strategy=GenericStrategyConfig("QQQ", "QLD", "BIL", signal_time="15:55:00"),
                       storage=StorageConfig(state_file=str(state.state_file_path), order_ledger_file=str(store.path),
                                             process_lock_file=str(tmp_path / "trader.lock")))
    broker = QueryOnlyBroker()
    errors = []
    notifier = SimpleNamespace(notify_startup=lambda **_: None, notify_error=lambda *a, **k: errors.append((a, k)))
    monkeypatch.setattr(main.AppConfig, "load", lambda: config)
    monkeypatch.setattr(main, "TelegramNotifier", lambda **_: notifier)
    monkeypatch.setattr(main, "KBAuthManager", lambda **_: None)
    monkeypatch.setattr(main, "KBAPIClient", lambda **_: None)
    monkeypatch.setattr(main, "KBBrokerAPI", lambda **_: broker)
    monkeypatch.setattr(main, "MarketDataService", lambda **_: None)
    monkeypatch.setattr(main, "PortfolioAdapter", lambda **_: SimpleNamespace(resolve_account_binding=lambda **_: 7))
    monkeypatch.setattr(main.OrderManager, "submit_ledger_order", lambda *a, **k: pytest.fail("legacy submission"))
    main.run_system()
    assert broker.queries == []
    assert store.load()["active_workflow"] is not None
    assert errors and not (tmp_path / "trader.lock").exists()


def test_account_mismatch_prevents_legacy_query():
    identity = dict(IDENTITY)
    with pytest.raises(RuntimeError, match="account mismatch"):
        WorkflowReconciler.assert_legacy_account(
            {"installation_identity": dict(IDENTITY, account_no="other")},
            {"installation_identity": identity}, identity)


def legacy_archive(tmp_path, store):
    from test_backup_recovery import archive, IDENTITY as OLD_IDENTITY
    store.update_workflow(installation_identity=dict(OLD_IDENTITY))
    return archive(tmp_path, ledger=store.path.read_bytes()), dict(OLD_IDENTITY)


def test_backup_recovery_queries_legacy_fills_but_never_installs_or_commits(tmp_path):
    from test_backup_recovery import context, Scheduler, VALUES, portfolio
    from scripts.recover_backup import recover
    store = make_store(tmp_path / "source", core="CLOSE")
    archive, _ = legacy_archive(tmp_path, store)
    broker, scheduler = QueryOnlyBroker(), Scheduler()
    root = tmp_path / "restored"
    with pytest.raises(RuntimeError, match="query-only"):
        recover(archive, root=root, values=dict(VALUES), context_factory=context(root, broker, portfolio()), scheduler=scheduler)
    assert broker.queries == ["ORDER-OLD"]
    assert not scheduler.installed and not (root / "data/state.json").exists()


def test_operator_cli_queries_legacy_and_returns_fail_closed(tmp_path, monkeypatch):
    from test_backup_recovery import context, portfolio, state_bytes
    from scripts import reconcile_workflow
    from app import notification
    store = make_store(tmp_path, core="CLOSE")
    _, old_identity = legacy_archive(tmp_path, store)
    state = StateStore(tmp_path / "state.json")
    state.state_file_path.write_bytes(state_bytes(old_identity))
    before = state.state_file_path.read_bytes()
    broker = QueryOnlyBroker()
    config, _, adapter, _, _, _ = context(tmp_path, broker, portfolio())()
    config.telegram_bot_token = config.telegram_chat_id = ""
    config.telegram_enabled = False
    current_identity = dict(old_identity, signal_mode="MINUTE", signal_time="15:55:00")
    monkeypatch.setattr(reconcile_workflow, "ROOT", tmp_path)
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(reconcile_workflow, "runtime_context", lambda: (config, broker, adapter, state, store, current_identity))
    monkeypatch.setattr(notification, "TelegramNotifier", lambda *a: SimpleNamespace(notify_warning=lambda *a: None))
    assert reconcile_workflow.main() == 2
    assert broker.queries == ["ORDER-OLD"]
    assert state.state_file_path.read_bytes() == before
    assert store.load()["active_workflow"]["next_index"] == 0


def test_restore_preserves_legacy_then_resume_blocks(tmp_path, monkeypatch):
    import sys
    from test_backup_recovery import context, portfolio
    from scripts import restore
    store = make_store(tmp_path / "source", core="CLOSE")
    archive, identity = legacy_archive(tmp_path, store)
    root = tmp_path / "destination"
    broker = QueryOnlyBroker()
    monkeypatch.setattr(sys, "argv", ["restore.py", str(archive)])
    monkeypatch.setattr(restore, "runtime_context", context(root, broker, portfolio(), identity))
    config = restore.runtime_context()[0]
    config.storage.state_file = str(root / "state.json")
    config.storage.order_ledger_file = str(root / "order_ledger.json")
    monkeypatch.setattr(restore, "runtime_context", lambda: (config, broker, None, None, None, identity))
    restore.main()
    restored = OrderLedgerStore(config.storage.order_ledger_file)
    assert restored.load()["active_workflow"]["execution_core"] == "CLOSE"
    assert broker.queries == []
    with pytest.raises(WorkflowBlocked, match="query-only"):
        WorkflowExecutor(NeverSubmit(broker, ExecutionMode.DRY_RUN), restored, None).resume(PortfolioState(), lambda: None)
    assert broker.queries == ["ORDER-OLD"] and restored.load()["active_workflow"] is not None


def test_initialize_cannot_replace_existing_legacy(tmp_path, monkeypatch):
    from scripts import initialize
    store = make_store(tmp_path)
    state = StateStore(tmp_path / "state.json")
    before = store.path.read_bytes()
    monkeypatch.setattr(initialize, "runtime_context", lambda **_: (None, QueryOnlyBroker(), None, state, store, IDENTITY))
    with pytest.raises(RuntimeError, match="already exists"):
        initialize.initialize_approved_state()
    assert store.path.read_bytes() == before


def test_missing_order_id_does_not_prevent_other_order_queries(tmp_path):
    store = make_store(tmp_path)
    data = store.load()
    data["active_workflow"]["steps"].append({"leg": "LEG2", "kind": "BUY_ENTRY_TRANCHE", "symbol": "BIL"})
    data["orders"][0]["broker_order_id"] = None
    second = dict(data["orders"][0], leg="LEG2", broker_order_id="ORDER-SECOND",
                  client_order_id=workflow_client_order_id(data["active_workflow"], "LEG2"))
    data["orders"].append(second)
    store.save(data)
    broker = QueryOnlyBroker()
    result = WorkflowReconciler(store, broker).reconcile_active()
    assert result.outcome == "BLOCKED" and broker.queries == ["ORDER-SECOND"]
    assert store.load()["orders"][0]["status"] == "UNKNOWN"
    assert store.load()["orders"][1]["status"] == "FILLED"
