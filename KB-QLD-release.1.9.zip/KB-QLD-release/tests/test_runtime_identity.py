from config.config import AMOUNT_KEYS, AppConfig, GenericStrategyConfig, account_fingerprint


def set_env(monkeypatch):
    for key, value in {
        "SIGNAL_SYMBOL": "QQQ", "MAIN_SYMBOL": "QLD", "SAFE_SYMBOL": "SGOV",
        "RISK_THRESHOLD": "1", "SIGNAL_TIME": "15:57:00", "TRADING_SIGNAL_MODE": "MINUTE",
    }.items():
        monkeypatch.setenv(key, value)
    for key in AMOUNT_KEYS:
        monkeypatch.setenv(key, "0")


def test_identity_preserves_v393_shape_without_removed_strategy_symbol():
    identity = GenericStrategyConfig("QQQ", "QLD", "SGOV").installation_identity("MINUTE", "123", 7)
    assert identity == {
        "signal_symbol": "QQQ", "main_symbol": "QLD", "safe_symbol": "SGOV",
        "signal_time": "15:58:00", "signal_mode": "MINUTE", "broker": "KB",
        "account_no": account_fingerprint("123"), "account_binding": "7",
    }
    assert "overheat_symbol" not in identity


def test_runtime_amount_change_does_not_change_identity(monkeypatch):
    set_env(monkeypatch)
    before = AppConfig.load()
    monkeypatch.setenv(AMOUNT_KEYS[0], "99")
    after = AppConfig.load()
    assert before.resolved_strategy().installation_identity("MINUTE", "123", 1) == after.resolved_strategy().installation_identity("MINUTE", "123", 1)
    assert after.trading.buy_amounts[AMOUNT_KEYS[0]] != before.trading.buy_amounts[AMOUNT_KEYS[0]]


def test_close_mode_is_rejected_for_trading(monkeypatch):
    set_env(monkeypatch)
    monkeypatch.setenv("TRADING_SIGNAL_MODE", "CLOSE")
    try:
        AppConfig.load()
    except ValueError as exc:
        assert "validation-only" in str(exc)
    else:
        raise AssertionError("CLOSE trading must be rejected")

