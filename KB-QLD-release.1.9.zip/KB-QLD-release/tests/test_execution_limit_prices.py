from decimal import Decimal

import pytest

from app.execution.workflow_executor import WorkflowBlocked, WorkflowExecutor
from app.models.common import OrderSide
from app.models.portfolio import PortfolioState


class Adapter:
    def __init__(self, price, cash="200"):
        self.price = Decimal(price)
        self.cash = Decimal(cash)
        self.symbols = []

    def get_execution_price(self, symbol):
        self.symbols.append(symbol)
        return self.price

    def get_buying_power(self, *args):
        return self.cash

    def get_sellable_quantity(self, symbol):
        return Decimal("7")


@pytest.mark.parametrize("core", ["MINUTE", "CLOSE"])
@pytest.mark.parametrize("side,expected", [(OrderSide.BUY, "100.10"), (OrderSide.SELL, "99.90")])
def test_common_limit_price(core, side, expected):
    adapter = Adapter("100")
    executor = WorkflowExecutor(None, None, adapter)
    portfolio = PortfolioState(prices={"SIGNAL": Decimal("999"), "TARGET": Decimal("1")})
    assert executor._step_price({"execution_core": core}, "TARGET", portfolio, side) == Decimal(expected)
    assert adapter.symbols == ["TARGET"]


@pytest.mark.parametrize("core", ["MINUTE", "CLOSE"])
@pytest.mark.parametrize("side,expected", [(OrderSide.BUY, "0.5005"), (OrderSide.SELL, "0.4995")])
def test_sub_dollar_precision(core, side, expected):
    executor = WorkflowExecutor(None, None, Adapter("0.5"))
    assert executor._step_price({"execution_core": core}, "TARGET", PortfolioState(), side) == Decimal(expected)


@pytest.mark.parametrize("core", ["MINUTE", "CLOSE"])
@pytest.mark.parametrize("kind", ["BUY_ENTRY_TRANCHE", "SELL_MAIN", "BUY_MILESTONE_PROFIT"])
def test_removed_order_calculations_fail_closed(core, kind):
    executor = WorkflowExecutor(None, None, Adapter("100"))
    step = {"symbol": "TARGET", "kind": kind, "leg": "legacy", "quantity": 7, "budget": "200"}
    workflow = {"execution_core": core, "event": "CONDITIONAL_ACCUMULATION", "steps": [step], "reason": "test"}
    with pytest.raises(WorkflowBlocked, match="Legacy"):
        executor._prepare_step(workflow, step, PortfolioState(), {"orders": []})


@pytest.mark.parametrize("core", ["MINUTE", "CLOSE"])
def test_missing_quote_remains_fail_closed(core):
    class Missing(Adapter):
        def get_execution_price(self, symbol):
            raise RuntimeError("unavailable")

    with pytest.raises(WorkflowBlocked):
        WorkflowExecutor(None, None, Missing("100"))._step_price(
            {"execution_core": core}, "TARGET", PortfolioState(), OrderSide.BUY,
        )
