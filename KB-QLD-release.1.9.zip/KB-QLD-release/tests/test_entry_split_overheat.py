from decimal import Decimal

import pytest

from app.execution.workflow_executor import WorkflowBlocked, WorkflowExecutor
from app.models.market import IndicatorResult
from app.models.orders import OrderPlan, StrategyDecision
from app.models.portfolio import PortfolioState
from app.strategy.generic_strategy import GenericStrategy
from config.config import AMOUNT_KEYS, GenericStrategyConfig, TradingConfig


def indicator(close="101", ma="100"):
    return IndicatorResult("SIGNAL", Decimal(close), Decimal(ma), Decimal("99"), Decimal(ma), False, False, Decimal("0"))


@pytest.mark.parametrize(
    ("close", "main_open", "main_close", "score", "key"),
    [
        ("101", "10", "11", "9.99", "RISK_ON_GREEN_FG_LOW_USD"),
        ("101", "10", "9", "10", "RISK_ON_RED_FG_MID_USD"),
        ("99", "10", "10", "45", "RISK_OFF_GREEN_FG_HIGH_USD"),
        ("99", "10", "9", "9", "RISK_OFF_RED_FG_LOW_USD"),
    ],
)
def test_conditional_strategy_selects_one_independent_amount(close, main_open, main_close, score, key):
    amounts = {name: Decimal("0") for name in AMOUNT_KEYS}
    amounts[key] = Decimal("12.34")
    strategy = GenericStrategy(
        GenericStrategyConfig(signal_symbol="SIGNAL", main_symbol="MAIN", safe_symbol="SAFE"),
        trading_config=TradingConfig(buy_amounts=amounts),
    )
    decision, plan = strategy.evaluate_decision(
        indicator(close), PortfolioState(), {}, Decimal(main_close), Decimal(main_open), Decimal(score),
    )
    assert decision.condition_key == key
    assert len(plan.orders) == 1
    assert plan.orders[0].symbol == "MAIN"
    assert plan.orders[0].order_amount == Decimal("12.34")
    assert plan.orders[0].side.value == "BUY"


def test_zero_amount_creates_no_main_order():
    decision, plan = GenericStrategy(GenericStrategyConfig(signal_symbol="SIGNAL")).evaluate_decision(
        indicator(), PortfolioState(), {}, Decimal("10"), Decimal("10"), Decimal("50"),
    )
    assert decision.decision == "SKIP_ZERO_AMOUNT"
    assert plan.orders == []


def test_removed_legacy_event_and_close_cannot_start_new_workflow():
    executor = WorkflowExecutor(None, type("Ledger", (), {"load": lambda self: {"active_workflow": None}})(), None)
    legacy = StrategyDecision("generic", "RISK_OFF", "removed", "RISK_OFF")
    with pytest.raises(WorkflowBlocked, match="MINUTE-only"):
        executor.start("2026-10-09", legacy, OrderPlan("generic", "RISK_OFF", "removed"), PortfolioState(), "CLOSE")
