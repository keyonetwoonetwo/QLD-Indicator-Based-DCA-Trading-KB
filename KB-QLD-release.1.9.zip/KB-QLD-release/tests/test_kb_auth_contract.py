import json
import unittest
from unittest.mock import Mock
from app.api.auth import KBAuthManager


class AuthContractTests(unittest.TestCase):
    def setUp(self):
        self.requests=[]
        self.responses=[]
        self.now=1000
        def opener(request,timeout):
            self.requests.append(request)
            response=Mock()
            response.__enter__=Mock(return_value=response)
            response.__exit__=Mock(return_value=False)
            response.read.return_value=json.dumps(self.responses.pop(0)).encode()
            return response
        self.auth=KBAuthManager('https://example.invalid','test-app','test-secret',
            ip_addr='127.0.0.1',mac_addr='00:00:00:00:00:00',opener=opener,clock=lambda:self.now)

    def reply(self,body):
        self.responses.append({'dataHeader':{'resultCode':'200','processFlag':'A'},'dataBody':body})

    def token_reply(self,value='test-token'):
        self.reply(dict(access_token=value,token_type='Bearer',expires_in=86400))

    def test_issue_cache_and_refresh(self):
        self.token_reply()
        self.assertEqual(self.auth.get_access_token(),'test-token')
        self.auth.get_access_token()
        self.assertEqual(len(self.requests),1)
        request=self.requests[0]
        self.assertEqual(request.method,'POST')
        self.assertEqual(request.get_header('Content-type'),'application/json')
        payload=json.loads(request.data)
        self.assertEqual(payload['dataBody'],dict(appKey='test-app',appSecret='test-secret',grantType='client_credentials'))
        self.now+=86400
        self.token_reply('renewed')
        self.assertEqual(self.auth.get_access_token(),'renewed')

    def test_revoke_contract_and_clear(self):
        self.token_reply()
        self.auth.get_access_token()
        self.reply({'tokenRevoke':'Y'})
        self.auth.revoke_token()
        self.assertFalse(self.auth.has_valid_token)
        self.assertTrue(self.requests[-1].full_url.endswith('/oauth2/revoke'))
        self.assertEqual(json.loads(self.requests[-1].data)['dataBody']['token'],'test-token')

    def test_rejected_response_cannot_cache_token(self):
        self.responses.append({'dataHeader':{'resultCode':'403','processFlag':'F'},'dataBody':{'access_token':'secret'}})
        with self.assertRaises(RuntimeError): self.auth.issue_token()
        self.assertFalse(self.auth.has_valid_token)

    def test_malformed_lifetime(self):
        self.reply(dict(access_token='token',token_type='Bearer',expires_in='NaN'))
        with self.assertRaises(RuntimeError): self.auth.issue_token()

    def test_failed_revoke_still_clears_local_cache(self):
        self.token_reply()
        self.auth.issue_token()
        self.reply({'tokenRevoke':'N'})
        with self.assertRaises(RuntimeError): self.auth.revoke_token()
        self.assertFalse(self.auth.has_valid_token)

    def test_network_error_does_not_disclose_secrets(self):
        self.auth._opener=Mock(side_effect=RuntimeError('test-secret sensitive body'))
        with self.assertRaises(RuntimeError) as error: self.auth.issue_token()
        self.assertNotIn('test-secret',str(error.exception))

if __name__=='__main__': unittest.main()
