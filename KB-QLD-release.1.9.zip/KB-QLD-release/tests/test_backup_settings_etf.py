"""Isolated backup/settings/ETF regression checks: no order or cancel API."""
import json
import os
from pathlib import Path
from types import SimpleNamespace

import pytest

from config.config import AppConfig, AMOUNT_KEYS, TRADING_BACKUP_KEYS
from scripts import backup_common, recover_backup
from scripts.release_common import read_env
from app.storage.state_store import StateStore, StateIntegrityError
from test_backup_recovery import (
    IDENTITY, Broker, Scheduler, context, ledger_bytes, portfolio, state_bytes, write_env,
)


BASE = dict(
    EXECUTION_MODE="DRY_RUN", LIVE_TRADING_ENABLED="false",
    SIGNAL_SYMBOL="SIG", MAIN_SYMBOL="MAIN", SAFE_SYMBOL="SAFE",
    TRADING_SIGNAL_MODE="MINUTE", SIGNAL_TIME="15:55:00",
    MINUTE_ORDER_CUTOFF="15:58:00", RISK_THRESHOLD="1", BACKUP_TIME="16:10:00",
    KB_CLIENT_SECRET="keep-secret", KB_ACCOUNT_NO="12345678",
    TELEGRAM_BOT_TOKEN="keep-token",
)
MINUTE_ID = dict(IDENTITY, signal_mode="MINUTE", signal_time="15:55:00")
CSV = b"date,symbol,amount,quantity,price,fee,kind\n2026-10-01,MAIN,10,0.1,100,0,SIMULATED_INTENT\n"


@pytest.fixture(autouse=True)
def isolated_environment():
    before = dict(os.environ)
    try:
        yield
    finally:
        os.environ.clear()
        os.environ.update(before)


class QueryBroker(Broker):
    def __init__(self, opens=None):
        super().__init__()
        self.opens = opens or []

    def get_orders(self, **kwargs):
        return self.opens

    def cancel_order(self, *args, **kwargs):
        raise AssertionError("never cancel")


def bundle(tmp_path, monkeypatch, settings=None, identity=None, history=CSV, ledger=None):
    data = {
        "state.json": state_bytes(identity or MINUTE_ID),
        "order_ledger.json": ledger or ledger_bytes(),
        "trading_settings.json": json.dumps(settings or {
            k: v for k, v in BASE.items() if k in TRADING_BACKUP_KEYS
        }).encode(),
    }
    if history is not None:
        data["trade_history.csv"] = history
    monkeypatch.setattr(backup_common, "snapshot_under_process_lock", lambda: (data, identity or MINUTE_ID))
    (tmp_path / "archives").mkdir(exist_ok=True)
    return backup_common.build_archive(tmp_path / "archives")[0]


def factory(root, broker=None, actual=None):
    def create():
        values = read_env(root / ".env")
        identity = dict(MINUTE_ID, **{k.lower(): values[k] for k in (
            "SIGNAL_SYMBOL", "MAIN_SYMBOL", "SAFE_SYMBOL",
        )}, signal_time=values["SIGNAL_TIME"], signal_mode=values["TRADING_SIGNAL_MODE"])
        return context(root, broker or QueryBroker(), actual, identity)()
    return create


def restore(tmp_path, monkeypatch, *, settings=None, current=None, answers=(), scheduler=None,
            identity=None, history=CSV, ledger=None, broker=None, actual=None):
    root = tmp_path / "project"
    values = dict(BASE, **(current or {}))
    write_env(root, values)
    path = bundle(tmp_path, monkeypatch, settings, identity, history, ledger)
    choices = iter(answers)
    report = recover_backup.recover(
        path, root=root, values=values, context_factory=factory(root, broker, actual),
        scheduler=scheduler or Scheduler(), input_fn=lambda _: next(choices),
    )
    return root, report


def test_snapshot_whitelist_and_optional_history(tmp_path, monkeypatch):
    root = tmp_path / "project"
    write_env(root, dict(BASE, **{AMOUNT_KEYS[0]: "12"}))
    data = root / "data"
    data.mkdir()
    (data / "state.json").write_bytes(state_bytes(MINUTE_ID))
    (data / "order_ledger.json").write_bytes(ledger_bytes())
    config = SimpleNamespace(storage=SimpleNamespace(
        state_file=str(data / "state.json"), order_ledger_file=str(data / "order_ledger.json"),
        process_lock_file=str(data / "trader.lock"),
        trade_history_file=str(data / "history" / "trade_history.csv"),
    ))
    monkeypatch.setattr(backup_common, "ROOT", root)
    monkeypatch.setattr(AppConfig, "load", lambda: config)
    monkeypatch.chdir(root)
    files, _ = backup_common.snapshot_under_process_lock()
    saved = json.loads(files["trading_settings.json"])
    assert saved[AMOUNT_KEYS[0]] == "12"
    assert set(saved) <= set(TRADING_BACKUP_KEYS)
    assert not any(k in saved for k in ("KB_CLIENT_SECRET", "KB_ACCOUNT_NO", "TELEGRAM_BOT_TOKEN", "EXECUTION_MODE", "LIVE_TRADING_ENABLED"))
    assert b"keep-secret" not in files["trading_settings.json"]
    assert "trade_history.csv" not in files
    (data / "history").mkdir()
    (data / "history" / "trade_history.csv").write_bytes(CSV)
    (data / "dry_run_validation.json").write_text('{"status":"DRY_RUN"}')
    files, _ = backup_common.snapshot_under_process_lock()
    assert files["trade_history.csv"] == CSV
    assert "dry_run_validation.json" in files
    write_env(root, dict(BASE, MAIN_SYMBOL="UNAPPROVED"))
    with pytest.raises(RuntimeError, match="unapproved"):
        backup_common.snapshot_under_process_lock()


def test_same_etf_no_question_settings_history_restore(tmp_path, monkeypatch):
    settings = {k: v for k, v in BASE.items() if k in TRADING_BACKUP_KEYS}
    settings[AMOUNT_KEYS[0]] = "35"
    scheduler = Scheduler()
    root, report = restore(tmp_path, monkeypatch, settings=settings, scheduler=scheduler)
    saved = read_env(root / ".env")
    assert saved[AMOUNT_KEYS[0]] == "35"
    assert saved["KB_CLIENT_SECRET"] == "keep-secret"
    assert saved["TELEGRAM_BOT_TOKEN"] == "keep-token"
    assert saved["EXECUTION_MODE"] == "DRY_RUN" and saved["LIVE_TRADING_ENABLED"] == "false"
    assert (root / "data/history/trade_history.csv").read_bytes() == CSV
    assert not scheduler.quiesced and not scheduler.installed


@pytest.mark.parametrize("answer,expected", [("y", "MAIN"), ("N", "NEW")])
def test_etf_restore_choice_retains_past_symbols(tmp_path, monkeypatch, answer, expected):
    root, report = restore(tmp_path, monkeypatch, current={"MAIN_SYMBOL": "NEW"}, answers=[answer])
    assert read_env(root / ".env")["MAIN_SYMBOL"] == expected
    assert report["identity"]["main_symbol"] == expected
    assert b",MAIN," in (root / "data/history/trade_history.csv").read_bytes()


@pytest.mark.parametrize("answer,installed", [("y", True), ("N", False)])
def test_time_choice_reuses_existing_scheduler(tmp_path, monkeypatch, answer, installed):
    scheduler = Scheduler()
    root, _ = restore(tmp_path, monkeypatch, current={"SIGNAL_TIME": "15:54:00"},
                      answers=[answer], scheduler=scheduler)
    assert scheduler.installed is installed
    assert read_env(root / ".env")["SIGNAL_TIME"] == ("15:55:00" if installed else "15:54:00")
    if installed:
        assert scheduler.values["BACKUP_TIME"] == BASE["BACKUP_TIME"]


def test_scheduler_failure_rolls_back_all_data(tmp_path, monkeypatch):
    root = tmp_path / "project"
    values = dict(BASE, SIGNAL_TIME="15:54:00")
    write_env(root, values)
    original_env = (root / ".env").read_bytes()
    (root / "data/history").mkdir(parents=True)
    prior_csv = CSV.replace(b"2026-10-01", b"2026-10-02")
    (root / "data/history/trade_history.csv").write_bytes(prior_csv)
    path = bundle(tmp_path, monkeypatch)
    scheduler = Scheduler(fail=True)
    with pytest.raises(RuntimeError, match="scheduler failed"):
        recover_backup.recover(path, root=root, values=values, context_factory=factory(root),
                               scheduler=scheduler, input_fn=lambda _: "y")
    assert scheduler.rolled_back
    assert (root / ".env").read_bytes() == original_env
    assert (root / "data/history/trade_history.csv").read_bytes() == prior_csv
    assert not (root / "data/state.json").exists()
    assert not (root / "data/order_ledger.json").exists()


def test_history_merge_never_erases_newer_rows(tmp_path, monkeypatch):
    root = tmp_path / "project"
    write_env(root, BASE)
    (root / "data/history").mkdir(parents=True)
    (root / "data/history/trade_history.csv").write_bytes(CSV.replace(b"2026-10-01", b"2026-10-02"))
    path = bundle(tmp_path, monkeypatch)
    recover_backup.recover(path, root=root, values=BASE, context_factory=factory(root), scheduler=Scheduler())
    history = (root / "data/history/trade_history.csv").read_bytes()
    assert b"2026-10-01" in history and b"2026-10-02" in history
    assert history.count(b"SIMULATED_INTENT") == 2


@pytest.mark.parametrize("settings", [
    {"KB_CLIENT_SECRET": "bad"}, {"LIVE_TRADING_ENABLED": "true"},
    {AMOUNT_KEYS[0]: "-1"}, {"BACKUP_TIME": "99:99:99"},
])
def test_unsafe_settings_fail_before_mutation(tmp_path, monkeypatch, settings):
    root = tmp_path / "project"
    write_env(root, BASE)
    before = (root / ".env").read_bytes()
    path = bundle(tmp_path, monkeypatch, settings=settings)
    with pytest.raises((RuntimeError, ValueError)):
        recover_backup.recover(path, root=root, values=BASE, context_factory=factory(root),
                               scheduler=Scheduler(), input_fn=lambda _: "y")
    assert (root / ".env").read_bytes() == before
    assert not (root / "data/state.json").exists()


@pytest.mark.parametrize("status", ["UNKNOWN", "PARTIAL_FILLED", "SUBMITTED", "INTENT_RECORDED", "UNRECOGNIZED"])
def test_direct_etf_change_blocks_unconfirmed_orders(tmp_path, status):
    store = StateStore(tmp_path / "state.json")
    state = json.loads(state_bytes(MINUTE_ID))
    new = dict(MINUTE_ID, main_symbol="NEW")
    with pytest.raises(StateIntegrityError, match="unresolved"):
        store.apply_symbol_change(state, new, {"orders": [{"status": status}]},
                                  QueryBroker(), portfolio(), "2026-10-12")
    assert not store.state_file_path.exists()


def test_direct_etf_change_clean_checkpoint(tmp_path):
    store = StateStore(tmp_path / "state.json")
    state = json.loads(state_bytes(MINUTE_ID))
    state["last_execution_date"] = "2026-10-09"
    new = dict(MINUTE_ID, main_symbol="NEW", safe_symbol="NEW_SAFE")
    result = store.apply_symbol_change(state, new, {"orders": []}, QueryBroker(), portfolio(), "2026-10-12")
    assert result["installation_identity"] == new
    assert result["last_execution_date"] == "2026-10-09"
    assert result["last_minute_decision"] is None


@pytest.mark.parametrize("reason", ["same_day", "open", "workflow", "account"])
def test_direct_etf_change_safety_gates(tmp_path, reason):
    store = StateStore(tmp_path / "state.json")
    state = json.loads(state_bytes(MINUTE_ID))
    if reason == "same_day":
        state["last_execution_date"] = "2026-10-12"
    new = dict(MINUTE_ID, main_symbol="NEW")
    if reason == "account":
        new["account_no"] = "other"
    with pytest.raises(StateIntegrityError):
        store.apply_symbol_change(state, new,
            {"active_workflow": {"id": "unfinished"}} if reason == "workflow" else {"orders": []},
            QueryBroker([{"id": "open"}] if reason == "open" else []), portfolio(), "2026-10-12")


def test_restore_different_etf_open_orders_blocked(tmp_path, monkeypatch):
    with pytest.raises(RuntimeError, match="unresolved"):
        restore(tmp_path, monkeypatch, current={"MAIN_SYMBOL": "NEW"}, answers=["N"],
                broker=QueryBroker([{"id": "open"}]))
    assert read_env(tmp_path / "project/.env")["MAIN_SYMBOL"] == "NEW"


def test_live_restore_rejected(tmp_path, monkeypatch):
    with pytest.raises(RuntimeError, match="DRY_RUN"):
        restore(tmp_path, monkeypatch, current={"EXECUTION_MODE": "LIVE"})


def test_no_history_initial_restore(tmp_path, monkeypatch):
    root, _ = restore(tmp_path, monkeypatch, history=None)
    assert not (root / "data/history/trade_history.csv").exists()


@pytest.mark.parametrize("status", ["UNKNOWN", "PARTIAL_FILLED", "UNRECOGNIZED"])
def test_etf_restore_blocks_backup_unresolved(tmp_path, monkeypatch, status):
    with pytest.raises(RuntimeError, match="unresolved"):
        restore(tmp_path, monkeypatch, current={"MAIN_SYMBOL": "NEW"}, answers=["N"],
                ledger=ledger_bytes(orders=[{"status": status}]))


def test_restore_preserves_newer_execution_guard(tmp_path, monkeypatch):
    root = tmp_path / "project"
    write_env(root, BASE)
    (root / "data").mkdir()
    current_state = json.loads(state_bytes(MINUTE_ID))
    current_state["last_execution_date"] = "2026-10-12"
    before = json.dumps(current_state).encode()
    (root / "data/state.json").write_bytes(before)
    path = bundle(tmp_path, monkeypatch)
    with pytest.raises(RuntimeError, match="checkpoint is newer"):
        recover_backup.recover(path, root=root, values=BASE, context_factory=factory(root), scheduler=Scheduler())
    assert (root / "data/state.json").read_bytes() == before


def test_directory_backup_selection_uses_existing_recover(tmp_path, monkeypatch):
    import sys
    first = tmp_path / "kb-qld-trader-backup-a.tar.gz"
    second = tmp_path / "kb-qld-trader-backup-b.tar.gz"
    first.touch()
    second.touch()
    os.utime(first, (1, 1))
    os.utime(second, (2, 2))
    monkeypatch.setattr(sys, "argv", ["recover_backup.py", str(tmp_path)])
    monkeypatch.setattr("builtins.input", lambda _: "2")
    chosen = []
    def record(path):
        chosen.append(path)
        raise RuntimeError("selected; stop before API")
    monkeypatch.setattr(recover_backup, "recover", record)
    with pytest.raises(RuntimeError, match="selected"):
        recover_backup.main()
    assert chosen == [first]


@pytest.mark.parametrize("value", ["0", "nan", "-2"])
def test_restored_polling_invalid(tmp_path, monkeypatch, value):
    with pytest.raises(ValueError):
        restore(tmp_path, monkeypatch, settings={"MINUTE_POLLING_INTERVAL_SECONDS": value}, answers=["y"])


def test_scheduler_persisted_cron_verification(tmp_path, monkeypatch):
    from scripts import recovery_scheduler, platform_deploy
    monkeypatch.setattr(recovery_scheduler, "selected_platform", lambda _: "termux")
    actual = platform_deploy.cron_block(tmp_path, BASE, False, BASE["BACKUP_TIME"])
    runner = lambda *a, **k: SimpleNamespace(returncode=0, stdout=actual, stderr="")
    platform_deploy.install_termux_boot(tmp_path,tmp_path/'home')
    scheduler = recovery_scheduler.RecoveryScheduler(tmp_path, run=runner,home=tmp_path/'home')
    scheduler.verify(BASE)
    actual = "invalid cron"
    with pytest.raises(RuntimeError, match="cron differs"):
        scheduler.verify(BASE)


def test_etf_restore_rejects_broker_account_mismatch(tmp_path, monkeypatch):
    actual = portfolio()
    actual.account_no = "different"
    with pytest.raises(RuntimeError, match="account mismatch"):
        restore(tmp_path, monkeypatch, current={"MAIN_SYMBOL": "NEW"}, answers=["N"], actual=actual)
