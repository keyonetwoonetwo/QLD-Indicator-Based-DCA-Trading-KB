from datetime import datetime,timedelta
from types import SimpleNamespace
import pytest
from app.api.kb_broker_api import NY
from app.market.market_data import MarketDataService
from app.runners.minute_runner import MinuteRunner
from config.config import AppConfig
from test_kb12_minutes_timers import kb,bar


def session_rows():
    end=datetime(2026,10,12,15,58,tzinfo=NY)
    return [bar(dt=(end-timedelta(minutes=i)).strftime('%Y%m%d'),
                tm=(end-timedelta(minutes=i)).strftime('%H%M%S')) for i in range(1000)]


def test_1000_rows_bad_volume_at_14_keeps_target_and_open(monkeypatch,caplog):
    rows=session_rows(); rows[14].pop('vlm')
    rows[14]['secret']='NEVER_LOG_THIS'
    broker,calls=kb(monkeypatch,rows)
    candles=MarketDataService(broker).fetch_session_minutes('QLD','2026-10-12')
    target=MinuteRunner.select_signal_candle(candles,'2026-10-12','15:58:00')
    assert target.close==100
    assert any(c.timestamp.hour==9 and c.timestamp.minute==30 for c in candles)
    assert not any(c.timestamp.strftime('%H%M%S')==rows[14]['tm'] for c in candles)
    assert len(calls)==1 and calls[0]['rcrd_c']=='1000'
    assert 'row=14 field=vlm missing' in caplog.text
    assert 'NEVER_LOG_THIS' not in caplog.text


@pytest.mark.parametrize('symbol',['QQQ','QLD'])
def test_missing_target_volume_polls_then_stops_without_older_fallback(monkeypatch,symbol):
    rows=session_rows()[:5]; rows[0]['vlm']=' '
    broker,calls=kb(monkeypatch,rows)
    clocks=iter([datetime(2026,10,12,15,59,12,tzinfo=NY),datetime(2026,10,12,15,59,35,tzinfo=NY)])
    sleeps=[]
    runner=MinuteRunner(now_fn=lambda:next(clocks),sleep_fn=lambda n:sleeps.append(n))
    with pytest.raises(ValueError,match='unavailable before'):
        runner._fetch_signal_with_polling(MarketDataService(broker),AppConfig(),
                                          SimpleNamespace(date_str='2026-10-12'),symbol)
    assert len(calls)==2 and sleeps and all(c['rcrd_c']=='5' for c in calls)


def test_missing_opening_volume_fails_open_check(monkeypatch):
    rows=session_rows()
    next(r for r in rows if r['dt']=='20261012' and r['tm']=='093000').pop('vlm')
    broker,_=kb(monkeypatch,rows)
    with pytest.raises(ValueError,match='09:30'):
        MarketDataService(broker).fetch_session_minutes('QLD','2026-10-12')


def test_good_qqq_target_survives_unrelated_missing_volume(monkeypatch):
    rows=session_rows()[:5]; rows[2].pop('vlm')
    broker,_=kb(monkeypatch,rows)
    candles=MarketDataService(broker).fetch_intraday_candles('QQQ',count=5)
    assert len(candles)==4
    assert MinuteRunner.select_signal_candle(candles,'2026-10-12','15:58:00').close==100


@pytest.mark.parametrize('field,value',[
    ('opn_prc_p4',None),('hgh_prc_p4',''),('lw_prc_p4','bad'),('cls_prc_p4','NaN'),
    ('vlm','not-numeric'),('dt','bad'),('tm','156000'),('tm',None)])
def test_individual_field_errors_skip_only_one_row(monkeypatch,caplog,field,value):
    rows=session_rows()[:3]; rows[1][field]=value
    broker,_=kb(monkeypatch,rows)
    candles=broker.get_candles('QLD','1m',5)['candles']
    assert len(candles)==2 and all(c['volume']=='10' for c in candles)
    assert 'row=1 field=' in caplog.text and 'candle excluded' in caplog.text


@pytest.mark.parametrize('raw',[None,{},'invalid',[None]])
def test_response_structure_errors_remain_fatal(monkeypatch,raw):
    broker,_=kb(monkeypatch,[])
    broker.client.request=lambda *a,**k:{'out2':raw}
    with pytest.raises(RuntimeError): broker.get_candles('QLD','1m',5)


def test_http_or_auth_error_remains_fatal(monkeypatch):
    broker,_=kb(monkeypatch,[])
    def failure(*a,**k): raise RuntimeError('HTTP/auth failure')
    broker.client.request=failure
    with pytest.raises(RuntimeError,match='HTTP/auth'): broker.get_candles('QLD','1m',5)


def test_duplicate_timestamp_with_malformed_row_still_blocks(monkeypatch):
    rows=[bar(),bar()]; rows[0].pop('vlm')
    broker,_=kb(monkeypatch,rows)
    with pytest.raises(RuntimeError,match='Duplicate'): broker.get_candles('QLD','1m',5)
