import importlib
import json
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime,timezone,timedelta
import pytest
from config.config import GenericStrategyConfig
from app.api import live_contract
from app.api.client import KBAPIClient
from app.api.kb_broker_api import KBBrokerAPI


@pytest.fixture
def promotion(tmp_path,monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).resolve().parents[1]/'scripts'))
    mod=importlib.import_module('enable_live')
    common=importlib.import_module('release_common')
    values={'EXECUTION_MODE':'DRY_RUN','LIVE_TRADING_ENABLED':'false','KB_BAR_TIME_BASIS':'START_NY',
            'KB_CLIENT_ID':'test-key','KB_CLIENT_SECRET':'test-secret','KB_ACCOUNT_NO':'12345678',
            'SIGNAL_SYMBOL':'QQQ','MAIN_SYMBOL':'QLD','SAFE_SYMBOL':'TBIL',
            'TRADING_SIGNAL_MODE':'MINUTE','SIGNAL_TIME':'15:58:00'}
    for key in values: monkeypatch.delenv(key,raising=False)
    import hashlib
    binding=hashlib.sha256(b'KB:test-key:12345678').hexdigest()
    profile=GenericStrategyConfig('QQQ','QLD','TBIL',signal_time='15:58:00')
    identity=profile.installation_identity('MINUTE','12345678',binding)
    record={'result':'PASS','execution_mode':'DRY_RUN','live_trading_enabled':False,
            'identity_hash':common.identity_hash(identity),'account_no':identity['account_no'],
            'account_binding':binding,'kb_contract_version':live_contract.CONTRACT_VERSION}
    data=tmp_path/'data'; data.mkdir()
    proof=data/'dry_run_validation.json'; proof.write_text(json.dumps(record))
    env=tmp_path/'.env'; env.write_text(''.join(f'{k}={v}\n' for k,v in values.items()))
    for target in (mod,common):
        monkeypatch.setattr(target,'ROOT',tmp_path)
        monkeypatch.setattr(target,'ENV_PATH',env)
    monkeypatch.setattr(mod,'VALIDATION_PATH',proof)
    monkeypatch.setattr(common,'VALIDATION_PATH',proof)
    monkeypatch.setattr(mod,'read_env',lambda:common.read_env(env))
    monkeypatch.setattr(live_contract,'ROOT',tmp_path)
    ledger={'orders':[]}
    state=SimpleNamespace(load_state_strict=lambda:{},assert_installation_identity=lambda *a:None,
                          assert_reconciled=lambda *a:None)
    broker=KBBrokerAPI(None)
    for symbol in ('QLD','TBIL'): broker._quotes[symbol]={'b_askprc_unt_p4':'0.01','s_askprc_unt_p4':'0.01'}
    monkeypatch.setattr(broker,'get_orders',lambda **k:[])
    monkeypatch.setattr(broker,'get_prices',lambda symbols:[{'symbol':s,'lastPrice':'100'} for s in symbols])
    adapter=SimpleNamespace(get_portfolio_state=lambda *a:object())
    config=SimpleNamespace(resolved_strategy=lambda:profile,signal_mode='MINUTE')
    monkeypatch.setattr(mod,'runtime_context',lambda **k:(config,broker,adapter,state,
        SimpleNamespace(load_strict=lambda:ledger),identity))
    answers=iter([mod.SPEC_ACK,mod.LIVE_ACK]); monkeypatch.setattr('builtins.input',lambda _:next(answers))
    return SimpleNamespace(mod=mod,common=common,env=env,proof=proof,record=record,identity=identity,
                           binding=binding,ledger=ledger,broker=broker,root=tmp_path)


def test_two_ack_promotion_and_request_gate_are_consistent(promotion,monkeypatch):
    p=promotion; old=p.env.read_bytes(); p.mod.main()
    assert list(p.root.glob('.env.backup.*'))[0].read_bytes()==old
    assert live_contract.require_live_contract(p.binding)['EXECUTION_MODE']=='LIVE'
    assert p.env.read_text().count('KB_LIVE_CONTRACT_VERSION=')==1
    assert not (p.root/'data/trader.lock').exists()


@pytest.mark.parametrize('bad',['missing','account','hash','no-pass'])
def test_missing_or_mismatched_proof_blocks(promotion,bad):
    p=promotion; original=p.env.read_bytes()
    if bad=='missing': p.proof.unlink()
    else:
        p.record[{'account':'account_binding','hash':'identity_hash','no-pass':'result'}[bad]]='wrong'
        p.proof.write_text(json.dumps(p.record))
    with pytest.raises(RuntimeError): p.mod.main()
    assert p.env.read_bytes()==original and not list(p.root.glob('.env.backup.*'))


@pytest.mark.parametrize('status',['UNKNOWN','PARTIAL_FILLED','PARTIAL_FILLED_BLOCKED','SUBMITTED','PENDING','INTENT'])
def test_any_unresolved_ledger_order_blocks(promotion,status):
    p=promotion; p.ledger['orders']=[{'status':status}]
    with pytest.raises(RuntimeError): p.mod.main()
    assert 'EXECUTION_MODE=DRY_RUN' in p.env.read_text()


def test_active_workflow_still_blocks(promotion,monkeypatch):
    p=promotion; p.ledger['active_workflow']={'id':'test'}
    original=p.env.read_bytes()
    monkeypatch.setattr(p.broker,'get_orders',lambda **k:pytest.fail('broker order scan must not run'))
    with pytest.raises(RuntimeError): p.mod.main()
    assert p.env.read_bytes()==original


def test_promotion_never_scans_or_adopts_manual_broker_orders(promotion,monkeypatch):
    p=promotion; original=json.loads(json.dumps(p.ledger))
    # Even a same-ticker manual order is outside this installation's ledger.
    p.broker.manual_orders=[{'symbol':s,'status':'UNKNOWN'} for s in ('QLD','TBIL','TSLA')]
    monkeypatch.setattr(p.broker,'get_orders',lambda **k:pytest.fail('broker order scan must not run'))
    monkeypatch.setattr(p.broker,'_order_rows',lambda:pytest.fail('broker order history must not run'))
    monkeypatch.setattr(p.broker,'get_order_detail',lambda *a:pytest.fail('manual order must not be adopted'))
    p.mod.main()
    assert p.ledger==original
    assert len(p.broker.manual_orders)==3
    assert 'EXECUTION_MODE=LIVE' in p.env.read_text()  # isolated temporary fixture only


@pytest.mark.parametrize('guard',['assert_installation_identity','assert_reconciled'])
def test_state_identity_and_portfolio_reconciliation_still_block(promotion,monkeypatch,guard):
    p=promotion; original=p.env.read_bytes()
    state=p.mod.runtime_context(require_dry=True)[3]
    def reject(*args): raise RuntimeError('state mismatch')
    monkeypatch.setattr(state,guard,reject)
    with pytest.raises(RuntimeError,match='state mismatch'): p.mod.main()
    assert p.env.read_bytes()==original


@pytest.mark.parametrize('answers',[['WRONG'],['주문 접수가 체결을 의미하지 않음을 이해했습니다','WRONG']])
def test_wrong_ack_does_not_write(promotion,monkeypatch,answers):
    p=promotion; old=p.env.read_bytes(); it=iter(answers)
    monkeypatch.setattr('builtins.input',lambda _:next(it))
    with pytest.raises(SystemExit): p.mod.main()
    assert p.env.read_bytes()==old


@pytest.mark.parametrize('code',['skam2101','skam2201','skam2102','skam2202'])
def test_dry_client_never_authenticates_or_sends_mutations(promotion,code):
    auth=SimpleNamespace(get_access_token=lambda:pytest.fail('auth must not be called'))
    client=KBAPIClient('https://example.invalid',auth,account_binding=promotion.binding,
                       opener=lambda *a,**k:pytest.fail('mutation sent'))
    with pytest.raises(RuntimeError,match='LIVE locked'): client.request('POST','/api/v1/'+code,json_data={})


def test_approved_client_keeps_wire_contract_deadline_and_no_retry(promotion,monkeypatch):
    p=promotion; p.mod.main(); now=datetime.now(timezone.utc)
    auth=SimpleNamespace(client_id='test-key',client_secret='test-secret',ip_addr='192.0.2.1',mac_addr='test-mac',get_access_token=lambda:'test-token')
    sent=[]
    def opener(req,**k):
        sent.append(json.loads(req.data)); raise TimeoutError('uncertain response')
    client=KBAPIClient('https://example.invalid',auth,account_binding=p.binding,opener=opener,now_fn=lambda:now)
    client.order_deadline=now+timedelta(seconds=20)
    code,body=p.broker.build_order_request('QLD','BUY','LIMIT',price='100',order_amount='20')
    with pytest.raises(RuntimeError,match='not replayed'): client.request('POST','/api/v1/'+code.lower(),json_data=body)
    assert len(sent)==1 and sent[0]['dataBody']==body
    client.order_deadline=now
    with pytest.raises(RuntimeError): client.request('POST','/api/v1/'+code.lower(),json_data=body)
    assert len(sent)==1
    body['frgn_ordr_q']='1'
    with pytest.raises(RuntimeError,match='fields'): client.request('POST','/api/v1/'+code.lower(),json_data=body)
    assert len(sent)==1


@pytest.mark.parametrize('code',['spao2104','spao2106','ssam1802','unknown'])
def test_other_mutation_routes_never_bypass_dry_gate(promotion,code):
    client=KBAPIClient('https://example.invalid',SimpleNamespace(),opener=lambda *a,**k:pytest.fail('HTTP'))
    with pytest.raises(RuntimeError,match='not approved'):
        client.request('POST','/api/v1/'+code,json_data={})


def test_validation_record_preserves_pass_fields_without_execution_claim(promotion):
    p=promotion; p.common.write_validation_record(p.identity,{})
    record=json.loads(p.proof.read_text())
    assert record['result']=='PASS' and record['execution_mode']=='DRY_RUN'
    assert record['live_trading_enabled'] is False
    assert record['kb_contract_version']==live_contract.CONTRACT_VERSION
    assert 'live_execution_verified' not in record


@pytest.mark.parametrize('field,value',[('KB_ACCOUNT_NO','87654321'),('MAIN_SYMBOL','WRONG'),('EXECUTION_MODE','DRY_RUN')])
def test_approval_cannot_survive_account_role_or_mode_change(promotion,field,value):
    p=promotion; p.mod.main()
    values=p.common.read_env(p.env); values[field]=value
    p.env.write_text(''.join(f'{k}={v}\n' for k,v in values.items()))
    with pytest.raises(RuntimeError): live_contract.require_live_contract(p.binding)


def test_cancel_wire_shapes_and_no_main_sell(promotion):
    live_contract.validate_mutation('skam2202',{'orgn_ordr_no':'0000000001'},'QLD','TBIL')
    live_contract.validate_mutation('skam2102',{'crct_cncl_clsf':'2','is_cd':'TBIL','orgn_ordr_no':'0000000002','frgn_ordr_prc_p4':'99.90'},'QLD','TBIL')
    code,body=promotion.broker.build_order_request('QLD','BUY','LIMIT',price='100',order_amount='20')
    body['trd_dl_ccd']='01'
    with pytest.raises(RuntimeError,match='MAIN'): live_contract.validate_mutation(code.lower(),body,'QLD','TBIL')
