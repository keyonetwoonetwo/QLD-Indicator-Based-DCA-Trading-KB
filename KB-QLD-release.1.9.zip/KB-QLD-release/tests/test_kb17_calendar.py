from datetime import datetime,timedelta
import sys
import pytest
import holidays
from app.api.session_calendar import market_calendar,session_timing,_nyse_days,NY


@pytest.mark.parametrize('day,previous,following',[
    ('2021-12-31','2021-12-30','2022-01-03'),
    ('2022-01-01','2021-12-31','2022-01-03'),
    ('2025-01-09','2025-01-08','2025-01-10'),
    ('2026-11-26','2026-11-25','2026-11-27'),
])
def test_boundaries_and_holidays(day,previous,following):
    result=market_calendar(day)
    assert result['previousBusinessDay']['date']==previous
    assert result['nextBusinessDay']['date']==following


@pytest.mark.parametrize('day,hour,offset',[
    ('2026-11-27',13,-5),('2026-12-24',13,-5),('2026-07-02',16,-4),
    ('2026-03-06',16,-5),('2026-03-09',16,-4),
    ('2026-10-30',16,-4),('2026-11-02',16,-5),
])
def test_sessions_dst_and_timing(day,hour,offset):
    regular=market_calendar(day)['today']['regularMarket']
    assert datetime.fromisoformat(regular['startTime']).strftime('%H:%M')=='09:30'
    close=datetime.fromisoformat(regular['endTime'])
    assert close.hour==hour and close.utcoffset()==timedelta(hours=offset)
    timing=session_timing(close)
    assert timing['signal'].strftime('%H:%M')==f'{hour-1}:58'
    assert timing['admission'].strftime('%H:%M:%S')==f'{hour-1}:59:35'


@pytest.mark.parametrize('day',['2026-07-03','2026-11-26','2026-12-25','2026-10-17','2025-01-09'])
def test_public_and_weekend_closed(day):
    assert market_calendar(day)['today']['regularMarket'] is None


def test_half_day_support_failure_has_no_federal_fallback(monkeypatch):
    _nyse_days.cache_clear()
    monkeypatch.setattr(holidays,'financial_holidays',lambda *a,**k:type('Unsupported',(),{'supported_categories':('public',)})())
    monkeypatch.setattr(holidays,'US',lambda *a,**k:pytest.fail('US fallback forbidden'))
    try:
        with pytest.raises(RuntimeError,match='HALF_DAY unsupported'):
            market_calendar('2026-11-27')
    finally: _nyse_days.cache_clear()


def test_calendar_creation_failure_is_fatal(monkeypatch):
    _nyse_days.cache_clear()
    def fail(*a,**k): raise ValueError('unavailable')
    monkeypatch.setattr(holidays,'financial_holidays',fail)
    try:
        with pytest.raises(RuntimeError,match='no fallback'): market_calendar('2026-10-16')
    finally: _nyse_days.cache_clear()
