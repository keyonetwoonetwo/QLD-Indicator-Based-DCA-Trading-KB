from decimal import Decimal
from types import SimpleNamespace
import pytest
from app.api.kb_broker_api import KBBrokerAPI


def test_inconsistent_empty_holdings_is_not_a_zero_balance():
    client = SimpleNamespace(request=lambda *a, **k: {"Record2": [], "grid_cnt2": "0001", "nxt_key": ""})
    with pytest.raises(RuntimeError, match="count"):
        KBBrokerAPI(client).get_holdings()


def test_buy_tick_rounding_preserves_slippage_and_sell_rounds_down():
    broker = KBBrokerAPI(None)
    broker._quotes["QLD"] = {"b_askprc_unt_p4": "0.01", "s_askprc_unt_p4": "0.01"}
    assert broker.normalize_limit_price("QLD", Decimal("100.2300299"), "BUY") == Decimal("100.24")
    assert broker.normalize_limit_price("QLD", Decimal("100.0297701"), "SELL") == Decimal("100.02")


def test_execution_quote_without_timestamp_is_rejected():
    broker = KBBrokerAPI(None)
    broker._quotes["QLD"] = {"now_prc_p4": "100"}
    with pytest.raises(RuntimeError, match="timestamp"):
        broker.assert_quote_fresh("QLD")
