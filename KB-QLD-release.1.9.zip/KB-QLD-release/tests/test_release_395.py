from version import RELEASE_VERSION
from app.models.order_identity import make_client_order_id


def test_release_and_v395_id_uniqueness():
    assert RELEASE_VERSION == "1.9"
    workflow = "g-20261009-conditional-accumulation"
    assert make_client_order_id(workflow, "SAFE_CASH_SELL_1") != make_client_order_id(workflow, "MAIN_AMOUNT_BUY_2")
