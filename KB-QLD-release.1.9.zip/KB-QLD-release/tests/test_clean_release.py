"""Guard the cleaned registry and preserve order-free CLOSE post-validation."""
import importlib.util
import json
from dataclasses import fields
from datetime import datetime, timezone
from decimal import Decimal
from types import SimpleNamespace
import pytest

from app.models.market import Candle
from app.models.orders import StrategyDecision
from app.models.orders import OrderItem
from app.models.common import ExecutionMode, OrderSide, OrderType
from app.execution.order_manager import OrderManager
from app.runners import RUNNERS, MinuteRunner
from config.config import AMOUNT_KEYS, GenericStrategyConfig, TradingConfig
from scripts import validate_close_signal


def test_only_minute_runner_and_removed_modules_are_absent():
    assert RUNNERS == {"MINUTE": MinuteRunner}
    assert importlib.util.find_spec("app.runners.close_runner") is None
    assert importlib.util.find_spec("app.strategy.strategy") is None


def test_unused_overheat_notification_field_removed():
    assert "overheat_price" not in {field.name for field in fields(StrategyDecision)}


def test_close_post_validation_is_order_free(tmp_path, monkeypatch):
    key = "RISK_ON_GREEN_FG_HIGH_USD"
    amounts = {name: Decimal("0") for name in AMOUNT_KEYS}
    amounts[key] = Decimal("25.50")
    profile = GenericStrategyConfig("SIGNAL", "MAIN", "SAFE")
    config = SimpleNamespace(
        resolved_strategy=lambda: profile, strategy_rules=SimpleNamespace(ma_period=2),
        trading=TradingConfig(buy_amounts=amounts),
    )
    minute = {"market_date": "2026-10-09", "fear_greed_score": "50",
              "condition_key": key, "configured_amount": "25.50"}
    state = SimpleNamespace(load_state_strict=lambda: {"last_minute_decision": minute},
                            assert_installation_identity=lambda *a: None)
    class NoMutations:
        def create_order(self, **kwargs):
            raise AssertionError("no real orders")
        def cancel_order(self, **kwargs):
            raise AssertionError("no cancels")
    broker = NoMutations()
    calls = []
    class Market:
        def __init__(self, value):
            assert value is broker
        def fetch_daily_candles(self, symbol, count):
            calls.append((symbol, count))
            prices = [Decimal("99"), Decimal("100"), Decimal("101")] if symbol == "SIGNAL" else [Decimal("10")]
            return [Candle(datetime(2026, 10, 9, 20, tzinfo=timezone.utc), p, p, p, p, Decimal("100")) for p in prices]
        def assert_latest_daily_candle_confirmed(self, candles, market_date):
            assert market_date == "2026-10-09"
    monkeypatch.setattr(validate_close_signal, "ROOT", tmp_path)
    monkeypatch.setattr(validate_close_signal, "MarketDataService", Market)
    monkeypatch.setattr(validate_close_signal, "runtime_context", lambda: (config, broker, None, state, None, {}))
    validate_close_signal.main()
    result = json.loads((tmp_path / "data/history/close_validation_2026-10-09.json").read_text())
    assert result["trading_enabled"] is False and result["matches_minute"] is True
    assert result["condition_key"] == key and result["amount_usd"] == "25.50"
    assert result["main_direction"] == "GREEN"
    assert calls == [("SIGNAL", 3), ("MAIN", 2)]


@pytest.mark.parametrize("symbol,side,amount", [
    ("QLD", OrderSide.BUY, Decimal("12.34")),
    ("SAFE", OrderSide.BUY, None),
    ("SAFE", OrderSide.SELL, None),
])
def test_public_dry_submission_never_calls_order_api(symbol, side, amount):
    class NoBrokerCalls:
        def __getattr__(self, name):
            raise AssertionError(f"DRY_RUN must not invoke broker {name}")
    updates = []
    ledger = SimpleNamespace(update_order=lambda client_id, **fields: updates.append(fields))
    item = OrderItem(symbol, side, Decimal("1") if amount is None else Decimal("0"),
                     order_type=OrderType.MARKET, price=Decimal("100"),
                     client_order_id="clean-dry-intent", order_amount=amount)
    record = OrderManager(NoBrokerCalls(), ExecutionMode.DRY_RUN).submit_ledger_order(item, "generic", ledger)
    assert record.order_id.startswith("SIM-") and updates[0]["status"] == "FILLED"
    assert record.filled_quantity == (Decimal("1") if amount is None else Decimal("0.1234"))
