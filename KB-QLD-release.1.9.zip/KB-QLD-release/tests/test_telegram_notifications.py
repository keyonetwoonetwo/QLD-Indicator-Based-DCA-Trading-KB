from decimal import Decimal

from app.models.common import OrderSide, OrderStatus
from app.models.market import IndicatorResult
from app.models.orders import ExecutionRecord
from app.models.portfolio import PortfolioState
from app.notification.telegram import TelegramNotifier
from app.strategy.generic_strategy import GenericStrategy
from config.config import AMOUNT_KEYS, GenericStrategyConfig, TradingConfig


def notifier_messages():
    messages = []
    notifier = TelegramNotifier("", "", enabled=False)
    notifier.send_message = lambda message: messages.append(message) or True
    return notifier, messages


def decision_fixture(symbol="QQQ"):
    amounts = {key: Decimal("0") for key in AMOUNT_KEYS}
    amounts["RISK_ON_GREEN_FG_MID_USD"] = Decimal("20")
    indicator = IndicatorResult(symbol, Decimal("101"), Decimal("100"), Decimal("99"), Decimal("100"), False, False, Decimal("0"))
    portfolio = PortfolioState(main_quantity=Decimal("2"), main_avg_price=Decimal("80"), safe_quantity=Decimal("3"), available_cash_usd=Decimal("50"), prices={"QLD": Decimal("100")})
    strategy = GenericStrategy(GenericStrategyConfig(symbol, "QLD", "SGOV"), trading_config=TradingConfig(buy_amounts=amounts))
    decision, plan = strategy.evaluate_decision(indicator, portfolio, {}, Decimal("100"), Decimal("99"), Decimal("20"))
    return decision, plan, portfolio


def test_decision_message_keeps_existing_format_and_adds_conditional_inputs():
    decision, plan, portfolio = decision_fixture()
    notifier, messages = notifier_messages()
    notifier.notify_decision(decision, plan, portfolio, main_symbol="QLD", safe_symbol="SGOV")
    message = messages[0]
    assert message.startswith("📊 <b>[전략 판단:")
    assert "SIGNAL 판단: RISK_ON" in message
    assert "MAIN 당일: GREEN" in message
    assert "CNN Fear & Greed: 20 (FG_MID)" in message
    assert "RISK_ON_GREEN_FG_MID_USD" in message
    assert "조건별 매수금액: $20.00" in message
    assert "Overheat" not in message and "ENTRY_SPLIT" not in message


def test_main_return_and_html_escaping_are_preserved():
    decision, plan, portfolio = decision_fixture("SIG<&")
    notifier, messages = notifier_messages()
    notifier.notify_decision(decision, plan, portfolio, main_symbol="QLD", safe_symbol="SGOV")
    assert "SIG&lt;&amp;" in messages[0]
    assert "수익률: 25.0%" in messages[0]


def test_partial_and_unknown_execution_still_block():
    notifier, messages = notifier_messages()
    record = ExecutionRecord("UNKNOWN", "QLD", OrderSide.BUY, Decimal("0"), OrderStatus.PENDING, filled_quantity=Decimal("0"), requested_amount=Decimal("20"))
    notifier.notify_execution([record])
    assert messages[0].startswith("⚠️")
    assert "UNKNOWN" in messages[0]
    assert "자동 진행 중단" in messages[0]
