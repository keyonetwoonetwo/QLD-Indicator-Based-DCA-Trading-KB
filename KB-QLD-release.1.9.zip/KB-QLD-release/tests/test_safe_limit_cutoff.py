"""KB order shapes and final-minute policy regression."""
from datetime import datetime, timezone
from decimal import Decimal
from types import SimpleNamespace
from zoneinfo import ZoneInfo

import pytest

from app.api.kb_broker_api import KBBrokerAPI
from app.api.session_calendar import session_timing
from app.execution.minute_execution import MinuteExecution

NY = ZoneInfo("America/New_York")


class Client:
    def __init__(self):
        self.auth_manager = SimpleNamespace(client_id="local-test-key")
        self.binding = None
        self.calls = []

    def set_account_binding(self, value):
        self.binding = value

    def request(self, method, path, **kwargs):
        self.calls.append((method, path, kwargs))
        if path.endswith("spqm2226"):
            return {"Record2": [], "nxt_key": ""}
        raise AssertionError("No order should be sent by request-shape tests")


def broker(monkeypatch):
    monkeypatch.setenv("KB_EXCHANGE_QLD", "AMS")
    monkeypatch.setenv("KB_EXCHANGE_TBIL", "NAS")
    result = KBBrokerAPI(Client())
    for symbol in ("QLD", "TBIL"):
        result._quotes[symbol] = {"b_askprc_unt_p4": "0.01", "s_askprc_unt_p4": "0.01"}
    return result


def test_main_amount_limit_keeps_usd_amount_and_price(monkeypatch):
    kb = broker(monkeypatch)
    price = kb.normalize_limit_price("QLD", Decimal("100") * Decimal("1.001"), "BUY")
    code, payload = kb.build_order_request("QLD", "BUY", "LIMIT", price=price, order_amount="20")
    assert code == "SKAM2201"
    assert payload["ordr_amt"] == "20"
    assert payload["amt_q_clsf"] == "0"
    assert payload["frgn_ordr_prc_p4"] == "100.10"
    assert "frgn_ordr_q" not in payload


def test_safe_integer_limit_and_invalid_fraction(monkeypatch):
    kb = broker(monkeypatch)
    code, payload = kb.build_order_request("TBIL", "SELL", "LIMIT", quantity=2, price="99.90")
    assert code == "SKAM2101"
    assert payload["frgn_ordr_q"] == "2"
    assert payload["trd_dl_ccd"] == "01"
    with pytest.raises(ValueError, match="whole shares"):
        kb.build_order_request("TBIL", "SELL", "LIMIT", quantity="2.5", price="99.90")


@pytest.mark.parametrize("close,signal,execution,deadline", [
    ("16:00:00", "15:58:00", "15:59:10", "15:59:35"),
    ("13:00:00", "12:58:00", "12:59:10", "12:59:35"),
])
def test_session_cutoffs_and_persisted_policy(close, signal, execution, deadline):
    end = datetime.fromisoformat("2026-11-27T" + close).replace(tzinfo=NY)
    timing = session_timing(end)
    assert timing["signal"].strftime("%H:%M:%S") == signal
    assert timing["execution"].strftime("%H:%M:%S") == execution
    assert timing["admission"].strftime("%H:%M:%S") == deadline
    policy = {"kind": "MINUTE_V1", "signal_time": signal,
              "admission_deadline": timing["admission"].isoformat(),
              "new_leg_deadline": timing["admission"].isoformat()}
    just_before = (timing["admission"] - __import__("datetime").timedelta(seconds=1)).astimezone(timezone.utc)
    MinuteExecution.validate_admission(policy, just_before)
    with pytest.raises(ValueError, match="cutoff"):
        MinuteExecution.validate_admission(policy, timing["admission"].astimezone(timezone.utc))
