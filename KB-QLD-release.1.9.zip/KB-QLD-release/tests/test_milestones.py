from decimal import Decimal

import pytest

from config.config import AMOUNT_KEYS, AppConfig, TradingConfig


def required_env(monkeypatch):
    values = {
        "SIGNAL_SYMBOL": "QQQ", "MAIN_SYMBOL": "QLD", "SAFE_SYMBOL": "SGOV",
        "RISK_THRESHOLD": "1", "SIGNAL_TIME": "15:57:00", "TRADING_SIGNAL_MODE": "MINUTE",
    }
    for key, value in values.items():
        monkeypatch.setenv(key, value)
    for key in AMOUNT_KEYS:
        monkeypatch.setenv(key, "0")


def test_all_twelve_amount_defaults_match_kb_release():
    assert len(AMOUNT_KEYS) == 12
    assert TradingConfig().buy_amounts == {
        f"{regime}_{direction}_FG_{band}_USD": Decimal(amount)
        for regime, directions in {
            "RISK_ON": {"GREEN": (10, 5, 0), "RED": (20, 15, 10)},
            "RISK_OFF": {"GREEN": (20, 15, 10), "RED": (40, 30, 20)},
        }.items()
        for direction, amounts in directions.items()
        for band, amount in zip(("LOW", "MID", "HIGH"), amounts)
    }


def test_app_config_loads_independent_amounts_and_cash_target(monkeypatch):
    required_env(monkeypatch)
    monkeypatch.setenv("RISK_OFF_RED_FG_HIGH_USD", "25.50")
    monkeypatch.setenv("CASH_TARGET_MULTIPLIER", "5")
    config = AppConfig.load()
    assert config.trading.buy_amounts["RISK_OFF_RED_FG_HIGH_USD"] == Decimal("25.50")
    assert config.target_cash == Decimal("127.50")


@pytest.mark.parametrize("value", ["-1", "NaN", "Infinity"])
def test_invalid_buy_amount_fails_closed(monkeypatch, value):
    required_env(monkeypatch)
    monkeypatch.setenv(AMOUNT_KEYS[0], value)
    with pytest.raises(ValueError, match="twelve buy amounts"):
        AppConfig.load()


def test_fear_greed_threshold_order_fails_closed(monkeypatch):
    required_env(monkeypatch)
    monkeypatch.setenv("FEAR_GREED_LOW_THRESHOLD", "45")
    monkeypatch.setenv("FEAR_GREED_HIGH_THRESHOLD", "10")
    with pytest.raises(ValueError, match="below"):
        AppConfig.load()

