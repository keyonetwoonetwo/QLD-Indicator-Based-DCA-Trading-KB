import pytest
from scripts import configure, release_common
from test_backup_recovery import archive, context, Scheduler, VALUES
from scripts.recover_backup import recover


def test_fresh_configure_writes_required_basis(tmp_path,monkeypatch):
    monkeypatch.setattr(configure,'ROOT',tmp_path)
    monkeypatch.setattr(configure,'ENV_PATH',tmp_path/'.env')
    monkeypatch.setattr(release_common,'ROOT',tmp_path)
    monkeypatch.setattr(release_common,'ENV_PATH',tmp_path/'.env')
    monkeypatch.setattr(configure,'ask_yes_no',lambda _: True)
    monkeypatch.setattr(configure,'ask_yes_no_default_yes',lambda _: False)
    monkeypatch.setattr(configure,'getpass',lambda _: 'test-secret')
    def answer(prompt):
        if prompt.startswith('KB_CLIENT_ID'): return 'test-key'
        if prompt.startswith('KB_ACCOUNT_NO'): return '12345678'
        if 'IPv4' in prompt: return '192.0.2.1'
        if 'MAC' in prompt: return '00:00:00:00:00:01'
        if '거래소 코드' in prompt: return 'NAS'
        return ''
    monkeypatch.setattr('builtins.input',answer)
    configure.main()
    values=release_common.read_env(tmp_path/'.env')
    assert values['KB_BAR_TIME_BASIS']=='START_NY'
    assert values['EXECUTION_MODE']=='DRY_RUN' and values['LIVE_TRADING_ENABLED']=='false'


@pytest.mark.parametrize('basis',[None,'','END_NY','WRONG'])
def test_validation_rejects_before_api(basis,monkeypatch):
    monkeypatch.delenv('KB_BAR_TIME_BASIS',raising=False)
    values={} if basis is None else {'KB_BAR_TIME_BASIS':basis}
    monkeypatch.setattr(release_common,'read_env',lambda: values)
    from config.config import AppConfig
    monkeypatch.setattr(AppConfig,'load',lambda: pytest.fail('must fail before API/config'))
    with pytest.raises(RuntimeError,match='KB_BAR_TIME_BASIS'):
        release_common.runtime_context(require_dry=True)


def test_invalid_process_override_is_rejected(monkeypatch):
    monkeypatch.setenv('KB_BAR_TIME_BASIS','END_NY')
    with pytest.raises(RuntimeError,match='process override'):
        release_common.validate_bar_time_basis({'KB_BAR_TIME_BASIS':'START_NY'})


@pytest.mark.parametrize('failure',[False,True])
def test_recovery_adds_only_missing_key_and_rolls_back_on_failure(tmp_path,monkeypatch,failure):
    monkeypatch.delenv('KB_BAR_TIME_BASIS',raising=False)
    root=tmp_path/'app'; factory=context(root)
    values={k:v for k,v in VALUES.items() if k!='KB_BAR_TIME_BASIS'}
    original='# preserve\n'+''.join(f'{k}={v}\n' for k,v in values.items())+'KB_CLIENT_SECRET=test-secret\n'
    (root/'.env').write_text(original,encoding='utf-8')
    scheduler=Scheduler(fail=failure)
    if failure:
        with pytest.raises(RuntimeError,match='scheduler failed'):
            recover(archive(tmp_path),factory,scheduler,root,dict(values))
        assert (root/'.env').read_text()==original
    else:
        recover(archive(tmp_path),factory,scheduler,root,dict(values))
        assert (root/'.env').read_text()==original+'KB_BAR_TIME_BASIS=START_NY\n'


def test_recovery_invalid_basis_keeps_files_and_scheduler(tmp_path,monkeypatch):
    monkeypatch.delenv('KB_BAR_TIME_BASIS',raising=False)
    root=tmp_path/'app'; factory=context(root)
    original=(root/'.env').read_bytes(); scheduler=Scheduler()
    with pytest.raises(RuntimeError,match='KB_BAR_TIME_BASIS'):
        recover(archive(tmp_path),factory,scheduler,root,dict(VALUES,KB_BAR_TIME_BASIS='END_NY'))
    assert (root/'.env').read_bytes()==original
    assert not scheduler.quiesced and not scheduler.installed
