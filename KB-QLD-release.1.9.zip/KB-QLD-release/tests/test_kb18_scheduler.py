from pathlib import Path
from types import SimpleNamespace
import subprocess,sys,os
import pytest
from scripts import recovery_scheduler as rs,platform_deploy as pd
from test_backup_settings_etf import BASE,bundle,factory
from scripts.recover_backup import recover

VALUES=dict(BASE,TELEGRAM_ENABLED='true',TELEGRAM_BOT_TOKEN='fake-token',TELEGRAM_ALERT_CHAT_ID='fake-chat')
OTHER='# BEGIN TOSS-TRADER\r\nCRON_TZ=America/New_York\r\n0 10 * * * /other/toss.sh  \r\n# END TOSS-TRADER\r\n\r\n# personal  \r\n1 2 * * * /other/personal\r\n\r\n'


class Termux:
    def __init__(self,cron=OTHER):
        self.cron=cron; self.daemon=True; self.calls=[]; self.fail_write=False; self.fail_daemon=False
    def __call__(self,args,**kw):
        self.calls.append((args,kw))
        assert 'systemctl' not in args and 'sudo' not in args
        code=0; out=b''
        if args==['crontab','-l']: out=self.cron.encode()
        elif args==['crontab','-']:
            assert isinstance(kw['input'],bytes)
            self.cron=kw['input'].decode()
            if self.fail_write:
                self.fail_write=False; raise subprocess.CalledProcessError(1,args)
        elif args==['pgrep','-x','crond']: code=0 if self.daemon else 1
        elif args[0]=='sh': self.daemon=not self.fail_daemon
        else: raise AssertionError(args)
        if kw.get('check') and code: raise subprocess.CalledProcessError(code,args)
        return SimpleNamespace(returncode=code,stdout=out,stderr=b'')


def termux(tmp_path,monkeypatch,cron=OTHER,boot=False):
    monkeypatch.setattr(rs,'selected_platform',lambda _: 'termux')
    monkeypatch.setattr(rs,'validate_termux_runtime',lambda:None)
    runner=Termux(cron)
    scheduler=rs.RecoveryScheduler(tmp_path,run=runner,home=tmp_path/'home')
    if boot: pd.install_termux_boot(tmp_path,tmp_path/'home')
    return scheduler,runner


def apply(scheduler,values=VALUES):
    if scheduler.needs_repair(values):
        try:
            scheduler.quiesce(); scheduler.install(values); scheduler.verify(values)
        except Exception:
            scheduler.rollback(); raise


@pytest.mark.parametrize('missing',['all','trade','backup','boot','path'])
def test_same_times_termux_repairs_missing_parts_preserves_other_cron(tmp_path,monkeypatch,missing):
    good=pd.cron_block(tmp_path,VALUES,True,VALUES['BACKUP_TIME'])
    cron=OTHER+good
    if missing=='all': cron=OTHER
    elif missing=='trade': cron=OTHER+'\n'.join(line for line in good.split('\n') if 'run_cron.py' not in line)
    elif missing=='backup': cron=OTHER+'\n'.join(line for line in good.split('\n') if '/backup.sh' not in line)
    elif missing=='path': cron=cron.replace(tmp_path.as_posix(),'/old/wsl/path')
    scheduler,runner=termux(tmp_path,monkeypatch,cron,boot=missing!='boot')
    apply(scheduler)
    assert not scheduler.needs_repair(VALUES)
    assert pd.replace_marker_block(runner.cron,'').encode()==OTHER.encode()
    assert runner.cron.count(pd.BEGIN)==1
    assert pd.cron_block(tmp_path,VALUES,True,VALUES['BACKUP_TIME']) in runner.cron


def test_healthy_termux_is_not_reinstalled(tmp_path,monkeypatch):
    cron=OTHER+pd.cron_block(tmp_path,VALUES,True,VALUES['BACKUP_TIME'])
    scheduler,runner=termux(tmp_path,monkeypatch,cron,boot=True)
    apply(scheduler)
    assert runner.cron==cron
    assert not any(args==['crontab','-'] or args[0]=='sh' for args,kw in runner.calls)


def test_marker_replacement_preserves_surrounding_bytes_and_deduplicates():
    block=pd.cron_block(Path('/kb'),VALUES,True,VALUES['BACKUP_TIME'])
    text=OTHER+block+'\r\n# between  \r\n'+block+'# after  \r\n'
    result=pd.replace_marker_block(text,block)
    assert result==OTHER+block+'\r\n# between  \r\n# after  \r\n'
    assert pd.replace_marker_block(result,block)==result


def test_cron_failure_rolls_back_exactly(tmp_path,monkeypatch):
    scheduler,runner=termux(tmp_path,monkeypatch,OTHER)
    runner.fail_write=True
    with pytest.raises(subprocess.CalledProcessError): apply(scheduler)
    assert runner.cron.encode()==OTHER.encode()
    assert not (tmp_path/'home/.termux/boot/start-kb-qld-trader').exists()


def test_crond_failure_is_not_success_and_rolls_back_boot_and_cron(tmp_path,monkeypatch):
    scheduler,runner=termux(tmp_path,monkeypatch,OTHER)
    runner.daemon=False; runner.fail_daemon=True
    with pytest.raises(RuntimeError,match='crond is not running'): apply(scheduler)
    assert runner.cron==OTHER
    assert not (tmp_path/'home/.termux/boot/start-kb-qld-trader').exists()


def test_rollback_preserves_concurrent_other_cron_changes(tmp_path,monkeypatch):
    scheduler,runner=termux(tmp_path,monkeypatch,OTHER)
    assert scheduler.needs_repair(VALUES)
    scheduler.quiesce(); scheduler.install(VALUES)
    runner.cron+='# concurrently added\n'
    scheduler.rollback()
    assert runner.cron==OTHER+'# concurrently added\n'


class Linux:
    def __init__(self): self.states={}; self.calls=[]; self.installed=[]
    def __call__(self,args,**kw):
        self.calls.append(args); code=0; out=''
        command=args[1:] if args[0]=='sudo' else args
        if command[0]=='systemctl':
            action=command[1]; name=command[-1]
            if action in ('is-enabled','is-active'):
                code=0 if self.states.get(name,(False,False))[action=='is-active'] else 1
            elif action=='show':
                out='DropInPaths=\nNeedDaemonReload=no\n' if 'DropInPaths' in args else 'AccuracyUSec=1s\nRandomizedDelayUSec=0\n'
            elif action in ('enable','disable','start','stop'):
                enabled,active=self.states.get(name,(False,False))
                if action in ('enable','disable'): enabled=action=='enable'
                if action in ('start','stop'): active=action=='start'
                if '--now' in command: active=enabled
                self.states[name]=(enabled,active)
            elif action!='daemon-reload': raise AssertionError(args)
        elif command[0]=='install': Path(command[-1]).write_bytes(Path(command[-2]).read_bytes())
        elif command[0]=='rm': Path(command[-1]).unlink(missing_ok=True)
        else: raise AssertionError(args)
        return SimpleNamespace(returncode=code,stdout=out,stderr='')


def linux(tmp_path,monkeypatch,healthy=True):
    monkeypatch.setattr(rs,'selected_platform',lambda _: 'linux')
    runner=Linux(); units=tmp_path/'units'; units.mkdir()
    scheduler=rs.RecoveryScheduler(tmp_path,run=runner,unit_root=units)
    def install(service,timer,service_text,timer_text):
        runner.installed.append(timer)
        (units/service).write_text(service_text); (units/timer).write_text(timer_text)
        runner.states[timer]=(True,True)
    monkeypatch.setattr(rs,'enable_timer',install)
    if healthy:
        for spec in scheduler._spec(VALUES).values():
            install(*spec)
        runner.installed.clear()
    return scheduler,runner,units


def test_healthy_wsl_preserves_states_and_all_files(tmp_path,monkeypatch):
    scheduler,runner,units=linux(tmp_path,monkeypatch)
    runner.states['kb-qld-trader.timer']=(False,False)
    before={p.name:p.read_bytes() for p in units.iterdir()}
    apply(scheduler)
    assert not runner.installed and not any('sudo' in c for c in runner.calls)
    assert before=={p.name:p.read_bytes() for p in units.iterdir()}


@pytest.mark.parametrize('role,problem',[('trade','missing'),('trade','different'),('backup','missing'),('backup','different')])
def test_linux_repairs_only_affected_role(tmp_path,monkeypatch,role,problem):
    scheduler,runner,units=linux(tmp_path,monkeypatch)
    timer=scheduler._spec(VALUES)[role][1]
    if problem=='missing': (units/timer).unlink()
    else: (units/timer).write_text('wrong OnCalendar')
    apply(scheduler)
    assert runner.installed==[timer]
    assert 'AccuracySec=1s' in (units/timer).read_text()
    assert 'RandomizedDelaySec=0' in (units/timer).read_text()


def test_termux_to_wsl_generates_both_timers(tmp_path,monkeypatch):
    scheduler,runner,units=linux(tmp_path,monkeypatch,healthy=False)
    apply(scheduler)
    assert set(runner.installed)=={'kb-qld-trader.timer','kb-qld-trader-backup.timer'}


def test_linux_failure_restores_prior_files_and_states(tmp_path,monkeypatch):
    scheduler,runner,units=linux(tmp_path,monkeypatch)
    for timer in ('kb-qld-trader.timer','kb-qld-trader-backup.timer'): (units/timer).write_text('old')
    before={p.name:p.read_bytes() for p in units.iterdir()}; states=dict(runner.states)
    original=rs.enable_timer
    def fail(*args): original(*args); raise RuntimeError('install failed')
    monkeypatch.setattr(rs,'enable_timer',fail)
    with pytest.raises(RuntimeError,match='install failed'): apply(scheduler)
    assert before=={p.name:p.read_bytes() for p in units.iterdir()}
    assert runner.states==states


def test_actual_platform_overrides_stale_backup_metadata(tmp_path,monkeypatch):
    (tmp_path/'.install-platform').write_text('linux')
    monkeypatch.setenv('PREFIX','/data/data/com.termux/files/usr')
    monkeypatch.setattr(pd,'validate_termux_runtime',lambda:None)
    assert pd.selected_platform(tmp_path)=='termux'


def test_unknown_environment_never_guesses(tmp_path,monkeypatch):
    monkeypatch.delenv('PREFIX',raising=False); monkeypatch.delenv('INSTALL_PLATFORM',raising=False)
    monkeypatch.setattr(pd.sys,'platform','unsupported')
    (tmp_path/'.install-platform').write_text('linux')
    with pytest.raises(RuntimeError,match='Unsupported execution environment'): pd.selected_platform(tmp_path)


def test_restore_same_settings_still_invokes_actual_scheduler_probe(tmp_path,monkeypatch):
    values=dict(BASE)
    root=tmp_path/'restore'; root.mkdir()
    from test_backup_recovery import write_env
    write_env(root,values)
    scheduler,runner=termux(root,monkeypatch,OTHER)
    before=(root/'.env').read_bytes()
    recover(bundle(tmp_path,monkeypatch),root=root,values=values,context_factory=factory(root),scheduler=scheduler)
    assert scheduler.needs_repair(values) is False
    assert (root/'.env').read_bytes()==before
    assert runner.cron.startswith(OTHER)


def test_direct_entrypoint_resolves_project_imports_without_pythonpath(tmp_path):
    import shutil
    src=Path(__file__).resolve().parents[1]
    project=tmp_path/'project'; project.mkdir()
    shutil.copy2(src/'version.py',project/'version.py')
    for name in ('scripts','app','config'):
        shutil.copytree(src/name,project/name,ignore=shutil.ignore_patterns('__pycache__'))
    env=dict(os.environ); env.pop('PYTHONPATH',None)
    result=subprocess.run([sys.executable,str(project/'scripts/configure_scheduler.py')],cwd=tmp_path,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace')
    assert result.returncode!=0 and '.env is missing' in result.stderr
    assert 'ModuleNotFoundError' not in result.stderr
    # Exercise the successful entrypoint with a scheduler command double too.
    (project/'.env').write_text('EXECUTION_MODE=DRY_RUN\nLIVE_TRADING_ENABLED=false\n')
    (project/'scripts/recovery_scheduler.py').write_text(
        'class RecoveryScheduler:\n    platform="termux"\n    def __init__(self,root): pass\n    def needs_repair(self,values): return False\n')
    result=subprocess.run([sys.executable,str(project/'scripts/configure_scheduler.py')],cwd=tmp_path,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace')
    assert result.returncode==0 and 'CURRENT_PRESERVED' in result.stdout


def test_restore_scheduler_failure_restores_env_state_ledger_history(tmp_path,monkeypatch):
    from scripts.backup_common import verify_archive
    from test_backup_recovery import write_env
    root=tmp_path/'restore'; root.mkdir(); write_env(root,BASE)
    path=bundle(tmp_path,monkeypatch)
    files,_=verify_archive(path)
    data=root/'data'; data.mkdir(); history=data/'history'; history.mkdir()
    targets={data/'state.json':files['state.json'],data/'order_ledger.json':files['order_ledger.json'],
             root/'.env':(root/'.env').read_bytes()}
    if 'trade_history.csv' in files: targets[history/'trade_history.csv']=files['trade_history.csv']
    for target,contents in targets.items(): target.write_bytes(contents)
    scheduler,runner=termux(root,monkeypatch,OTHER)
    runner.daemon=False; runner.fail_daemon=True
    with pytest.raises(RuntimeError,match='crond is not running'):
        recover(path,root=root,values=dict(BASE),context_factory=factory(root),scheduler=scheduler)
    for target,contents in targets.items(): assert target.read_bytes()==contents
    assert runner.cron==OTHER


def test_disabled_existing_timer_state_survives_repair(tmp_path,monkeypatch):
    scheduler,runner,units=linux(tmp_path,monkeypatch)
    timer='kb-qld-trader.timer'; runner.states[timer]=(False,False)
    (units/timer).write_text('outdated')
    apply(scheduler)
    assert runner.states[timer]==(False,False)


def test_missing_termux_commands_are_explicit(monkeypatch):
    monkeypatch.setenv('PREFIX','/data/data/com.termux/files/usr')
    monkeypatch.setattr(pd.shutil,'which',lambda command:None)
    with pytest.raises(RuntimeError,match='crontab'): pd.validate_termux_runtime()


def test_healthy_termux_restore_reports_preserved_running_scheduler(tmp_path,monkeypatch):
    from test_backup_recovery import write_env
    root=tmp_path/'restore'; root.mkdir(); write_env(root,BASE)
    good=pd.cron_block(root,BASE,rs.backup_enabled(BASE),BASE['BACKUP_TIME'])
    scheduler,runner=termux(root,monkeypatch,OTHER+good,boot=True)
    result=recover(bundle(tmp_path,monkeypatch),root=root,values=dict(BASE),context_factory=factory(root),scheduler=scheduler)
    assert result['scheduler'].trading=='CURRENT_PRESERVED'
    assert result['scheduler'].crond=='RUNNING'
    assert not any(args==['crontab','-'] or args[0]=='sh' for args,kw in runner.calls)


def test_termux_rollback_reports_failure_but_still_restores_boot(tmp_path,monkeypatch):
    scheduler,runner=termux(tmp_path,monkeypatch,OTHER)
    scheduler.needs_repair(VALUES); scheduler.quiesce(); scheduler.install(VALUES)
    runner.fail_write=True
    with pytest.raises(RuntimeError,match='manual review required: crontab'):
        scheduler.rollback()
    assert not (tmp_path/'home/.termux/boot/start-kb-qld-trader').exists()


def test_linux_detection_ignores_old_termux_metadata(tmp_path,monkeypatch):
    monkeypatch.delenv('PREFIX',raising=False)
    monkeypatch.setenv('INSTALL_PLATFORM','termux')
    monkeypatch.setattr(pd.sys,'platform','linux')
    original=Path.is_dir
    monkeypatch.setattr(Path,'is_dir',lambda p:True if p.as_posix()=='/run/systemd/system' else original(p))
    monkeypatch.setattr(pd.shutil,'which',lambda command:'/usr/bin/'+command)
    (tmp_path/'.install-platform').write_text('termux')
    assert pd.selected_platform(tmp_path)=='linux'


def test_loaded_dropin_is_safe_manual_error(tmp_path,monkeypatch):
    scheduler,runner,units=linux(tmp_path,monkeypatch)
    def run(args,**kw):
        if 'DropInPaths' in args:
            return SimpleNamespace(returncode=0,stdout='DropInPaths=/custom/override.conf\nNeedDaemonReload=no\n')
        return runner(args,**kw)
    scheduler.run=run
    with pytest.raises(RuntimeError,match='manual review'): scheduler.needs_repair(VALUES)
    assert not runner.installed


def test_repair_keeps_kb_block_position_between_other_jobs(tmp_path,monkeypatch):
    good=pd.cron_block(tmp_path,VALUES,True,VALUES['BACKUP_TIME'])
    bad=good.replace('CRON_TZ=America/New_York','CRON_TZ=wrong')
    suffix='\r\n# following job  \r\n3 4 * * * /other/following\r\n'
    scheduler,runner=termux(tmp_path,monkeypatch,OTHER+bad+suffix,boot=True)
    apply(scheduler)
    assert runner.cron==OTHER+good+suffix


def test_linux_partial_rollback_continues_and_reports_manual_review(tmp_path,monkeypatch):
    scheduler,runner,units=linux(tmp_path,monkeypatch)
    for name in ('kb-qld-trader.timer','kb-qld-trader-backup.timer'):
        (units/name).write_text('old')
    before={p.name:p.read_bytes() for p in units.iterdir()}
    scheduler.needs_repair(VALUES); scheduler.quiesce(); scheduler.install(VALUES)
    def fail_one(args,**kw):
        if args[:2]==['sudo','install'] and args[-1].endswith('kb-qld-trader.service'):
            raise PermissionError('mock rollback denied')
        return runner(args,**kw)
    scheduler.run=fail_one
    with pytest.raises(RuntimeError,match='manual review required'):
        scheduler.rollback()
    for name in ('kb-qld-trader.timer','kb-qld-trader-backup.timer'):
        assert (units/name).read_bytes()==before[name]
