from datetime import datetime
from zoneinfo import ZoneInfo
import pytest
from app.api.session_calendar import session_timing
from app.api.live_contract import require_live_contract

@pytest.mark.parametrize('hour,expected', [(16,'15:58:00'),(13,'12:58:00')])
def test_session_times(hour, expected):
    close=datetime(2026,11,27,hour,tzinfo=ZoneInfo('America/New_York'))
    policy=session_timing(close)
    assert policy['signal'].strftime('%H:%M:%S') == expected
    assert policy['poll'].minute == 59
    assert policy['admission'].second == 35
    assert policy['execution'].second == 10

def test_missing_contract_cannot_unlock_live():
    with pytest.raises(RuntimeError,match='unverified'):
        require_live_contract('any-account')
