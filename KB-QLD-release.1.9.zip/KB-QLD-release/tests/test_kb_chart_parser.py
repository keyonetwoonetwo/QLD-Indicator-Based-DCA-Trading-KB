from types import SimpleNamespace
import pytest
from app.api.kb_broker_api import KBBrokerAPI


def chart(monkeypatch, row):
    monkeypatch.setenv('KB_EXCHANGE_QQQ','NAS')
    return KBBrokerAPI(SimpleNamespace(request=lambda *a,**k: {'out2':[row]}))


def row():
    return dict(dt='20261012',tm='',opn_prc_p4=' 100.0000',hgh_prc_p4='101',
                lw_prc_p4='99',cls_prc_p4='100.5',vlm='0')


@pytest.mark.parametrize('field',['opn_prc_p4','hgh_prc_p4','lw_prc_p4','cls_prc_p4'])
@pytest.mark.parametrize('value',[None,'','    ','NaN','not-a-number'])
def test_chart_error_names_field_without_raw_response(monkeypatch,field,value):
    data=row(); data[field]=value; data['private']='SECRET_ACCOUNT_TOKEN'
    with pytest.raises(RuntimeError) as error:
        chart(monkeypatch,data).get_candles('QQQ',interval='1d')
    message=str(error.value)
    assert all(part in message for part in ('GSC10060','QQQ','1d','field='+field))
    assert 'SECRET_ACCOUNT_TOKEN' not in message


def test_daily_chart_accepts_blank_time_and_zero_volume(monkeypatch):
    result=chart(monkeypatch,row()).get_candles('QQQ',interval='1d')['candles'][0]
    assert result['closePrice']=='100.5' and result['volume']=='0'
    assert 'T00:00:00' in result['timestamp']


@pytest.mark.parametrize('value',[None,'','   '])
def test_daily_unavailable_volume_keeps_ohlc(monkeypatch,value,caplog):
    data=row(); data['vlm']=value
    result=chart(monkeypatch,data).get_candles('QQQ',interval='1d')['candles'][0]
    assert result['volume']=='0' and result['volumeAvailable'] is False
    assert result['closePrice']=='100.5'
    assert all(part in caplog.text for part in ('GSC10060','QQQ','1d','field=vlm'))


@pytest.mark.parametrize('value',['NaN','not-a-number'])
def test_malformed_volume_remains_an_error(monkeypatch,value):
    data=row(); data['vlm']=value
    with pytest.raises(RuntimeError,match='field=vlm'):
        chart(monkeypatch,data).get_candles('QQQ',interval='1d')


def test_validate_dry_run_with_blank_daily_volume(monkeypatch):
    import importlib
    from pathlib import Path
    monkeypatch.syspath_prepend(str(Path(__file__).resolve().parents[1] / 'scripts'))
    validate=importlib.import_module('validate')
    data=row(); data['vlm']='   '
    broker=chart(monkeypatch,data)
    calls=[]
    def read_only(method,path,**kwargs):
        assert method=='POST' and path=='/api/v1/gsc10060'
        calls.append(path)
        return {'out2':[data]}
    broker.client.request=read_only
    monkeypatch.setattr(broker,'get_prices',lambda symbols: [])
    monkeypatch.setattr(broker,'get_us_market_calendar',lambda: {})
    config=SimpleNamespace(resolved_strategy=lambda: SimpleNamespace(signal_symbol='QQQ',main_symbol='QLD',safe_symbol='TBIL'))
    state=SimpleNamespace(load_state_strict=lambda: {},assert_installation_identity=lambda *a: None,assert_reconciled=lambda *a: None)
    ledger=SimpleNamespace(load_strict=lambda: {})
    adapter=SimpleNamespace(get_portfolio_state=lambda *a: object())
    def context(require_dry):
        assert require_dry is True
        return config,broker,adapter,state,ledger,{'account_binding':'test-binding','account_no':'test-fingerprint'}
    monkeypatch.setattr(validate,'runtime_context',context)
    monkeypatch.setattr(validate,'read_env',lambda: {})
    approvals=[]
    monkeypatch.setattr(validate,'write_validation_record',lambda *a: approvals.append(True))
    validate.main()
    assert calls==['/api/v1/gsc10060'] and approvals==[True]
