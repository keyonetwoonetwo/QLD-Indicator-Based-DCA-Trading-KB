import pytest
from app.api.kb_broker_api import KBBrokerAPI


def row(state='주문접수', **changes):
    result=dict(ordr_st_nm=state,ordr_dt='20261020',ordr_no='0000000147',
                orgn_ordr_no='0000000000',shrt_is_cd='QLD',dl_clsf_nm='매수',
                frgn_ordr_q_p6='11',ccls_q_p6='0',nccls_q_p6='0',frgn_ccls_prc_p6='0')
    result.update(changes)
    return result


def cancelled_pair():
    return [row(),row('취소확인',ordr_no='0000000148',orgn_ordr_no='0000000147',dl_clsf_nm='매수취소')]


def broker_with(rows):
    broker=KBBrokerAPI(None)
    broker._order_rows=lambda:rows
    return broker


@pytest.mark.parametrize('state,filled,remaining,expected',[
    ('체결','11','0','FILLED'),('주문취소','0','0','CANCELED'),
    ('주문접수','0','11','PENDING'),('주문접수','0','0','PENDING'),
    ('주문중','0','11','PENDING'),('취소확인','0','0','UNKNOWN'),
    ('모름','0','0','UNKNOWN'),('체결','0','0','UNKNOWN'),
    ('주문취소','0','11','UNKNOWN'),('주문중','2','9','PARTIAL_FILLED'),
    ('취소완료','0','0','CANCELED'),('거부','0','0','REJECTED'),
    ('취소중','0','11','PENDING_CANCEL')])
def test_kb_states(state,filled,remaining,expected):
    assert KBBrokerAPI.normalize_order(row(state,ccls_q_p6=filled,nccls_q_p6=remaining))['status']==expected


def test_received_original_and_confirmation_are_both_final_only_with_evidence():
    broker=broker_with(cancelled_pair())
    assert broker.get_orders()==[]
    assert [o['status'] for o in broker.get_orders('ALL')]==['CANCELED','CANCELED']
    assert broker.get_order_detail('0000000147')['status']=='CANCELED'
    assert broker.get_order_detail('0000000148')['status']=='CANCELED'


@pytest.mark.parametrize('changes',[
    {'ordr_dt':'20261019'},{'shrt_is_cd':'TBIL'},{'orgn_ordr_no':'0000000146'},
    {'frgn_ordr_q_p6':'10'},{'nccls_q_p6':'1'},{'ccls_q_p6':'1'},
    {'dl_clsf_nm':'매수'},{'ordr_st_nm':'취소중'},{'ordr_no':'0000000147'},
    {'frgn_ordr_q_p6':'0'},{'frgn_ordr_q_p6':'12'},
])
def test_unverified_cancellation_blocks(changes):
    rows=cancelled_pair(); rows[1].update(changes)
    assert broker_with(rows).get_orders()


@pytest.mark.parametrize('change',['duplicate-child','duplicate-parent','conflicting-child','remaining','missing-date','unknown-parent'])
def test_ambiguous_or_open_parent_blocks(change):
    rows=cancelled_pair()
    if change=='duplicate-child': rows.append(dict(rows[1]))
    elif change=='duplicate-parent': rows.append(dict(rows[0]))
    elif change=='conflicting-child': rows.append(dict(rows[1],ordr_st_nm='주문취소'))
    elif change=='remaining': rows[0]['nccls_q_p6']='1'
    elif change=='missing-date':
        for r in rows: r.pop('ordr_dt')
    else: rows[0]['ordr_st_nm']='모름'
    assert broker_with(rows).get_orders()


def test_partial_fill_then_verified_full_remainder_cancellation():
    rows=cancelled_pair(); rows[0].update(ccls_q_p6='2',frgn_ccls_prc_p6='100')
    rows[1]['frgn_ordr_q_p6']='9'
    broker=broker_with(rows)
    assert broker.get_orders()==[]
    assert broker.get_order_detail('0000000147')['execution']['filledQuantity']=='2'


def test_invalid_managed_numeric_field_still_blocks():
    with pytest.raises(RuntimeError): broker_with([row(ccls_q_p6='')]).get_orders(symbol='QLD')
