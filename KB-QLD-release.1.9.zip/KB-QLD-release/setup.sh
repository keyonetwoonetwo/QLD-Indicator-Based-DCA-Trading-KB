#!/usr/bin/env bash
# Fresh-install wizard entrypoint. It intentionally never promotes LIVE.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"

echo "========================================"
echo "KB QLD Trader 설치"
echo "========================================"
echo
echo "실행 환경을 선택하세요."
echo
echo "[1] Linux"
echo "    일반 Linux / VPS / systemd 환경"
echo
echo "[2] Android / Termux"
echo "    스마트폰 / Termux 환경"
echo
while true; do
    read -r -p "선택 [1/2]: " choice
    case "$choice" in
        1)
            command -v systemctl >/dev/null 2>&1 || { echo "오류: Linux 설치에는 systemctl이 필요합니다." >&2; exit 1; }
            [[ -d /run/systemd/system ]] || { echo "오류: systemd가 실행 중이 아닙니다. 설치를 안전하게 중단합니다." >&2; exit 1; }
            INSTALL_PLATFORM="linux"
            break
            ;;
        2)
            case "${PREFIX:-}" in
                /data/data/com.termux/*|/data/user/*/com.termux/*) ;;
                *) echo "오류: 실제 Termux 환경을 확인할 수 없습니다(PREFIX=${PREFIX:-설정되지 않음}). 설치를 안전하게 중단합니다." >&2; exit 1 ;;
            esac
            echo
            echo "Android / Termux 설치를 선택했습니다."
            echo
            echo "설치를 계속하기 전에 다음을 확인하세요."
            echo
            echo "- Android 배터리 최적화에서 Termux 제외"
            echo "- Termux 알림 패널에서 Wake Lock 활성화"
            read -r -p "위 설정을 완료했습니까? [y/N]: " ready
            case "${ready,,}" in y|yes) ;; *) echo "필수 Android 설정이 확인되지 않아 설치를 중단합니다."; exit 1 ;; esac
            INSTALL_PLATFORM="termux"
            break
            ;;
        *) echo "잘못된 선택입니다. 1 또는 2를 입력하세요." ;;
    esac
done
export INSTALL_PLATFORM
printf '%s\n' "$INSTALL_PLATFORM" > "$ROOT/.install-platform"

# This is deliberately a fresh-install tool. Existing approved durable data
# must be recovered or handled by an operator, never recreated implicitly.
if [[ -e "$ROOT/data/state.json" || -e "$ROOT/data/order_ledger.json" ]]; then
    echo "승인된 기존 lifecycle 데이터가 있습니다. 새 설치를 거부합니다." >&2
    echo "maintenance 또는 restore 절차를 사용하세요. setup.sh는 state/ledger를 덮어쓰지 않습니다." >&2
    exit 1
fi

"$ROOT/install.sh"
"$ROOT/.venv/bin/python" "$ROOT/scripts/setup_wizard.py"
if [[ "$INSTALL_PLATFORM" == "termux" ]]; then
    "$ROOT/.venv/bin/python" "$ROOT/scripts/cleanup_termux_build.py"
fi
