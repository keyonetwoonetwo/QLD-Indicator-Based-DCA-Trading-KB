"""KB TR adapter. Undocumented live contracts fail closed, never fall back."""
import hashlib
import logging
import os
from datetime import datetime, timedelta
from decimal import Decimal, ROUND_DOWN, ROUND_UP
from zoneinfo import ZoneInfo
from app.api.base_broker import BaseBrokerAPI
from app.api.session_calendar import market_calendar

NY=ZoneInfo('America/New_York')

def number(value):
    if value is None or not str(value).strip(): raise RuntimeError('Required KB numeric field missing')
    result=Decimal(str(value).strip())
    if not result.is_finite(): raise RuntimeError('Invalid KB number')
    return result

class KBBrokerAPI(BaseBrokerAPI):
    def __init__(self,client,**kwargs):
        self.client=client
        self._quotes={}
        self._chart_cache={}
    def _tr(self,code,body=None,account=True):
        return self.client.request('POST','/api/v1/'+code.lower(),json_data=body or {},require_account=account)
    def _pages(self,code,body,record):
        rows=[]; seen=set()
        for _ in range(100):
            data=self._tr(code,body)
            values=data.get(record)
            if not isinstance(values,list): raise RuntimeError('KB record array missing')
            count_field = 'grid_cnt2' if record == 'Record2' else 'grid_cnt'
            if count_field in data and number(data[count_field]) != len(values):
                raise RuntimeError('KB record count disagrees with returned rows')
            rows.extend(values)
            key=str(data.get('nxt_key','')).strip()
            if not key: return rows
            if key in seen: raise RuntimeError('KB continuation key repeats')
            seen.add(key); body=dict(body,nxt_key=key)
        raise RuntimeError('KB continuation exceeded bound')
    def connect_account(self,configured_account):
        if not configured_account: raise RuntimeError('KB account configuration missing')
        # This hash isolates local state. It is never sent as a broker account ID.
        binding=hashlib.sha256(('KB:'+self.client.auth_manager.client_id+':'+configured_account).encode()).hexdigest()
        self.client.set_account_binding(binding)
        try:
            self.get_holdings()
            self.get_buying_power('USD')
        except Exception:
            self.client.set_account_binding(None)
            raise
        return binding
    def get_accounts(self):
        raise RuntimeError('KB has no documented account-list TR; use app-bound account context')
    def get_us_market_calendar(self,date_str=None): return market_calendar(date_str)
    def _exchange(self,symbol):
        value=os.getenv('KB_EXCHANGE_'+symbol)
        if not value: raise RuntimeError('Explicit KB exchange mapping required for '+symbol)
        return value
    def get_prices(self,symbols):
        result=[]
        for symbol in symbols:
            data=self._tr('GSS10030',{'krx_cd':self._exchange(symbol),'is_cd':symbol},False)
            if str(data.get('is_cd','')).strip()!=symbol or str(data.get('dl_crncy','')).strip()!='USD': raise RuntimeError('KB quote instrument/currency mismatch')
            price=number(data.get('now_prc_p4'))
            if price<=0: raise RuntimeError('KB price not positive')
            self._quotes[symbol]=data
            result.append({'symbol':symbol,'lastPrice':str(price),'currency':'USD'})
        return result
    def assert_quote_fresh(self,symbol,max_age_seconds=30):
        data=self._quotes.get(symbol)
        if not data: raise RuntimeError('KB execution quote missing')
        try:
            stamp=datetime.strptime(str(data['dt']).strip()+str(data['tm']).strip(),'%Y%m%d%H%M%S').replace(tzinfo=NY)
        except (KeyError,ValueError) as exc:
            raise RuntimeError('KB execution quote timestamp unavailable') from exc
        age=(datetime.now(NY)-stamp).total_seconds()
        if age < -3 or age > max_age_seconds: raise RuntimeError('KB execution quote is stale or future-dated')
    def normalize_limit_price(self,symbol,price,side='BUY'):
        data=self._quotes.get(symbol)
        if not data:
            self.get_prices([symbol]); data=self._quotes[symbol]
        tick=number(data.get('b_askprc_unt_p4' if side=='BUY' else 's_askprc_unt_p4'))
        if tick<=0: raise RuntimeError('KB tick unavailable')
        rounding=ROUND_UP if side=='BUY' else ROUND_DOWN
        result=(price/tick).to_integral_value(rounding=rounding)*tick
        if result<=0: raise RuntimeError('KB normalized price not positive')
        return result
    def get_candles(self,symbol,interval='1d',count=200,before=None,adjusted=True):
        if interval not in {'1d','1m'}: raise ValueError('Unsupported KB chart interval')
        cache_key=(symbol,interval,adjusted)
        if before:
            stamp,offset=before.rsplit('|',1)
            cache=self._chart_cache.get(cache_key)
            if not cache or cache[0]!=stamp: raise RuntimeError('Chart cursor is not valid in this process')
            rows=cache[1]; start=int(offset)
        else:
            requested_count=int(count) if interval=='1m' else 5000
            if not 1 <= requested_count <= 5000: raise ValueError('Invalid KB chart request count')
            data=self._tr('GSC10060',{'krx_cd':self._exchange(symbol),'is_cd':symbol,'chrt_clsf':'3' if interval=='1d' else '2','bndl':'1','mdfy_stk_prc_use_f':'1' if adjusted else '0','rcrd_c':str(requested_count)},False)
            if interval=='1m':
                logging.getLogger(__name__).info('GSC10060 symbol=%s interval=1m mrkt_prc_clsf=%r; realtime pricing unverified',symbol,str(data.get('mrkt_prc_clsf',''))[:64])
            if interval=='1m' and os.getenv('KB_BAR_TIME_BASIS')!='START_NY': raise RuntimeError('KB minute timestamp semantics unverified; configure only after read-only validation')
            raw=data.get('out2')
            if not isinstance(raw,list): raise RuntimeError('KB chart out2 missing')
            rows=[]
            seen_minute_timestamps=set()
            for index,item in enumerate(raw):
                context=f'GSC10060 symbol={symbol} interval={interval} row={index}'
                if not isinstance(item,dict): raise RuntimeError(context+' field=out2 invalid row')
                def chart_number(field):
                    value=item.get(field)
                    try:
                        return str(number(value))
                    except (RuntimeError,ArithmeticError,ValueError):
                        reason='missing' if value is None or not str(value).strip() else 'invalid numeric'
                        raise RuntimeError(f'{context} field={field} {reason}') from None
                try:
                    dt=str(item.get('dt','')).strip(); tm=str(item.get('tm','')).strip() if interval=='1m' else '000000'
                    if len(dt)!=8 or not dt.isdigit(): raise RuntimeError(context+' field=dt missing or invalid')
                    if len(tm)!=6 or not tm.isdigit(): raise RuntimeError(context+' field=tm missing or invalid')
                    try:
                        timestamp=datetime.strptime(dt+tm,'%Y%m%d%H%M%S').replace(tzinfo=NY)
                    except ValueError:
                        raise RuntimeError(context+' field=dt/tm invalid timestamp') from None
                    if interval=='1m':
                        if timestamp in seen_minute_timestamps:
                            raise RuntimeError('Duplicate KB candle timestamp')
                        seen_minute_timestamps.add(timestamp)
                    missing_volume=item.get('vlm') is None or not str(item.get('vlm')).strip()
                    # Volume is not a strategy input. Only daily absent volume gets
                    # a compatibility placeholder; OHLC and malformed numbers fail.
                    volume_missing=interval=='1d' and missing_volume
                    if volume_missing:
                        logging.getLogger(__name__).warning('%s field=vlm missing; daily volume unavailable',context)
                    rows.append(dict(timestamp=timestamp.isoformat(),openPrice=chart_number('opn_prc_p4'),highPrice=chart_number('hgh_prc_p4'),lowPrice=chart_number('lw_prc_p4'),closePrice=chart_number('cls_prc_p4'),volume='0' if volume_missing else chart_number('vlm'),volumeAvailable=not volume_missing,currency='USD'))
                except RuntimeError as exc:
                    if interval!='1m' or not str(exc).startswith(context+' field='):
                        raise
                    logging.getLogger(__name__).warning('%s; candle excluded',exc)
                    continue
            rows.sort(key=lambda row:row['timestamp'],reverse=True)
            if len({r['timestamp'] for r in rows})!=len(rows): raise RuntimeError('Duplicate KB candle timestamp')
            if interval=='1m':
                now=datetime.now(NY)
                if any(datetime.fromisoformat(r['timestamp'])>now for r in rows):
                    raise RuntimeError(f'GSC10060 symbol={symbol} interval=1m future candle')
                rows=[r for r in rows if datetime.fromisoformat(r['timestamp'])+timedelta(minutes=1)<=now]
            stamp=datetime.now(NY).isoformat(); self._chart_cache[cache_key]=(stamp,rows); start=0
        stop=start+(int(count) if interval=='1m' else min(int(count),200))
        return {'candles':rows[start:stop],'nextBefore':f'{stamp}|{stop}' if stop<len(rows) else None}
    def get_holdings(self,symbol=None):
        rows=self._pages('SPQM2226',{'std_crncy_f':'1','nxt_key':''},'Record2')
        merged={}
        for row in rows:
            name=str(row['is_cd']).strip()
            if symbol and name!=symbol: continue
            qty=number(row['frgn_hld_q_p6']); avg=number(row['byng_avr_prc_p4']); price=number(row['now_prc_p4'])
            item=merged.setdefault(name,{'symbol':name,'name':str(row.get('is_nm','')).strip(),'quantity':Decimal(0),'cost':Decimal(0),'lastPrice':str(price),'currency':'USD'})
            item['quantity']+=qty; item['cost']+=qty*avg
        for item in merged.values():
            qty=item['quantity']; item['averagePurchasePrice']=str(item.pop('cost')/qty if qty else 0)
            item['marketValue']={'amount':str(qty*number(item['lastPrice']))}
            item['quantity']=str(qty)
        return {'items':list(merged.values())}
    def get_buying_power(self,currency='USD'):
        if currency!='USD': raise ValueError('USD only')
        rows=self._tr('SKQM3350').get('Record1',[])
        matches=[r for r in rows if str(r.get('crncy_cd','')).strip()=='USD']
        if len(matches)!=1: raise RuntimeError('Unique USD cash record unavailable')
        value=number(matches[0]['fcrncy_use_psbl_amt_p2'])
        if value<0: raise RuntimeError('Negative USD buying power')
        return {'cashBuyingPower':str(value)}
    def get_sellable_quantity(self,symbol):
        rows=self._pages('SPQM2226',{'std_crncy_f':'1','nxt_key':''},'Record2')
        quantity=sum((number(r['frgn_ordr_psbl_q_p6']) for r in rows if str(r['is_cd']).strip()==symbol),Decimal(0))
        return {'sellableQuantity':str(quantity)}
    def build_order_request(self,symbol,side,order_type,quantity=None,price=None,time_in_force=None,client_order_id=None,order_amount=None):
        if order_type!='LIMIT' or not price or side not in {'BUY','SELL'}: raise ValueError('KB LIMIT with price required')
        p=number(price)
        if p<=0 or p!=self.normalize_limit_price(symbol,p,side): raise ValueError('Invalid KB tick price')
        body={'is_cd':symbol,'trd_dl_ccd':'02' if side=='BUY' else '01','frgn_ordr_typ_cd':'2','frgn_ordr_prc_p4':str(p)}
        if order_amount is not None:
            if side!='BUY' or quantity is not None or number(order_amount)<=0: raise ValueError('MAIN requires positive USD amount only')
            body.update(amt_q_clsf='0',crncy_ccd='1',ordr_amt=str(number(order_amount)))
            return 'SKAM2201',body
        q=number(quantity)
        if q<=0 or q!=q.to_integral_value(): raise ValueError('SAFE requires positive whole shares')
        body['frgn_ordr_q']=str(q.to_integral_value())
        return 'SKAM2101',body
    def create_order(self,**kwargs):
        code,body=self.build_order_request(**kwargs)
        response=self._tr(code,body)
        if str(response.get('rsrv_ordr_f','')).strip()=='1': raise RuntimeError('KB reservation is not a same-session order; reconciliation required')
        oid=str(response.get('ordr_no','')).strip()
        if not oid: raise RuntimeError('KB order number missing')
        return {'orderId':oid}
    def _order_rows(self):
        today=datetime.now(NY).date(); start=today-timedelta(days=7)
        return self._pages('SPQM2204',dict(strt_ordr_dt=start.strftime('%Y%m%d'),end_ordr_dt=today.strftime('%Y%m%d'),ccls_clsf='0',trd_clsf='99',dl_clsf='0',nxt_key=''),'Record1')
    @staticmethod
    def _confirmed_cancel(row, rows):
        # SPQM2204 can leave the original order as 주문접수 after cancellation.
        key=lambda r: (str(r.get('ordr_dt','')).strip(),str(r.get('shrt_is_cd','')).strip())
        identity=key(row)
        if not all(identity): return False
        order_id=str(row.get('ordr_no','')).strip()
        parents=[r for r in rows if key(r)==identity and str(r.get('ordr_no','')).strip()==order_id]
        if len(parents)!=1 or str(row.get('ordr_st_nm','')).strip() not in {'주문접수','주문취소','취소완료'}:
            return False
        confirmations=[r for r in rows if key(r)==identity and str(r.get('orgn_ordr_no','')).strip()==order_id
                       and str(r.get('ordr_st_nm','')).strip()=='취소확인']
        if not confirmations: return False
        ids=[str(r.get('ordr_no','')).strip() for r in confirmations]
        if not all(ids) or len(ids)!=len(set(ids)) or order_id in ids: return False
        if any(sum(key(r)==identity and str(r.get('ordr_no','')).strip()==child_id for r in rows)!=1
               for child_id in ids): return False
        cancelled=number('0')
        for child in confirmations:
            if '취소' not in str(child.get('dl_clsf_nm','')): return False
            quantity=number(child.get('frgn_ordr_q_p6'))
            if quantity<=0 or number(child.get('nccls_q_p6'))!=0 or number(child.get('ccls_q_p6'))!=0:
                return False
            cancelled+=quantity
        filled=number(row.get('ccls_q_p6'))
        return (filled>=0 and number(row.get('nccls_q_p6'))==0
                and number(row.get('frgn_ordr_q_p6'))==filled+cancelled)
    @staticmethod
    def normalize_order(row, rows=()):
        state=str(row.get('ordr_st_nm','')).strip()
        status={'체결':'FILLED','주문중':'PENDING','주문접수':'PENDING',
                '주문취소':'CANCELED','취소완료':'CANCELED',
                '거부':'REJECTED','취소중':'PENDING_CANCEL'}.get(state,'UNKNOWN')
        filled=number(row['ccls_q_p6']); remaining=number(row['nccls_q_p6']); average=number(row['frgn_ccls_prc_p6'])
        if filled<0 or remaining<0: raise RuntimeError('Invalid KB execution quantity')
        if status=='FILLED' and (filled<=0 or remaining!=0): status='UNKNOWN'
        if status=='CANCELED' and remaining!=0: status='UNKNOWN'
        if state=='주문접수' and KBBrokerAPI._confirmed_cancel(row,rows): status='CANCELED'
        if state=='취소확인':
            parents=[r for r in rows if str(r.get('ordr_no','')).strip()==str(row.get('orgn_ordr_no','')).strip()
                     and str(r.get('ordr_dt','')).strip()==str(row.get('ordr_dt','')).strip()
                     and str(r.get('shrt_is_cd','')).strip()==str(row.get('shrt_is_cd','')).strip()]
            if len(parents)==1 and KBBrokerAPI._confirmed_cancel(parents[0],rows): status='CANCELED'
        if filled>0 and remaining>0: status='PARTIAL_FILLED'
        # Price field's averaging semantics are not asserted as verified LIVE evidence.
        return dict(orderId=str(row['ordr_no']).strip(),symbol=str(row['shrt_is_cd']).strip(),status=status,execution=dict(filledQuantity=str(filled),averageFilledPrice=str(average),filledAmount=str(filled*average)))
    def get_orders(self,status='OPEN',symbol=None):
        rows=self._order_rows()
        orders=[self.normalize_order(row,rows) for row in rows]
        return [o for o in orders if (not symbol or o['symbol']==symbol) and (status!='OPEN' or o['status'] not in {'FILLED','CANCELED','REJECTED'})]
    def get_order_detail(self,order_id):
        all_rows=self._order_rows()
        rows=[r for r in all_rows if str(r['ordr_no']).strip()==order_id]
        if len(rows)!=1: raise RuntimeError('KB order missing or ambiguous; do not resubmit')
        return self.normalize_order(rows[0],all_rows)
    def cancel_order(self,order_id):
        rows=[r for r in self._order_rows() if str(r['ordr_no']).strip()==order_id]
        if len(rows)!=1: raise RuntimeError('KB cancellation identity ambiguous')
        row=rows[0]
        if str(row.get('dcml_dl_f')).strip()=='1': return self._tr('SKAM2202',{'orgn_ordr_no':order_id})
        return self._tr('SKAM2102',dict(crct_cncl_clsf='2',is_cd=str(row['shrt_is_cd']).strip(),orgn_ordr_no=order_id,frgn_ordr_prc_p4=str(number(row['frgn_ordr_prc_p6']))))
