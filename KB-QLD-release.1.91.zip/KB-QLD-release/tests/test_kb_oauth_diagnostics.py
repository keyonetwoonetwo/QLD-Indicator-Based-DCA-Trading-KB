import io
import json
import traceback
import urllib.error
from datetime import datetime,timezone,timedelta
import pytest
from app.api.auth import KBAuthManager
from app.api.client import KBAPIClient
from test_kb14_live_flow import promotion

SECRETS=('FAKE_ACCESS_TOKEN_12345','FAKE_REFRESH_TOKEN_67890','FAKE_APP_KEY_11111',
         'FAKE_APP_SECRET_22222','12345678901234','Bearer FAKE_AUTH_HEADER_33333')


def reply(body=None):
    return {'dataHeader':{'resultCode':'200','processFlag':'A'},
            'dataBody':body if body is not None else dict(access_token=SECRETS[0],token_type='Bearer',expires_in=86400)}


class Response:
    def __init__(self,payload,status=200):
        self.raw=payload if isinstance(payload,bytes) else json.dumps(payload).encode()
        self.status=status
    def __enter__(self): return self
    def __exit__(self,*args): return False
    def read(self): return self.raw


def manager(payload=None,error=None,status=200):
    requests=[]
    def opener(request,timeout):
        requests.append(request)
        if error: raise error
        return Response(reply() if payload is None else payload,status)
    auth=KBAuthManager('https://example.invalid',SECRETS[2],SECRETS[3],
                       ip_addr='192.0.2.1',mac_addr='00:00:00:00:00:01',opener=opener,clock=lambda:1000)
    return auth,requests


def safe_failure(auth,caplog,expected):
    with pytest.raises(RuntimeError,match=expected) as error:
        auth.issue_token()
    output=str(error.value)+caplog.text+''.join(traceback.format_exception(error.type,error.value,error.tb))
    assert not any(secret in output for secret in SECRETS)
    assert not auth.has_valid_token
    return str(error.value)


@pytest.mark.parametrize('field,value,expected',[
    ('access_token',None,'access_token missing'),('access_token','  ','access_token missing'),
    ('access_token',123,'access_token invalid type'),
    ('token_type',None,'token_type missing'),('token_type','','token_type missing'),
    ('token_type','Basic','token_type unexpected'),('token_type',123,'token_type unexpected'),
    ('token_type',' bearer ','token_type unexpected'),
    ('expires_in',None,'expires_in missing'),('expires_in',' ','expires_in missing'),
    ('expires_in','SECRET expires','expires_in invalid numeric'),
    ('expires_in','NaN','expires_in invalid nonfinite'),
    ('expires_in','Infinity','expires_in invalid nonfinite'),
    ('expires_in',10**400,'expires_in invalid numeric'),
])
def test_validation_failures_are_specific_and_private(caplog,field,value,expected):
    body=reply()['dataBody']; body[field]=value
    if value is None: body.pop(field)
    auth,requests=manager(reply(body))
    safe_failure(auth,caplog,expected)
    assert len(requests)==1


@pytest.mark.parametrize('status',[400,401,429,500])
def test_http_errors_do_not_echo_url_reason_or_body(caplog,status):
    error=urllib.error.HTTPError('https://example.invalid/'+SECRETS[2],status,' '.join(SECRETS),{},io.BytesIO(' '.join(SECRETS).encode()))
    auth,requests=manager(error=error)
    safe_failure(auth,caplog,f'HTTP status={status}')
    assert len(requests)==1


def test_nonexception_http_status_is_classified(caplog):
    auth,_=manager(status=500)
    assert 'HTTP status=500' in safe_failure(auth,caplog,'HTTP status=500')


@pytest.mark.parametrize('payload',[
    b'not JSON '+SECRETS[0].encode(), b'\xff', [], {},
    {'dataHeader':[]}, {'dataHeader':{'resultCode':'200'}},
    {'dataHeader':{'resultCode':'200','processFlag':'A'},'dataBody':[]},
])
def test_json_and_structure_failure(caplog,payload):
    auth,_=manager(payload)
    safe_failure(auth,caplog,'response format invalid')


@pytest.mark.parametrize('error,expected',[
    (TimeoutError(' '.join(SECRETS)),'transport timeout'),
    (urllib.error.URLError(TimeoutError(' '.join(SECRETS))),'transport timeout'),
    (urllib.error.URLError(' '.join(SECRETS)),'transport connection_failed'),
    (ConnectionRefusedError(' '.join(SECRETS)),'transport connection_failed'),
    (OSError(' '.join(SECRETS)),'transport connection_failed'),
    (RuntimeError(' '.join(SECRETS)),'unexpected_transport_error'),
])
def test_transport_failure_no_retry_or_secret(caplog,error,expected):
    auth,requests=manager(error=error)
    safe_failure(auth,caplog,expected)
    assert len(requests)==1


def test_known_server_error_code_and_message_category(caplog):
    auth,_=manager({'error':'invalid_client','error_description':'invalid client credentials',
                    'access_token':SECRETS[0],'refresh_token':SECRETS[1]})
    message=safe_failure(auth,caplog,'KB OAuth rejected')
    assert 'server_code=invalid_client' in message
    assert 'server_message_category=client_authentication_failed' in message


def test_untrusted_kb_code_and_message_never_echoed(caplog):
    payload=reply(); payload['dataHeader'].update(resultCode=SECRETS[2],processFlag='F',
        processCode=SECRETS[0],resultMessage=' '.join(SECRETS),processMessage=' '.join(SECRETS))
    auth,_=manager(payload)
    message=safe_failure(auth,caplog,'KB OAuth rejected')
    assert 'unrecognized(redacted)' in message


def test_cache_refresh_margin_and_failed_force_clear(caplog):
    auth,requests=manager(); now=[1000]; auth._clock=lambda:now[0]
    assert auth.get_access_token()==SECRETS[0]
    auth.get_access_token(); assert len(requests)==1
    now[0]+=86400-60
    auth.get_access_token(); assert len(requests)==2
    auth._opener=lambda *a,**k:Response(reply({'token_type':'Bearer','expires_in':86400}))
    safe_failure(auth,caplog,'access_token missing')
    assert auth._access_token is None


def test_read_401_refreshes_once_without_extra_issuance():
    auth,token_calls=manager(); reads=[]
    def opener(req,**kwargs):
        reads.append(req)
        if len(reads)==1: raise urllib.error.HTTPError(req.full_url,401,'hidden',{},None)
        return Response(reply({'items':[]}))
    client=KBAPIClient('https://example.invalid',auth,account_binding='test',opener=opener)
    client.request('POST','/api/v1/spqm2226',require_account=True)
    assert len(token_calls)==2 and len(reads)==2
    auth.get_access_token(); assert len(token_calls)==2


def test_bad_initial_token_stops_account_request(caplog):
    auth,token_calls=manager(reply({'token_type':'Bearer','expires_in':86400}))
    client=KBAPIClient('https://example.invalid',auth,account_binding='test',
                       opener=lambda *a,**k:pytest.fail('account API must not run'))
    with pytest.raises(RuntimeError,match='access_token missing'):
        client.request('POST','/api/v1/spqm2226',require_account=True)
    assert len(token_calls)==1


def test_mutation_401_never_reissues_or_replays(promotion):
    p=promotion; p.mod.main()
    auth,token_calls=manager(); auth.client_id='test-key'; auth.client_secret='test-secret'
    calls=[]
    def opener(req,**k):
        calls.append(req)
        raise urllib.error.HTTPError(req.full_url,401,' '.join(SECRETS),{},None)
    client=KBAPIClient('https://example.invalid',auth,account_binding=p.binding,opener=opener)
    client.order_deadline=datetime.now(timezone.utc)+timedelta(seconds=30)
    code,body=p.broker.build_order_request('QLD','BUY','LIMIT',price='100',order_amount='20')
    with pytest.raises(RuntimeError,match='HTTP 401; request not replayed'):
        client.request('POST','/api/v1/'+code.lower(),json_data=body)
    assert len(calls)==len(token_calls)==1
