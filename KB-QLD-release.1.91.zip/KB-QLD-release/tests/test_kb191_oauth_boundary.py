import json
import logging
import traceback
import urllib.error

import pytest

from app.api.auth import KBAuthManager
from app.api.client import KBAPIClient
from test_kb_oauth_diagnostics import Response, reply, SECRETS


def token(lifetime=86400, **changes):
    body=dict(access_token=SECRETS[0],token_type='Bearer',expires_in=lifetime)
    body.update(changes)
    return reply(body)


def sequence(responses):
    calls=[]
    auth=None
    def opener(request, **kwargs):
        calls.append(request)
        assert auth._access_token is None and auth._expires_at==0
        assert len(calls)<=len(responses), 'unexpected extra OAuth call'
        response=responses[len(calls)-1]
        if isinstance(response,Exception): raise response
        return Response(response)
    auth=KBAuthManager('https://example.invalid',SECRETS[2],SECRETS[3],
                       ip_addr='192.0.2.1',mac_addr='00:00:00:00:00:01',
                       opener=opener,clock=lambda:1000)
    return auth,calls


def paths(calls):
    return [r.full_url.split('example.invalid')[1] for r in calls]


def fails_privately(auth,caplog):
    with pytest.raises(RuntimeError) as error: auth.get_access_token(force_refresh=True)
    output=caplog.text+''.join(traceback.format_exception(error.type,error.value,error.tb))
    assert not any(secret in output for secret in SECRETS)
    assert auth._access_token is None and auth._expires_at==0


@pytest.mark.parametrize('lifetime',[60.001,61,86400,'86400'])
def test_normal_issue_and_memory_cache_unchanged(lifetime):
    auth,calls=sequence([token(lifetime)])
    assert auth.get_access_token()==SECRETS[0]
    assert auth.get_access_token()==SECRETS[0]
    assert paths(calls)==['/oauth2/token']
    assert auth._expires_at==1000+float(lifetime)


@pytest.mark.parametrize('lifetime',[-1,0,1,59,60,'60'])
def test_short_token_revoke_then_exactly_one_reissue(lifetime,caplog):
    caplog.set_level(logging.INFO)
    replacement='FAKE_REPLACEMENT_TOKEN'
    auth,calls=sequence([token(lifetime),reply({'tokenRevoke':'Y'}),token(access_token=replacement)])
    assert auth.get_access_token()==replacement
    assert paths(calls)==['/oauth2/token','/oauth2/revoke','/oauth2/token']
    assert json.loads(calls[1].data)['dataBody']['token']==SECRETS[0]
    assert 'token' not in json.loads(calls[2].data)['dataBody']
    assert auth.get_access_token()==replacement and len(calls)==3
    assert 'success=True' in caplog.text and 'reissue succeeded' in caplog.text
    assert 'expires_in=' in caplog.text
    assert replacement not in caplog.text
    assert not any(secret in caplog.text for secret in SECRETS)


@pytest.mark.parametrize('response',[
    reply({'tokenRevoke':'N'}),reply({}),reply({'tokenRevoke':True}),
    reply({'tokenRevoke':'y'}),reply({'tokenRevoke':'Y '}),
    b'not-json',[],{'dataHeader':{}},
    {'dataHeader':{'resultCode':'401','processFlag':'F','resultMessage':' '.join(SECRETS)},'dataBody':{}},
    TimeoutError(' '.join(SECRETS)),
    urllib.error.HTTPError('https://example.invalid',500,' '.join(SECRETS),{},None),
])
def test_revoke_failure_or_ambiguity_never_reissues(response,caplog):
    auth,calls=sequence([token(60),response])
    fails_privately(auth,caplog)
    assert paths(calls)==['/oauth2/token','/oauth2/revoke']
    assert 'success=False' in caplog.text


@pytest.mark.parametrize('response',[
    token(60),token(0),token(-1),token(59),
    token(access_token=None),token(access_token=' '),token(token_type='Basic'),
    token(expires_in=None),token(expires_in='invalid'),token(expires_in='NaN'),
    b'not-json',[],{'dataHeader':{}},
    TimeoutError(' '.join(SECRETS)),
    urllib.error.HTTPError('https://example.invalid',429,' '.join(SECRETS),{},None),
])
def test_bad_reissue_never_retries_or_revokes_again(response,caplog):
    auth,calls=sequence([token(60),reply({'tokenRevoke':'Y'}),response])
    fails_privately(auth,caplog)
    assert paths(calls)==['/oauth2/token','/oauth2/revoke','/oauth2/token']
    assert 'boundary reissue failed' in caplog.text


@pytest.mark.parametrize('response',[
    token(60,access_token=None),token(60,access_token=' '),token(60,access_token=1),
    token(60,token_type='Basic'),token(expires_in=None),token(expires_in='bad'),
    token(expires_in='Infinity'),b'not-json',[],{'dataHeader':{}},
])
def test_invalid_initial_response_never_revokes_or_reissues(response,caplog):
    auth,calls=sequence([response])
    fails_privately(auth,caplog)
    assert paths(calls)==['/oauth2/token']


def test_failure_clears_old_cache_and_prevents_account_request(caplog):
    auth,calls=sequence([token(60),reply({'tokenRevoke':'N'})])
    auth._access_token='FAKE_OLD_TOKEN'; auth._expires_at=1059
    client=KBAPIClient('https://example.invalid',auth,account_binding='test',
                       opener=lambda *a,**k:pytest.fail('account request must not run'))
    with pytest.raises(RuntimeError): client.request('POST','/api/v1/spqm2226',require_account=True)
    assert auth._access_token is None and auth._expires_at==0
    assert paths(calls)==['/oauth2/token','/oauth2/revoke']


def test_existing_explicit_revoke_clears_memory_and_uses_same_contract():
    auth,calls=sequence([reply({'tokenRevoke':'Y'})])
    auth._access_token=SECRETS[0]; auth._expires_at=87400
    auth.revoke_token()
    assert paths(calls)==['/oauth2/revoke']
    assert json.loads(calls[0].data)['dataBody']['token']==SECRETS[0]
    assert auth._access_token is None and auth._expires_at==0
    auth.revoke_token()
    assert len(calls)==1
